# hcbubble — cavity-scale models for hydrodynamic cavitation reactors

Code, inputs and every run output behind the manuscript *"Selecting cavity-scale models for hydrodynamic
cavitation reactors: a regime map across recovery pressure, gas content, solvent and wall proximity"*
(Pandey & Ranade). Repository URL and DOI: to be added on deposit (e.g. GitHub + Zenodo).

## What is modelled
- Cavity dynamic models: Rayleigh–Plesset (RP), Keller–Miksis (KM), Prosperetti–Lezzi with η = 1/2 (PL), Gilmore (G).
- Closures: polytropic (gas adiabatic with Noble–Abel co-volume, vapour at p_sat) and a Toegel-type energy balance
  (conduction across a thermal boundary layer; vapour exchange by Stefan-corrected diffusion in series with a
  Hertz–Knudsen resistance; vibrational heat capacities; co-volume for gas and vapour).
- One thermodynamically consistent initial state for every combination: vapour at p_sat(T0), gas at p_g0, both at T0.
- No stopping rule on the cavity-wall speed. KM and PL are not singular during collapse (Rdot < 0); the Mach number is reported instead.
- Liquid-specific Tait constants (B from the measured sound speed), the same liquid state for all compressible models.
- Rigid wall / free surface by the image method; arbitrary far-field pressure histories p_inf(t).

## Layout
| Path | Contents |
|---|---|
| `code/properties.py` | gases, vapours and liquids (values and their basis) |
| `code/hcbubble.py` | the models; `simulate(Case(...))` returns the collapse metrics |
| `code/benchmarks.py` | verification: Rayleigh time, Minnaert, adiabatic energy balance, closure limit, image term vs Rattray, tolerance |
| `code/studies.py` | regime map (S1), gases (S2), boundaries (S3), solvents (S4) |
| `code/validation.py` | Tinguely et al. (2012) inverse test (V1), noble gases vs Didenko et al. (2000) (V2, V2b) |
| `code/legacy_check.py` | reproduces the polytropic values of the earlier manuscript's Table 5 |
| `cfd/*.py` | extraction of the mean cavity pressure histories of Simpson & Ranade (ChERD 2018; AIChE J 2019) from the published figures: `extract_aiche.py`/`dashes.py` (traced vector graphics of AIChE J Figs. 10b and 19), `raster_extract.py` (ChERD Figs. 6b, 6c, 8c bitmaps), `histories.py` (binning, PCHIP smoothing, cross-checks) |
| `cfd/*_raw.json`, `out/H_histories.json`, `out/H_histories.csv` | digitised points and the six smoothed mean histories used in the runs |
| `code/hist_study.py` | history runs: nuclei (H1), cavities from the vapour pocket (H2), matching steps (H3) |
| `code/gasx_study.py`, `out/R18_gas_exchange.csv` | sensitivity to dissolution/uptake of the non-condensable gas (`Switches(gas_exchange=True)`, off by default) |
| `code/elsevier_refs.py` | Elsevier numbered reference style for the Ultrasonics Sonochemistry build |
| `code/hist_figs.py` | Section 4.7 numbers (`out/H_numbers.json`) and Figure 9 (`fig/fig10_histories.png`) |
| `code/fig9_pptx.py` | Figure 9 as an editable PowerPoint slide (`fig/Figure9_editable.pptx`): four native charts, data in each chart's embedded workbook (needs `pip install python-pptx lxml`) |
| `code/ms_numbers.py`, `code/build_ms.py`, `ms/template.md` | every number in the manuscript is generated from `out/` |
| `code/figures.py` | all figures |
| `out/*.csv`, `out/*.json` | all run outputs, including failed runs (column `error`); nothing is imputed |
| `fig/*.png` | figures at 300 dpi |

## Reproduce
```
pip install numpy scipy pandas matplotlib
cd code
python benchmarks.py           # ~1 min
python studies.py S1 S2 S3 S4  # ~2 min on 2 cores
python validation.py V1 V2 V2b # ~15 min (millimetre bubbles use BDF)
python figures.py regime deviation ladder gases solvents glycerol boundaries
python legacy_check.py
python hist_study.py H2 H3 H1  # ~5 min on 2 cores
python hist_figs.py
python fig9_pptx.py            # editable Figure 9 (PowerPoint)
python gasx_study.py           # ~1 min
python build_ms.py             # needs pandoc; Ultrasonics Sonochemistry style (python build_ms.py <name> aiche for AIChE J)
```
The digitisation scripts in `cfd/` need the two published PDFs (not redistributed) and `pip install pymupdf pillow`.

## Failure log
Runs that exceed 1.5e6 right-hand-side evaluations or exhaust the free volume are recorded as failures:
S1 1 of 1,280 (RP-T, 500 µm, 0.2 MPa, 300 Pa); S4 1 of 416 (RP-T, 40 vol% methanol, 0.3 MPa, 1 kPa).
In V1, energy-balance runs below ~0.1 Pa of gas exceed Mach 3 and fail; inversions are bracketed above that.

History runs: H1 144, H2 384, H3 416, no failures. Gas-exchange sensitivity: 144 runs, no failures.

## Digitised CFD histories: what they are and are not
- Mean pressure along cavity trajectories (average of ten trajectories), from the edge of the vapour pocket; outlet at
  1 atm, water at 22 °C. Venturi (Case 3, 2 mm throat) at PR 3.0, 4.0, 5.5; venturi with a 7.5° diffuser and with
  l/d = 3 at PR 3.0; sharp-edged orifice (l/d = 2) at PR 5.0.
- Accuracy: curves published twice agree to 1.1% RMS (venturi PR 3.0, Figs. 10b and 19) and 2.3–4.9% RMS (orifice,
  Figs. 6b, 6c, 8c). The venturi figures are traced vector graphics with a 0.12 pt grid.
- Not used: the fluctuating histories p' = p_mean + (normal random number) x rho k. Each is one random realisation,
  and on the published log axes every negative excursion is missing. The authors' raw trajectory files would allow
  both histories to be used directly and should replace the digitised curves when available.
- Not digitised: ChERD Fig. 6b at PR 2.5 and Fig. 6c at l/d = 5 (mean curve hidden under its own fluctuating trace).
