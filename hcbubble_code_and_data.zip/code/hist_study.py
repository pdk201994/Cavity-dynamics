"""S6: the eight combinations driven by the mean cavity pressure histories of device CFD
(Simpson & Ranade, ChERD 2018 orifice; AIChE J 2019 venturi), digitized in ../cfd.

H1  nucleus problem: a 10 um air nucleus in equilibrium at the inlet pressure PR * p_out passes a cosine
    contraction ramp of duration t_ramp (30, 100, 300 us) and then the mean history.
H2  cavity problem: a cavity of radius Rmax at rest at the vapour-pocket edge (start of the history) holding
    p_g0 of air, as in the step problem, driven by the mean history.
H3  step references: the same cavities under a step to (a) the work-equivalent overpressure dp_eq of the
    history collapse and (b) the outlet pressure (1 atm).
Liquid: water at the CFD temperature, 22 C (T0 = 295.15 K, p_sat = 2645 Pa); other properties as Table 2.
"""
import json, math, sys, time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import replace
import numpy as np
import pandas as pd
from hcbubble import Case, simulate, MODELS, CLOSURES, LABEL

T0, PS, PATM = 295.15, 2645.0, 101325.0
OUT = '../out/'
H = json.load(open(OUT + 'H_histories.json'))
TG = np.array(H['t'])
NAMES = ['V-PR3.0', 'V-PR4.0', 'V-PR5.5', 'V-b7.5', 'V-ld3', 'O-PR5.0']
RMAX = [50e-6, 100e-6, 200e-6, 500e-6]
PG0 = [100.0, 1000.0]
RAMPS = [30e-6, 100e-6, 300e-6]
KEEP = ['label', 'model', 'closure', 'status', 'nfev', 'pg0', 'Tmax', 't_Tmax', 'Rmax_hist', 't_Rmax', 'expansion',
        'Mach', 'n_min', 't_end', 'collapsed1', 't_c', 'Rpeak', 't_peak', 'Rmin1', 'comp1', 'Tmax1', 'Mach1', 'pinf_c',
        'dp_eq', 'reb1', 'collapsed', 'comp', 'Rreb', 'reb_ratio', 'floor_hit', 'Rmin']


def history(name, ramp=None, PR=None):
    p = np.array(H[name])
    if ramp is None:
        return TG, p
    p1 = PR * PATM
    tr = np.linspace(0.0, ramp, 301)
    pr = p[0] + (p1 - p[0]) * 0.5 * (1.0 + np.cos(np.pi * tr / ramp))
    return np.r_[tr, ramp + TG[1:]], np.r_[pr, p[1:]]


def run(job):
    tag, kw = job
    c = Case(**kw)
    t1 = time.time()
    out = dict(tag)
    try:
        r = simulate(c)
        if r['status'] < 0 or (r.get('floor_hit') and c.closure == 'T'):
            raise RuntimeError(r.get('message', 'integration failure'))
    except Exception as e:  # retry once with a stiff solver, then record the failure
        try:
            r = simulate(replace(c, method='BDF', rtol=1e-7))
            out['retry'] = 'BDF'
        except Exception as e2:
            out.update(failed=True, error=str(e2)[:200], wall=time.time() - t1)
            return out
    out.update({k: r.get(k) for k in KEEP})
    out['failed'] = bool(r['status'] < 0)
    out['wall'] = time.time() - t1
    return out


def jobs_H1():
    J = []
    for name in NAMES:
        PR = H['meta'][name]['PR']
        for ramp in RAMPS:
            hist = history(name, ramp, PR)
            for cl in CLOSURES:
                for m in MODELS:
                    J.append((dict(study='H1', hist=name, PR=PR, ramp=ramp, Rn=10e-6),
                              dict(model=m, closure=cl, history=hist, start='nucleus', Rn=10e-6, T0=T0, psat=PS)))
    return J


def jobs_H2():
    J = []
    for name in NAMES:
        hist = history(name)
        for R in RMAX:
            for pg in PG0:
                for cl in CLOSURES:
                    for m in MODELS:
                        J.append((dict(study='H2', hist=name, Rmax=R, pg0_set=pg),
                                  dict(model=m, closure=cl, history=hist, start='cavity', Rmax=R, pg0=pg, T0=T0, psat=PS)))
    return J


def jobs_H3(h2):
    J = []
    for R in RMAX:
        for pg in PG0:
            for cl in CLOSURES:
                for m in MODELS:
                    J.append((dict(study='H3out', Rmax=R, pg0_set=pg, pinf=PATM),
                              dict(model=m, closure=cl, Rmax=R, pg0=pg, pinf=PATM, T0=T0, psat=PS)))
    for _, r in h2.iterrows():
        if not r.get('collapsed1') or not np.isfinite(r.get('dp_eq', np.nan)):
            continue
        Rp = r['Rpeak']
        pgp = r['pg0_set'] * (r['Rmax'] / Rp) ** 3
        J.append((dict(study='H3eq', hist=r['hist'], Rmax=r['Rmax'], pg0_set=r['pg0_set'], Rpeak=Rp, pg_peak=pgp,
                       pinf=PS + r['dp_eq'], model_h=r['model'], closure_h=r['closure']),
                  dict(model=r['model'], closure=r['closure'], Rmax=Rp, pg0=pgp, pinf=PS + r['dp_eq'], T0=T0, psat=PS)))
    return J


def pool(J, nw=2):
    res = []
    with ProcessPoolExecutor(max_workers=nw, max_tasks_per_child=40) as ex:
        for k, r in enumerate(ex.map(run, J, chunksize=1)):
            res.append(r)
            if (k + 1) % 50 == 0:
                print(f'  {k + 1}/{len(J)}', flush=True)
    return pd.DataFrame(res)


if __name__ == '__main__':
    which = sys.argv[1:] or ['H2', 'H3', 'H1']
    if 'H2' in which:
        t1 = time.time(); d = pool(jobs_H2()); d.to_csv(OUT + 'H2_cavity.csv', index=False)
        print('H2', len(d), 'runs', d['failed'].sum(), 'failed', '%.0f s' % (time.time() - t1), flush=True)
    if 'H3' in which:
        h2 = pd.read_csv(OUT + 'H2_cavity.csv')
        t1 = time.time(); d = pool(jobs_H3(h2)); d.to_csv(OUT + 'H3_steps.csv', index=False)
        print('H3', len(d), 'runs', d['failed'].sum(), 'failed', '%.0f s' % (time.time() - t1), flush=True)
    if 'H1' in which:
        t1 = time.time(); d = pool(jobs_H1()); d.to_csv(OUT + 'H1_nucleus.csv', index=False)
        print('H1', len(d), 'runs', d['failed'].sum(), 'failed', '%.0f s' % (time.time() - t1), flush=True)
