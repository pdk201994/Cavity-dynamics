"""
Thermophysical properties used by hcbubble.

Every value is listed with its basis so that a reader can see which numbers are
property-library values, which are correlations and which are estimates.

Units: SI unless stated. Heat capacities are per molecule in units of k_B.
"""
import math
from dataclasses import dataclass, field
from scipy.optimize import brentq

KB = 1.380649e-23          # J/K
NA = 6.02214076e23         # 1/mol
RG = KB * NA               # J/(mol K)
P_ATM = 101325.0
T_REF = 298.15


def cv_mode(theta, T):
    """Heat capacity of one harmonic vibrational mode, in units of k_B."""
    x = theta / T
    if x > 300.0:
        return 0.0
    ex = math.exp(x)
    return x * x * ex / (ex - 1.0) ** 2


def e_mode(theta, T):
    """Vibrational energy of one harmonic mode above its zero-point energy, in units of k_B*K."""
    x = theta / T
    if x > 300.0:
        return 0.0
    return theta / math.expm1(x)


@dataclass
class Species:
    """A gas-phase species (non-condensable gas or solvent vapour).

    cv_tr  : translational + rotational heat capacity (k_B units): 1.5 monatomic, 2.5 linear, 3.0 non-linear
    modes  : list of (theta_vib [K], degeneracy); a mixture species carries weighted degeneracies
    lam    : thermal conductivity at 298 K [W/(m K)]
    b      : Noble-Abel co-volume [m^3/mol], b = R_g T_c / (8 p_c)
    vf     : Fuller diffusion volume [-]
    M      : molar mass [g/mol]
    """
    name: str
    M: float
    cv_tr: float
    modes: list
    lam: float
    b: float
    vf: float
    note: str = ""

    def cv(self, T):
        return self.cv_tr + sum(g * cv_mode(th, T) for th, g in self.modes)

    def e(self, T):
        return self.cv_tr * T + sum(g * e_mode(th, T) for th, g in self.modes)

    @property
    def cv298(self):
        return self.cv(T_REF)

    @property
    def kappa298(self):
        return 1.0 + 1.0 / self.cv298

    @property
    def b_molecule(self):
        return self.b / NA

    @property
    def m(self):
        return self.M * 1e-3 / NA


def b_from_critical(Tc, pc):
    return RG * Tc / (8.0 * pc)


THETA_CH, THETA_OH = 4240.0, 5300.0   # ~2950 cm-1 C-H and ~3680 cm-1 O-H stretches


def einstein_modes(n_atoms, cv298_target, n_ch=0, n_oh=0, cv_tr=3.0):
    """Group model for a polyatomic vapour: the n_ch C-H and n_oh O-H stretches sit at their
    characteristic temperatures; the remaining 3N-6-n_ch-n_oh modes share one effective
    temperature fixed so that c_v(298 K) equals the tabulated ideal-gas value.  The model is
    bounded by the classical limit at high temperature."""
    n_vib = 3 * n_atoms - 6
    n_rest = n_vib - n_ch - n_oh
    fixed = [(THETA_CH, n_ch), (THETA_OH, n_oh)]
    target = (cv298_target - cv_tr - sum(g * cv_mode(th, T_REF) for th, g in fixed)) / n_rest
    theta = brentq(lambda th: cv_mode(th, T_REF) - target, 10.0, 2.0e4)
    return [(theta, n_rest)] + [(th, g) for th, g in fixed if g > 0]


# ---------------------------------------------------------------------------------------------
# Non-condensable gases.  Vibrational temperatures: N2 3393 K, O2 2274 K, CO2 960 K (x2), 1997 K,
# 3380 K (standard spectroscopic values).  Conductivities at 298 K; critical constants from
# standard tables (Poling, Prausnitz & O'Connell).  Air = 0.79 N2 + 0.21 O2.
# ---------------------------------------------------------------------------------------------
GASES = {
    "He": Species("He", 4.0026, 1.5, [], 0.1513, b_from_critical(5.19, 0.227e6), 2.67),
    "Ne": Species("Ne", 20.180, 1.5, [], 0.0491, b_from_critical(44.4, 2.76e6), 5.98),
    "Ar": Species("Ar", 39.948, 1.5, [], 0.01775, b_from_critical(150.7, 4.86e6), 16.2),
    "Kr": Species("Kr", 83.798, 1.5, [], 0.00943, b_from_critical(209.4, 5.50e6), 24.5),
    "Xe": Species("Xe", 131.29, 1.5, [], 0.00565, b_from_critical(289.7, 5.84e6), 32.7),
    "air": Species("air", 28.97, 2.5, [(3393.0, 0.79), (2274.0, 0.21)], 0.02625,
                   0.79 * b_from_critical(126.2, 3.39e6) + 0.21 * b_from_critical(154.6, 5.04e6), 19.7),
    "CO2": Species("CO2", 44.01, 2.5, [(960.0, 2), (1997.0, 1), (3380.0, 1)], 0.01663,
                   b_from_critical(304.1, 7.38e6), 26.9),
}

# Solvent vapours.  Water: real normal modes (2295, 5255, 5400 K).  Organic vapours: Einstein model
# calibrated to the 298 K ideal-gas heat capacity of Table 2 of the original manuscript.
VAPOURS = {
    "water": Species("water", 18.015, 3.0, [(2295.0, 1), (5255.0, 1), (5400.0, 1)], 0.0186,
                     b_from_critical(647.1, 22.064e6), 13.1),
    "methanol": Species("methanol", 32.04, 3.0, einstein_modes(6, 4.30, n_ch=3, n_oh=1), 0.0145,
                        b_from_critical(512.6, 8.09e6), 15.9 + 4 * 2.31 + 6.11),
    "ethanol": Species("ethanol", 46.07, 3.0, einstein_modes(9, 6.84, n_ch=5, n_oh=1), 0.0146,
                       b_from_critical(513.9, 6.14e6), 2 * 15.9 + 6 * 2.31 + 6.11),
    "isopropanol": Species("isopropanol", 60.10, 3.0, einstein_modes(12, 9.74, n_ch=7, n_oh=1), 0.0140,
                           b_from_critical(508.3, 4.76e6), 3 * 15.9 + 8 * 2.31 + 6.11),
    "acetone": Species("acetone", 58.08, 3.0, einstein_modes(10, 7.97, n_ch=6), 0.0115,
                       b_from_critical(508.1, 4.70e6), 3 * 15.9 + 6 * 2.31 + 6.11),
    "glycerol": Species("glycerol", 92.09, 3.0, einstein_modes(14, 15.10, n_ch=5, n_oh=3), 0.0100,
                        b_from_critical(850.0, 7.50e6), 3 * 15.9 + 8 * 2.31 + 3 * 6.11),
    "octanol": Species("octanol", 130.23, 3.0, einstein_modes(27, 25.5, n_ch=17, n_oh=1), 0.0100,
                       b_from_critical(652.5, 2.86e6), 8 * 15.9 + 18 * 2.31 + 6.11),
}


def vapour_blend(y_meoh):
    """Methanol-water vapour as one pseudo-species, blended by vapour mole fraction of methanol."""
    w, m = VAPOURS["water"], VAPOURS["methanol"]
    yw = 1.0 - y_meoh
    modes = [(th, g * yw) for th, g in w.modes] + [(th, g * y_meoh) for th, g in m.modes]
    return Species(f"MeOH-water vapour (y={y_meoh:.3f})", yw * w.M + y_meoh * m.M, 3.0, modes,
                   yw * w.lam + y_meoh * m.lam, yw * w.b + y_meoh * m.b, yw * w.vf + y_meoh * m.vf)


@dataclass
class Liquid:
    """Liquid at its reference temperature T0.  Tait: (p+B)/(p0+B) = (rho/rho0)^n with
    B = rho0 c0^2 / n - p0, so the Tait sound speed equals the measured c0 for every liquid."""
    name: str
    rho0: float
    mu: float
    sigma: float
    c0: float
    psat: float
    vapour: Species
    n_tait: float
    T0: float = T_REF
    note: str = ""

    @property
    def B(self):
        return self.rho0 * self.c0 ** 2 / self.n_tait - P_ATM

    def rho(self, p):
        return self.rho0 * ((p + self.B) / (P_ATM + self.B)) ** (1.0 / self.n_tait)

    def c(self, p):
        return math.sqrt(self.n_tait * (p + self.B) / self.rho(p))


# Tait exponent: water 7.15 (Cole); organic liquids n = 1/C - 1 = 10.2 with the near-universal Tait
# constant C = 0.0894 (Dymond & Malhotra 1988); methanol-water blended linearly in volume fraction.
N_WATER, N_ORG = 7.15, 1.0 / 0.0894 - 1.0

# y_MeOH (vapour mole fraction) inferred from the blended vapour heat capacity of Table 2 of the
# original manuscript, (cv_mix - 3.04) / (4.30 - 3.04).
_MIX = {  # vol% MeOH: rho, mu[mPa s], sigma[mN/m], c, psat, cv_vap
    20: (955, 1.30, 57.0, 1545, 5698, 3.17),
    40: (913, 1.58, 46.3, 1525, 8155, 3.33),
    60: (871, 1.50, 38.5, 1452, 10572, 3.54),
    80: (828, 1.05, 31.5, 1331, 13195, 3.85),
}

LIQUIDS = {
    "water": Liquid("water", 997.0, 0.89e-3, 0.0721, 1497.0, 3170.0, VAPOURS["water"], N_WATER),
    "methanol": Liquid("methanol", 786.0, 0.544e-3, 0.0221, 1100.0, 16981.0, VAPOURS["methanol"], N_ORG),
    "ethanol": Liquid("ethanol", 785.0, 1.08e-3, 0.0219, 1142.0, 7886.0, VAPOURS["ethanol"], N_ORG),
    "isopropanol": Liquid("isopropanol", 781.0, 2.04e-3, 0.0217, 1170.0, 5800.0, VAPOURS["isopropanol"], N_ORG),
    "acetone": Liquid("acetone", 785.0, 0.306e-3, 0.0227, 1164.0, 30727.0, VAPOURS["acetone"], N_ORG),
    "glycerol": Liquid("glycerol", 1258.0, 934e-3, 0.0634, 1904.0, 0.017, VAPOURS["glycerol"], N_ORG),
    # octanol at 285 K, for the noble-gas comparison with Didenko et al. (2000); 0.02 torr = 2.67 Pa
    "octanol": Liquid("octanol (285 K)", 832.0, 11.0e-3, 0.0275, 1385.0, 2.67, VAPOURS["octanol"], N_ORG,
                      T0=285.0),
}
for v, (rho, mu, sig, c, ps, cvv) in _MIX.items():
    y = (cvv - 3.04) / (4.30 - 3.04)
    phi = v / 100.0
    LIQUIDS[f"{v}% MeOH"] = Liquid(f"{v}% MeOH", rho, mu * 1e-3, sig * 1e-3, c, ps, vapour_blend(y),
                                   (1 - phi) * N_WATER + phi * N_ORG)

LIQUID_ORDER = ["water", "20% MeOH", "40% MeOH", "60% MeOH", "80% MeOH", "methanol",
                "ethanol", "isopropanol", "acetone", "glycerol"]


def fuller_D(vap: Species, gas: Species, T=T_REF, p=P_ATM):
    """Fuller-Schettler-Giddings binary diffusivity [m^2/s]."""
    num = 1.0e-7 * T ** 1.75 * math.sqrt(1.0 / vap.M + 1.0 / gas.M)
    den = (p / P_ATM) * (vap.vf ** (1 / 3) + gas.vf ** (1 / 3)) ** 2
    return num / den


if __name__ == "__main__":
    print("gas      kappa298  cv298   lam     b[m3/mol]")
    for k, g in GASES.items():
        print(f"{k:8s} {g.kappa298:7.4f} {g.cv298:6.3f} {g.lam:7.4f} {g.b:.3e}")
    print("\nvapour       cv298   cv(2000K) cv(5000K)  theta_eff/modes   D(in air, 1 atm)")
    for k, v in VAPOURS.items():
        print(f"{k:12s} {v.cv298:6.3f} {v.cv(2000):7.3f} {v.cv(5000):7.3f}   {v.modes[:1]}   "
              f"{fuller_D(v, GASES['air']):.3e}")
    print("\nliquid        n      B[Pa]      c(1 atm)  c(1 MPa)")
    for k in LIQUID_ORDER + ["octanol"]:
        L = LIQUIDS[k]
        print(f"{k:12s} {L.n_tait:5.2f} {L.B:10.3e} {L.c(P_ATM):8.1f} {L.c(1e6):8.1f}")
