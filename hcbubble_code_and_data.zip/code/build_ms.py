"""Assemble the manuscript: fill numbers, generate tables, number citations, convert to .docx."""
import re, json, subprocess, sys
import numpy as np, pandas as pd
from properties import GASES, LIQUIDS, LIQUID_ORDER, fuller_D, T_REF
import ms_numbers
import elsevier_refs

MS = "../ms/"
REFS = {
 "gogate2005": "Gogate PR, Pandit AB. A review and assessment of hydrodynamic cavitation as a technology for the future. Ultrason Sonochem. 2005;12(1-2):21-27. doi:10.1016/j.ultsonch.2004.03.007",
 "ranade2022": "Ranade VV. Modeling of hydrodynamic cavitation reactors: reflections on present status and path forward. ACS Eng Au. 2022;2(6):461-476. doi:10.1021/acsengineeringau.2c00025",
 "zheng2022": "Zheng H, Zheng Y, Zhu J. Recent developments in hydrodynamic cavitation reactors: cavitation mechanism, reactor design, and applications. Engineering. 2022;19:180-198. doi:10.1016/j.eng.2022.04.027",
 "wang2021": "Wang B, Su H, Zhang B. Hydrodynamic cavitation as a promising route for wastewater treatment – a review. Chem Eng J. 2021;412:128685. doi:10.1016/j.cej.2021.128685",
 "dular2016": "Dular M, Griessler-Bulc T, Gutierrez-Aguirre I, et al. Use of hydrodynamic cavitation in (waste)water treatment. Ultrason Sonochem. 2016;29:577-588. doi:10.1016/j.ultsonch.2015.10.010",
 "nagarajan2021": "Nagarajan S, Ranade VV. Valorizing waste biomass via hydrodynamic cavitation and anaerobic digestion. Ind Eng Chem Res. 2021;60(46):16577-16598. doi:10.1021/acs.iecr.1c03177",
 "patil2021": "Patil A, Baral S, Dhanke P. Hydrodynamic cavitation for process intensification of biodiesel synthesis – a review. Curr Res Green Sustain Chem. 2021;4:100144. doi:10.1016/j.crgsc.2021.100144",
 "thaker2023": "Thaker AH, Ranade VV. Emulsions using a vortex-based cavitation device: influence of number of passes, pressure drop, and device scale on droplet size distributions. Ind Eng Chem Res. 2023;62(45):18837-18851. doi:10.1021/acs.iecr.2c03714",
 "tiwari2025": "Tiwari V, Swain S, Ranade VV. Enhancing nucleation using a vortex-based hydrodynamic cavitation device: application to antisolvent crystallization of paracetamol–methanol–water system. Ultrason Sonochem. 2025;123:107668. doi:10.1016/j.ultsonch.2025.107668",
 "moholkar2001": "Moholkar VS, Pandit AB. Modeling of hydrodynamic cavitation reactors: a unified approach. Chem Eng Sci. 2001;56(21-22):6295-6302. doi:10.1016/S0009-2509(01)00253-6",
 "simpson2018": "Simpson A, Ranade VV. Modelling of hydrodynamic cavitation with orifice: influence of different orifice designs. Chem Eng Res Des. 2018;136:698-711. doi:10.1016/j.cherd.2018.06.014",
 "simpson2019": "Simpson A, Ranade VV. Modeling hydrodynamic cavitation in venturi: influence of venturi configuration on inception and extent of cavitation. AIChE J. 2019;65(1):421-433. doi:10.1002/aic.16411",
 "capocelli2014": "Capocelli M, Prisciandaro M, Lancia A, Musmarra D. Hydrodynamic cavitation of p-nitrophenol: a theoretical and experimental insight. Chem Eng J. 2014;254:1-8. doi:10.1016/j.cej.2014.05.102",
 "denasri2022": "De-Nasri SJ, Sarvothaman VP, Nagarajan S, Manesiotis P, Robertson PKJ, Ranade VV. Quantifying OH radical generation in hydrodynamic cavitation via coumarin dosimetry: influence of operating parameters and cavitation devices. Ultrason Sonochem. 2022;90:106207. doi:10.1016/j.ultsonch.2022.106207",
 "rayleigh1917": "Lord Rayleigh. On the pressure developed in a liquid during the collapse of a spherical cavity. Philos Mag. 1917;34(200):94-98. doi:10.1080/14786440808635681",
 "plesset1977": "Plesset MS, Prosperetti A. Bubble dynamics and cavitation. Annu Rev Fluid Mech. 1977;9:145-185. doi:10.1146/annurev.fl.09.010177.001045",
 "keller1980": "Keller JB, Miksis M. Bubble oscillations of large amplitude. J Acoust Soc Am. 1980;68(2):628-633. doi:10.1121/1.384720",
 "gilmore1952": "Gilmore FR. The Growth or Collapse of a Spherical Bubble in a Viscous Compressible Liquid. Report 26-4. California Institute of Technology; 1952.",
 "prosperetti1986": "Prosperetti A, Lezzi A. Bubble dynamics in a compressible liquid. Part 1. First-order theory. J Fluid Mech. 1986;168:457-478. doi:10.1017/S0022112086000460",
 "denner2024": "Denner F. The Kirkwood–Bethe hypothesis for bubble dynamics, cavitation, and underwater explosions. Phys Fluids. 2024;36. doi:10.1063/5.0209167",
 "toegel2000": "Toegel R, Gompf B, Pecha R, Lohse D. Does water vapor prevent upscaling sonoluminescence? Phys Rev Lett. 2000;85(15):3165-3168. doi:10.1103/PhysRevLett.85.3165",
 "brenner2002": "Brenner MP, Hilgenfeldt S, Lohse D. Single-bubble sonoluminescence. Rev Mod Phys. 2002;74(2):425-484. doi:10.1103/RevModPhys.74.425",
 "storey2000": "Storey BD, Szeri AJ. Water vapour, sonoluminescence and sonochemistry. Proc R Soc A. 2000;456:1685-1709. doi:10.1098/rspa.2000.0582",
 "lauterborn2010": "Lauterborn W, Kurz T. Physics of bubble oscillations. Rep Prog Phys. 2010;73(10):106501. doi:10.1088/0034-4885/73/10/106501",
 "hu2014": "Hu Z, Xu J, Bigelow TA. Comparison of Gilmore-Akulichev's, Keller-Miksis's and Rayleigh-Plesset's equations on therapeutic ultrasound bubble cavitation. J Acoust Soc Am. 2014;136(4):2280. doi:10.1121/1.4900240",
 "fuster2011": "Fuster D, Dopazo C, Hauke G. Liquid compressibility effects during the collapse of a single cavitating bubble. J Acoust Soc Am. 2011;129(1):122-131. doi:10.1121/1.3502464",
 "stricker2011": "Stricker L, Prosperetti A, Lohse D. Validation of an approximate model for the thermal behavior in acoustically driven bubbles. J Acoust Soc Am. 2011;130(5):3243-3251. doi:10.1121/1.3626132",
 "kalmar2022": "Kalmár C, Turányi T, Zsély IG, Papp M, Hegedűs F. The importance of chemical mechanisms in sonochemical modelling. Ultrason Sonochem. 2022;83:105925. doi:10.1016/j.ultsonch.2022.105925",
 "dehane2023": "Dehane A, Haddad B, Merouani S, Hamdaoui O. The impact of methanol mass transport on its conversion for the production of hydrogen and oxygenated reactive species in sono-irradiated aqueous solution. Ultrason Sonochem. 2023;95:106380. doi:10.1016/j.ultsonch.2023.106380",
 "yasui2017": "Yasui K. Acoustic Cavitation and Bubble Dynamics. Springer International Publishing; 2017. doi:10.1007/978-3-319-68237-2",
 "noltingk1950": "Noltingk BE, Neppiras EA. Cavitation produced by ultrasonics. Proc Phys Soc B. 1950;63(9):674-685. doi:10.1088/0370-1301/63/9/305",
 "tinguely2012": "Tinguely M, Obreschkow D, Kobel P, Dorsaz N, de Bosset A, Farhat M. Energy partition at the collapse of spherical cavitation bubbles. Phys Rev E. 2012;86(4):046315. doi:10.1103/PhysRevE.86.046315",
 "gielen2016": "Gielen B, Marchal S, Jordens J, Thomassen LCJ, Braeken L, Van Gerven T. Influence of dissolved gases on sonochemistry and sonoluminescence in a flow reactor. Ultrason Sonochem. 2016;31:463-472. doi:10.1016/j.ultsonch.2016.02.001",
 "mcnamara1999": "McNamara WB, Didenko YT, Suslick KS. Sonoluminescence temperatures during multi-bubble cavitation. Nature. 1999;401:772-775. doi:10.1038/44536",
 "didenko2000": "Didenko YT, McNamara WB, Suslick KS. Effect of noble gases on sonoluminescence temperatures during multibubble cavitation. Phys Rev Lett. 2000;84(4):777-780. doi:10.1103/PhysRevLett.84.777",
 "suslick2008": "Suslick KS, Flannigan DJ. Inside a collapsing bubble: sonoluminescence and the conditions during cavitation. Annu Rev Phys Chem. 2008;59:659-683. doi:10.1146/annurev.physchem.59.032607.093739",
 "ashokkumar2011": "Ashokkumar M. The characterization of acoustic cavitation bubbles – an overview. Ultrason Sonochem. 2011;18(4):864-872. doi:10.1016/j.ultsonch.2010.11.016",
 "blake1987": "Blake JR, Gibson DC. Cavitation bubbles near boundaries. Annu Rev Fluid Mech. 1987;19:99-123. doi:10.1146/annurev.fl.19.010187.000531",
 "rattray1951": "Rattray M. Perturbation Effects in Cavitation Bubble Dynamics [PhD thesis]. California Institute of Technology; 1951. doi:10.7907/NJDD-ZN16",
 "reuter2022": "Reuter F, Zeng Q, Ohl CD. The Rayleigh prolongation factor at small bubble to wall stand-off distances. J Fluid Mech. 2022;944:A11. doi:10.1017/jfm.2022.475",
 "supponen2016": "Supponen O, Obreschkow D, Tinguely M, Kobel P, Dorsaz N, Farhat M. Scaling laws for jets of single cavitation bubbles. J Fluid Mech. 2016;802:263-293. doi:10.1017/jfm.2016.463",
 "ohl1998": "Ohl CD, Lindau O, Lauterborn W. Luminescence from spherically and aspherically collapsing laser induced bubbles. Phys Rev Lett. 1998;80(2):393-396. doi:10.1103/PhysRevLett.80.393",
 "brujan2005": "Brujan EA, Hecht DS, Lee F, Williams GA. Properties of luminescence from laser-created bubbles in pressurized water. Phys Rev E. 2005;72(6):066310. doi:10.1103/PhysRevE.72.066310",
 "supponen2017": "Supponen O, Obreschkow D, Kobel P, Farhat M. Luminescence from cavitation bubbles deformed in uniform pressure gradients. Phys Rev E. 2017;96(3):033114. doi:10.1103/PhysRevE.96.033114",
 "beig2018": "Beig SA, Aboulhasanzadeh B, Johnsen E. Temperatures produced by inertially collapsing bubbles near rigid surfaces. J Fluid Mech. 2018;852:105-125. doi:10.1017/jfm.2018.525",
 "fuller1966": "Fuller EN, Schettler PD, Giddings JC. A new method for prediction of binary gas-phase diffusion coefficients. Ind Eng Chem. 1966;58(5):18-27. doi:10.1021/ie50677a007",
 "poling2001": "Poling BE, Prausnitz JM, O'Connell JP. The Properties of Gases and Liquids. 5th ed. McGraw-Hill; 2001.",
 "bell2014": "Bell IH, Wronski J, Quoilin S, Lemort V. Pure and pseudo-pure fluid thermophysical property evaluation and the open-source thermophysical property library CoolProp. Ind Eng Chem Res. 2014;53(6):2498-2508. doi:10.1021/ie4033999",
 "mikhail1961": "Mikhail SZ, Kimel WR. Densities and viscosities of methanol-water mixtures. J Chem Eng Data. 1961;6(4):533-537. doi:10.1021/je60011a015",
 "vatandas2006": "Vatandas M, Koc AB, Koc C. Ultrasonic velocity measurements in ethanol–water and methanol–water mixtures. Eur Food Res Technol. 2007;225:525-532. doi:10.1007/s00217-006-0448-0",
 "vazquez1995": "Vazquez G, Alvarez E, Navaza JM. Surface tension of alcohol + water from 20 to 50 °C. J Chem Eng Data. 1995;40(3):611-614. doi:10.1021/je00019a016",
 "cole1948": "Cole RH. Underwater Explosions. Princeton University Press; 1948.",
 "dymond1988": "Dymond JH, Malhotra R. The Tait equation: 100 years on. Int J Thermophys. 1988;9(6):941-951. doi:10.1007/BF01133262",
}


def md_table(header, rows, caption, align=None):
    al = align or ([":--"] + ["--:"] * (len(header) - 1))
    out = [f"Table: {caption}", "", "| " + " | ".join(header) + " |", "|" + "|".join(al) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(x) for x in r) + " |")
    return "\n".join(out) + "\n"


def tables(N):
    T = {}
    vib = {"He": "–", "Ne": "–", "Ar": "–", "Kr": "–", "Xe": "–", "air": "3393 (N₂), 2274 (O₂)", "CO2": "960 (×2), 1997, 3380"}
    rows = []
    for k in ("He", "Ne", "Ar", "Kr", "Xe", "air", "CO2"):
        g = GASES[k]
        rows.append([{"CO2": "CO₂"}.get(k, k), f"{g.cv298:.3f}", f"{g.kappa298:.4f}", f"{g.lam:.4f}", f"{g.b*1e5:.2f}", vib[k],
                     f"{g.vf:.1f}"])
    T["TABLE1"] = md_table(["Gas", "$c_v/k_B$ (298 K)", "κ (298 K)", "λ (W m⁻¹ K⁻¹)", "$b$ (10⁻⁵ m³ mol⁻¹)",
                            "Vibrational temperatures (K)", "Fuller volume"], rows,
                           "**Table 1.** Non-condensable gases. Heat capacities from Eq. (11); co-volume $b = R_gT_c/(8p_c)$; conductivity at 298 K.")
    rows = []
    for k in LIQUID_ORDER:
        L = LIQUIDS[k]
        nm = {"water": "Water", "methanol": "Methanol", "ethanol": "Ethanol", "isopropanol": "Isopropanol",
              "acetone": "Acetone", "glycerol": "Glycerol"}.get(k, k)
        rows.append([nm,
                     f"{L.rho0:.0f}", f"{L.mu*1e3:.3g}", f"{L.sigma*1e3:.1f}", f"{L.c0:.0f}", f"{L.psat:.3g}" if L.psat < 1 else f"{L.psat:,.0f}",
                     f"{L.n_tait:.2f}", f"{L.B/1e8:.3f}", f"{L.vapour.cv298:.2f}", f"{fuller_D(L.vapour, GASES['air'])*1e5:.2f}"])
    T["TABLE2"] = md_table(["Liquid", "ρ (kg m⁻³)", "μ (mPa s)", "σ (mN m⁻¹)", "$c_0$ (m s⁻¹)", "$p_{sat}$ (Pa)", "$n$",
                            "$B$ (10⁸ Pa)", "$c_{v,vap}/k_B$ (298 K)", "$D$ in air (10⁻⁵ m² s⁻¹)"], rows,
                           "**Table 2.** Liquids at 25 °C. Mixtures in vol% methanol. $B$ from Eq. (5) with the measured $c_0$; vapor diffusivity in air at 298 K and 1 atm from the Fuller correlation.")
    bm = json.load(open("../out/benchmarks.json"))
    b1 = bm["B1_rayleigh"]
    rows = [
        ["Rayleigh collapse time, RP (1 mm, Δp = 0.1 MPa)", "Error at $p_{g0}$ = 100, 10, 1 Pa", ", ".join(f"{r['err_pct']:+.4f}%" for r in b1)],
        ["Minnaert frequency (50 and 100 µm)", "Error vs. frequency at equilibrium radius", f"{max(abs(r['err_vs_Req_pct']) for r in bm['B2_minnaert']):.3f}%"],
        ["Adiabatic energy balance, Eq. (13)", "Max. difference, Ar/air/CO₂ at two conditions", f"{max(abs(r['diff_pct']) for r in bm['B3_energy_balance']):.1f}% (viscous dissipation)"],
        ["Energy balance with transfers off, no vapor", "Max. difference from polytropic closure", "< 10⁻⁵%"],
        ["Image term, empty cavity (γ = 1.5–10)", "RP simulation vs. quadrature", f"{max(abs(r['RP_wall_pct'] - r['quad_wall_pct']) for r in bm['B4_image']['rows']):.4f} pp"],
        ["Image term vs. Rattray", "Coefficients of 1/γ and 1/γ²", f"{bm['B4_image']['first_order_coeff']:.4f}, {bm['B4_image']['second_order_coeff']:.4f} (Rattray 0.205, −0.0225)"],
        ["Tolerance, KM-T (0.3 MPa, 100 Pa)", "Change in $T_{max}$, rtol 10⁻⁷ → 10⁻¹¹", f"{100*abs(bm['B6_tolerance'][0]['Tmax']/bm['B6_tolerance'][-1]['Tmax']-1):.4f}%"],
    ]
    T["TABLE3"] = md_table(["Test", "Quantity", "Result"], rows, "**Table 3.** Verification.", align=[":--"] * 3)
    v1 = pd.read_csv("../out/V1_tinguely_inverse.csv")

    def fit(m, cl, p, R=3.5e-3, a=0.4):
        q = v1[(v1.model == m) & (v1.closure == cl) & np.isclose(v1.pinf, p) & np.isclose(v1.Rmax, R) & np.isclose(v1.alpha, a)]
        if not len(q):
            return "–"
        r = q.iloc[0]
        if np.isfinite(r.pg0_fit):
            return f"{r.pg0_fit:.2f}"
        return "not reachable" if "outside" in str(r.note) else "failed†"
    lab = {"RP": "Rayleigh–Plesset", "KM": "Keller–Miksis", "PL": "Prosperetti–Lezzi", "G": "Gilmore"}
    rows = []
    for cl in ("P", "T"):
        for m in ("RP", "KM", "PL", "G"):
            rows.append([lab[m] + (" (energy balance)" if cl == "T" else " (polytropic)"), fit(m, cl, 1e4), fit(m, cl, 3e4)])
    rows += [["Keller–Miksis-T, α = 0.04", fit("KM", "T", 1e4, a=0.04), fit("KM", "T", 3e4, a=0.04)],
             ["Keller–Miksis-T, α = 1", fit("KM", "T", 1e4, a=1.0), fit("KM", "T", 3e4, a=1.0)],
             ["Keller–Miksis-T, $R_{max}$ = 2 mm", fit("KM", "T", 1e4, R=2e-3), fit("KM", "T", 3e4, R=2e-3)],
             ["Keller–Miksis-T, $R_{max}$ = 5.6 mm", fit("KM", "T", 1e4, R=5.6e-3), fit("KM", "T", 3e4, R=5.6e-3)]]
    T["TABLE4"] = md_table(["Combination ($R_{max}$ = 3.5 mm unless stated)", "$p_{g0}$ for 0.57 at 10 kPa (Pa)", "$p_{g0}$ for 0.22 at 30 kPa (Pa)"], rows,
                           "**Table 4.** Gas pressure at maximum radius required to reproduce the rebound ratios of the two example bubbles of Tinguely et al. [ref]; their fitted range is 7.0 ± 3.5 Pa. \"Not reachable\": no plausible gas content reproduces the rebound (Rayleigh–Plesset rebounds to 0.80–0.999 of its maximum radius)." + (" †Integration failed." if any("failed†" in c for r in rows for c in r) else ""))
    rows = [
        ["Gas-dominated, fast", "Contents ≳ 95% gas (ξ ≲ 2), Pe ≳ 10", "Any; RP only for $M$ ≲ 0.05", "Polytropic acceptable", f"Closure ≤ {N['s1_clos_pg100_max']}%"],
        ["Moderate", "2 ≲ ξ ≲ 4", "Any; RP only for $M$ ≲ 0.05", "Energy balance", f"Closure {N['clos_mid_lo']}–{N['clos_mid_hi']}%"],
        ["Vapor-rich, subsonic", "ξ ≳ 4, $M$ ≲ 0.5", "KM or Gilmore (not RP)", "Energy balance with vapor exchange", f"Models < 5%; closure ×{N['clos_vr_lo']}–{N['clos_vr_hi']}"],
        ["Vapor-rich, transonic", "0.5 ≲ $M$ ≲ 1", "KM and Gilmore, report spread", "Energy balance", "Models 5–15%"],
        ["Supersonic collapse", "$M$ ≳ 1", "Gilmore; KM–PL spread as error bar", "Energy balance", f"Models up to {float(N['bin_T_M1.0-10_G_max']):.0f}% (EB), {float(N['bin_P_M1.0-10_G_max']):.0f}% (polytropic)"],
        ["Device pressure history", "Any; evaluate ξ, $M$ and Pe for a step to $\\Delta p_{eq}$, Eq. (14)", "As for that step", "As for that step", f"Step to $\\Delta p_{{eq}}$ within {N['h2_eq_P_max']}%; step to the outlet pressure ×{N['h2_over_lo']}–{N['h2_over_hi']} too hot (KM-T)"],
        ["Slow collapse", "Pe ≲ 3 (device histories)", "Any compressible; RP only for $M$ ≲ 0.05", "Energy balance, also for ξ < 2", f"Closure ×{N['h2_clos_lo']}–{N['h2_clos_hi']}; models < {float(N['h2_spread_T_max']):.0f}%"],
        ["Volatile organic solvents", "$p_{sat}$ ≳ 5 kPa", "As above", "Energy balance essential", f"Methanol quench {min(int(N[k]) for k in ('s_03_1k_quenchT','s_03_10k_quenchT','s_1_1k_quenchT','s_1_10k_quenchT'))}–{max(int(N[k]) for k in ('s_03_1k_quenchT','s_03_10k_quenchT','s_1_1k_quenchT','s_1_10k_quenchT'))}% vs. water"],
        ["Viscous liquids", "$Re$ ≲ 4", "Any (viscous collapse)", "Energy balance", "Over-damped or isothermal"],
        ["Near walls (timing)", "γ ≥ 1.5", "Any with image term", "Either", "< 1 pp vs. 2nd-order theory"],
        ["Near walls (hot spot)", "γ ≲ 3.5 (uncertain up to 7.5)", "Spherical models not adequate", "–", "Jet suppresses hot spot"],
    ]
    T["TABLE5"] = md_table(["Regime", "Criterion", "Cavity dynamic model", "Closure", "Model uncertainty in $T_{max}$"], rows,
                           "**Table 5.** Selection guide for cavity-scale models in HC reactor models.", align=[":--"] * 5)
    notation = [
        ("$A$", "cavity surface area, m²"), ("$B$", "Tait pressure constant, Pa"), ("$b$", "Noble–Abel co-volume per molecule, m³"),
        ("$C$", "local sound speed at the cavity wall (Gilmore), m s⁻¹"), ("$c$, $c_0$", "sound speed in the liquid (at $p_\\infty$, at 1 atm), m s⁻¹"),
        ("$c_v$", "heat capacity per molecule at constant volume, units of $k_B$"), ("$D$", "vapor–gas diffusivity, m² s⁻¹"),
        ("$d$", "distance from cavity center to boundary, m"), ("$e_v$, $h_v$", "internal energy and enthalpy of a vapor molecule, J"),
        ("$H$", "enthalpy difference at the cavity wall, J kg⁻¹"), ("$k_B$", "Boltzmann constant, J K⁻¹"),
        ("$M$", "maximum cavity-wall Mach number"), ("$m_v$", "mass of a vapor molecule, kg"), ("$N_g$, $N_v$", "numbers of gas and vapor molecules"),
        ("$n$", "Tait exponent"), ("$p_B$", "liquid pressure at the cavity wall, Pa"), ("$p_g$", "pressure of the cavity contents, Pa"),
        ("$p_{g0}$", "gas partial pressure at maximum radius, Pa"), ("$p_{sat}$", "saturation vapor pressure, Pa"),
        ("$p_\\infty$", "far-field (recovery) pressure, Pa"), ("$\\dot Q$", "heat flow into the cavity, W"),
        ("$R$, $R_{max}$, $R_n$", "cavity radius, maximum radius, nucleus radius, m"), ("$Re$", "Reynolds number, $R_{max}\\sqrt{\\rho\\Delta p}/\\mu$"),
        ("$T$, $T_0$", "temperature of the contents, liquid temperature, K"), ("$V$", "cavity volume, m³"),
        ("$x_v$", "vapor mole fraction in the cavity"), ("α", "accommodation coefficient"), ("γ", "stand-off $d/R_{max}$"),
        ("η", "Prosperetti–Lezzi family parameter"), ("ζ", "Kelvin-impulse anisotropy parameter"), ("κ", "ratio of specific heats at 298 K"),
        ("λ", "thermal conductivity of the contents, W m⁻¹ K⁻¹"), ("μ", "liquid viscosity, Pa s"), ("ξ", "energy-partition parameter, Eq. (12)"),
        ("ρ", "liquid density, kg m⁻³"), ("σ", "surface tension, N m⁻¹"), ("$\\sigma_b$", "boundary sign: −1 rigid wall, +1 free surface"),
        ("χ, $\\chi_0$", "thermal diffusivity of the contents (initial value), m² s⁻¹"),
        ("$\\Delta p$", "overpressure $p_\\infty - p_{sat}$, Pa"), ("$\\Delta p_{eq}$", "work-equivalent overpressure of a collapse, Eq. (14), Pa"),
        ("$k$", "turbulent kinetic energy per unit mass, J kg⁻¹"), ("$p_1$", "inlet pressure of the device, Pa"),
        ("PR", "device pressure ratio, inlet to outlet"), ("$Pe$", "thermal Péclet number, $R_{max}^2/(\\chi_0 t_{coll})$"),
        ("$t_{coll}$", "duration of the collapse, s"),
    ]
    T["NOTATION"] = md_table(["Symbol", "Meaning"], notation, "", align=[":--", ":--"]).replace("Table: \n\n", "")
    return T


def cite_numbers(text, style="uson"):
    order = []
    def repl(m):
        keys = [k.strip() for k in m.group(1).split(",")]
        nums = []
        for k in keys:
            if k not in REFS:
                raise KeyError(k)
            if k not in order:
                order.append(k)
            nums.append(order.index(k) + 1)
        nums = sorted(set(nums))
        parts, i = [], 0
        while i < len(nums):
            j = i
            while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
                j += 1
            parts.append(f"{nums[i]}–{nums[j]}" if j - i >= 2 else ",".join(str(x) for x in nums[i:j + 1]))
            i = j + 1
        if style == "aiche":
            return "^" + ",".join(parts) + "^"
        return " \\[" + ",".join(parts) + "\\]"
    text = re.sub(r"\s?\{cite:([^}]+)\}", repl, text)
    return text, order


def strip_unused_media(docx_path):
    """remove media inherited from the reference document that no relationship points to"""
    import zipfile, shutil
    with zipfile.ZipFile(docx_path) as z:
        names = z.namelist()
        rels = "".join(z.read(n).decode("utf8", "ignore") for n in names if n.endswith(".rels"))
        used = set(re.findall(r'Target="(?:\.\./)?(media/[^"]+)"', rels))
        drop = [n for n in names if n.startswith("word/media/") and n[len("word/"):] not in used]
        if not drop:
            return 0
        tmp = docx_path + ".tmp"
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in z.infolist():
                if item.filename not in drop:
                    zout.writestr(item, z.read(item.filename))
    shutil.move(tmp, docx_path)
    return len(drop)


def add_line_numbers(docx_path):
    """continuous line numbering in every section (Elsevier review copies)"""
    import zipfile, shutil, os
    tmp = docx_path + ".tmp"
    with zipfile.ZipFile(docx_path) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == "word/document.xml":
                x = data.decode("utf8")
                ln = '<w:lnNumType w:countBy="1" w:restart="continuous"/>'
                def fix(m):
                    sp = m.group(0)
                    if "lnNumType" in sp:
                        return sp
                    for anchor in ("</w:pgMar>", "<w:pgMar"):
                        pass
                    mm = re.search(r"<w:pgMar[^>]*/>", sp)
                    if mm:
                        return sp[:mm.end()] + ln + sp[mm.end():]
                    mm = re.search(r"<w:(pgNumType|cols|docGrid)", sp)
                    if mm:
                        return sp[:mm.start()] + ln + sp[mm.start():]
                    return sp.replace("</w:sectPr>", ln + "</w:sectPr>")
                x = re.sub(r"<w:sectPr[^>]*?(?:/>|>.*?</w:sectPr>)", fix, x, flags=re.S)
                data = x.encode("utf8")
            zout.writestr(item, data)
    shutil.move(tmp, docx_path)


def build(out_name="Manuscript_UltrasonSonochem_revised", style="uson"):
    N = ms_numbers.build()
    N.update(json.load(open("../out/H_numbers.json")))
    T = tables(N)
    src = open(MS + "template.md").read()
    for k, v in T.items():
        src = src.replace("{{" + k + "}}", v)
    def num(m):
        k = m.group(1)
        if k == "REFERENCES":
            return m.group(0)
        if k not in N:
            raise KeyError("missing number: " + k)
        return N[k]
    src = re.sub(r"\{\{([A-Za-z0-9_.\-]+)\}\}", num, src)
    # display equations: number kept inside the display, separated by spaces; trailing comma removed
    def eqnum(m):
        body, n = m.group(1).strip().rstrip(","), m.group(2)
        return "$$" + body + "\\qquad\\qquad\\qquad (" + n + ")$$"
    src = re.sub(r"\$\$(.+?)\s*(?:\\qquad\s*)+\((\d+)\)\$\$", eqnum, src)
    src, order = cite_numbers(src, style)
    nt = order.index("tinguely2012") + 1
    src = src.replace("[ref]", ("^%d^" % nt) if style == "aiche" else ("\\[%d\\]" % nt))
    if style == "aiche":
        refs = "\n".join(f"{i+1}. {REFS[k]}" for i, k in enumerate(order))
    else:
        orig = elsevier_refs.original_by_doi("../../ms/ms.md")
        refs = "\n\n".join("\\[%d\\] %s" % (i + 1, elsevier_refs.convert(k, REFS[k], orig)[0]) for i, k in enumerate(order))
    src = src.replace("{{REFERENCES}}", refs)
    assert "{{" not in src and "{cite:" not in src, "unfilled placeholder"
    open(MS + out_name + ".md", "w").write(src)
    unused = sorted(set(REFS) - set(order))
    print("references:", len(order), "unused:", unused)
    cmd = ["pandoc", MS + out_name + ".md", "-o", MS + out_name + ".docx", "--reference-doc", MS + "reference.docx",
           "--resource-path", MS, "-f", "markdown+superscript+tex_math_dollars+pipe_tables+simple_tables+implicit_figures+definition_lists"]
    subprocess.run(cmd, check=True)
    subprocess.run(["zip", "-d", MS + out_name + ".docx", "*/"], capture_output=True)
    print("unused media removed:", strip_unused_media(MS + out_name + ".docx"))
    if style == "uson":
        add_line_numbers(MS + out_name + ".docx")
    words = len(re.sub(r"\$[^$]*\$", " x ", src.split("# References")[0]).split())
    print("built", out_name, "words (incl. tables/notation):", words)
    return N


if __name__ == "__main__":
    build(*(sys.argv[1:3] if len(sys.argv) > 2 else []))
