"""Benchmarks and verification of hcbubble (Section 3 of the rewritten manuscript)."""
import json, math
from dataclasses import replace
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import beta
from properties import LIQUIDS, Liquid, GASES, Species, P_ATM
from hcbubble import Case, simulate, Switches

OUT = "../out/"
# an inviscid, surface-tension-free, non-volatile 'water' for analytical comparisons
LIQUIDS["ideal"] = replace(LIQUIDS["water"], name="ideal water", mu=0.0, sigma=0.0, psat=0.0)
NOHC = Switches(hard_core=False)
res = {}

# B1 Rayleigh collapse time (RP, R0 = 1 mm, dp = 0.1 MPa)
R0, dp = 1e-3, 1e5
tR = 0.914681 * R0 * math.sqrt(997.0 / dp)
b1 = []
for pg in (100.0, 10.0, 1.0):
    r = simulate(Case(model="RP", closure="P", liquid="ideal", Rmax=R0, pinf=dp + pg, pg0=pg, kappa=1.4,
                      sw=NOHC, liquid_state="fixed", rtol=1e-11))
    b1.append(dict(pg0=pg, t_sim_us=r["t_c"] * 1e6, t_analytic_us=tR * 1e6, err_pct=100 * (r["t_c"] / tR - 1)))
res["B1_rayleigh"] = b1

# B2 Minnaert frequency, release at 2% under-pressure so the cavity starts at its maximum;
#    reference frequency evaluated at the equilibrium radius R_eq = R0 * 0.98^(1/(3 kappa))
b2 = []
for R0m in (50e-6, 100e-6):
    k = 1.4
    r = simulate(Case(model="RP", closure="P", liquid="ideal", Rmax=R0m, pinf=P_ATM, pg0=0.98 * P_ATM, kappa=k,
                      sw=NOHC, liquid_state="fixed", rtol=1e-11))
    period = r["t_c"] * 2.0                      # time to the minimum is half a period
    Req = R0m * 0.98 ** (1 / (3 * k))
    f_eq = math.sqrt(3 * k * P_ATM / 997.0) / (2 * math.pi * Req)
    f_R0 = math.sqrt(3 * k * P_ATM / 997.0) / (2 * math.pi * R0m)
    b2.append(dict(R0_um=R0m * 1e6, f_sim_kHz=1e-3 / period, f_Req_kHz=f_eq * 1e-3, f_R0_kHz=f_R0 * 1e-3,
                   err_vs_Req_pct=100 * (1 / period / f_eq - 1), err_vs_R0_pct=100 * (1 / period / f_R0 - 1)))
res["B2_minnaert"] = b2


# B3 adiabatic energy balance at R_min (closed form) vs RP polytropic, 1 MPa, R0 = 25 um, 1 atm gas
def energy_balance_T(pinf, k, pg0, R0, psat, sig, T0=298.15):
    def f(x):
        vr = x ** (-1.0 / (k - 1))
        work = (pinf - psat) * (1 - vr) + 3 * sig / R0 * (1 - vr ** (2 / 3))
        return work - pg0 / (k - 1) * (x - 1)
    return T0 * brentq(f, 1.0001, 1e8)


b3 = []
for gas in ("Ar", "air", "CO2"):
    k = GASES[gas].kappa298
    for pinf, R0m, pg in ((1e6, 25e-6, 101325.0), (3e5, 100e-6, 1e3)):
        W = LIQUIDS["water"]
        r = simulate(Case(model="RP", closure="P", gas=gas, Rmax=R0m, pinf=pinf, pg0=pg, sw=NOHC,
                          liquid_state="fixed", rtol=1e-11))
        Te = energy_balance_T(pinf, k, pg, R0m, W.psat, W.sigma)
        b3.append(dict(gas=gas, pinf_MPa=pinf / 1e6, pg0=pg, T_closed_form=Te, T_RP=r["Tmax"],
                       diff_pct=100 * (r["Tmax"] / Te - 1)))
res["B3_energy_balance"] = b3

# B4 image model: empty cavity near a rigid wall / free surface, prolongation vs quadrature and Rattray
I0 = quad(lambda x: math.sqrt(x ** 3 / (1 - x ** 3)), 0, 1)[0]
c1 = 0.25 * beta(7 / 6, 0.5) / beta(5 / 6, 0.5)
c2 = (1 / 32) * beta(1.5, 0.5) / beta(5 / 6, 0.5)
b4 = []
Rb, pinf_b = 1e-3, 1e5
ref = {m: simulate(Case(model=m, closure="P", liquid="ideal", Rmax=Rb, pinf=pinf_b + 1.0, pg0=1.0, kappa=1.4,
                        sw=NOHC, rtol=1e-11))["t_c"] for m in ("RP", "KM", "G")}
for g in (1.5, 2, 3, 5, 7, 10):
    Iw = quad(lambda x: math.sqrt(x ** 3 * (1 + x / (2 * g)) / (1 - x ** 3)), 0, 1)[0]
    If = quad(lambda x: math.sqrt(x ** 3 * (1 - x / (2 * g)) / (1 - x ** 3)), 0, 1)[0]
    row = dict(gamma=g, quad_wall_pct=100 * (Iw / I0 - 1), quad_free_pct=100 * (If / I0 - 1),
               rattray1_pct=100 * 0.205 / g, rattray2_pct=100 * (0.205 / g - 0.0225 / g ** 2),
               sato_shima_pct=100 * 0.19 / g)
    for m in ("RP", "KM", "G"):
        for bnd in ("wall", "free"):
            t = simulate(Case(model=m, closure="P", liquid="ideal", Rmax=Rb, pinf=pinf_b + 1.0, pg0=1.0, kappa=1.4,
                              sw=NOHC, boundary=bnd, gamma=g, rtol=1e-11))["t_c"]
            row[f"{m}_{bnd}_pct"] = 100 * (t / ref[m] - 1)
    b4.append(row)
res["B4_image"] = dict(rows=b4, first_order_coeff=c1, second_order_coeff=-c2)

# B5 energy balance reduces to the polytropic closure when every transfer is switched off
b5 = []
LIQUIDS["dry"] = replace(LIQUIDS["water"], name="non-volatile water", psat=0.0)
for gas in ("Ar", "air"):
    for m in ("RP", "KM", "G"):
        rp = simulate(Case(model=m, closure="P", gas=gas, liquid="dry", Rmax=100e-6, pinf=3e5, pg0=1e3))
        rt = simulate(Case(model=m, closure="T", gas=gas, liquid="dry", Rmax=100e-6, pinf=3e5, pg0=1e3,
                           sw=Switches(conduction=False, transport=False, cv_T=False)))
        b5.append(dict(gas=gas, model=m, T_poly=rp["Tmax"], T_EB_adiabatic=rt["Tmax"],
                       diff_pct=100 * (rt["Tmax"] / rp["Tmax"] - 1), t_c_diff_pct=100 * (rt["t_c"] / rp["t_c"] - 1)))
res["B5_closure_limit"] = b5

# B6 tolerance study on a demanding case (KM-T, 0.3 MPa, 100 Pa gas)
b6 = []
for rt_ in (1e-7, 1e-9, 1e-11):
    r = simulate(Case(model="KM", closure="T", Rmax=100e-6, pinf=3e5, pg0=100.0, rtol=rt_))
    b6.append(dict(rtol=rt_, Tmax=r["Tmax"], t_c=r["t_c"], reb=r["reb_ratio"], Mach=r["Mach"]))
res["B6_tolerance"] = b6

json.dump(res, open(OUT + "benchmarks.json", "w"), indent=1)
for k, v in res.items():
    print("==", k)
    rows = v["rows"] if isinstance(v, dict) else v
    for row in rows:
        print({kk: (round(vv, 4) if isinstance(vv, float) else vv) for kk, vv in row.items()})
print("image-model coefficients:", round(c1, 4), round(-c2, 4))
