"""Figure 9 as an editable PowerPoint slide: four native XY charts (data in each chart's embedded workbook),
log axes, legends and text boxes, built from the same run outputs as fig/fig10_histories.png."""
import math, sys
import numpy as np
from lxml import etree
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.chart.data import XyChartData
from pptx.enum.chart import (XL_CHART_TYPE, XL_MARKER_STYLE, XL_TICK_LABEL_POSITION, XL_TICK_MARK,
                             XL_AXIS_CROSSES)
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.dml.color import RGBColor
from pptx.oxml.ns import qn
import hist_figs as HF
import figures as F

FONT = "Arial"
QA = False   # True: fill open markers so a LibreOffice preview (which drops marker outlines) shows them
MK = {"o": XL_MARKER_STYLE.CIRCLE, "s": XL_MARKER_STYLE.SQUARE, "^": XL_MARKER_STYLE.TRIANGLE,
      "D": XL_MARKER_STYLE.DIAMOND, "x": XL_MARKER_STYLE.X}
C_NS = "http://schemas.openxmlformats.org/drawingml/2006/chart"
LEG_A = {'V-PR3.0': 'Venturi, PR 3.0', 'V-PR4.0': 'Venturi, PR 4.0', 'V-PR5.5': 'Venturi, PR 5.5',
         'V-b7.5': 'Venturi 7.5°, PR 3.0', 'V-ld3': 'Venturi l/d 3, PR 3.0', 'O-PR5.0': 'Orifice, PR 5.0'}


def rgb(h):
    return RGBColor.from_string(h.lstrip("#").upper())


def cel(tag, **attrs):
    e = etree.Element(qn(tag))
    for k, v in attrs.items():
        e.set(k, str(v))
    return e


def runs_from(text):
    """'p_{sat}, 22 °C' -> [(text, baseline)] with _{...} as subscript"""
    out, i = [], 0
    for m in __import__("re").finditer(r"_\{([^}]*)\}", text):
        if m.start() > i:
            out.append((text[i:m.start()], 0))
        out.append((m.group(1), -25000))
        i = m.end()
    if i < len(text):
        out.append((text[i:], 0))
    return out


def fill_runs(paragraph, text, size, color, bold=False, italic=False):
    for t, base in runs_from(text):
        r = paragraph.add_run()
        r.text = t
        f = r.font
        f.size, f.name, f.bold, f.italic = Pt(size), FONT, bold, italic
        f.color.rgb = rgb(color)
        if base:
            r._r.get_or_add_rPr().set("baseline", str(base))


def text_box(parent, x, y, w, h, lines, size=7, color=F.INK2, bold=False, align=PP_ALIGN.LEFT,
             anchor=MSO_ANCHOR.TOP, name=None):
    """parent: the slide or a group shape (child coordinates equal slide coordinates)"""
    tb = parent.shapes.add_textbox(Emu(int(x)), Emu(int(y)), Emu(int(w)), Emu(int(h)))
    tf = tb.text_frame
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    for k, line in enumerate(lines if isinstance(lines, list) else [lines]):
        p = tf.paragraphs[0] if k == 0 else tf.add_paragraph()
        p.alignment = align
        fill_runs(p, line, size, color, bold)
    if name:
        tb.name = name
    return tb


class Panel:
    """one native XY chart with a manual inner plot area, so data coordinates can be mapped onto the slide"""

    def __init__(self, parent, name, box, series, xr, yr, logx, logy, xtitle, ytitle, plot, legend=None,
                 xfmt="General", yfmt="General", hide_x_labels=False):
        x, y, w, h = box
        cd = XyChartData(number_format="General")
        for s in series:
            ser = cd.add_series(s["name"])
            for a, b in zip(s["x"], s["y"]):
                ser.add_data_point(float(a), float(b))
        gf = parent.shapes.add_chart(XL_CHART_TYPE.XY_SCATTER_LINES, Emu(int(x)), Emu(int(y)), Emu(int(w)),
                                    Emu(int(h)), cd)
        gf.name = name
        self.gf, self.chart, self.box, self.plot = gf, gf.chart, box, plot
        self.xr, self.yr, self.logx, self.logy = xr, yr, logx, logy
        ch = self.chart
        ch.has_title = False
        ch.font.size, ch.font.name = Pt(7), FONT
        ch.font.color.rgb = rgb(F.INK2)
        for s, ser in zip(series, ch.plots[0].series):
            ser.smooth = False
            if s["kind"] == "line":
                ser.marker.style = XL_MARKER_STYLE.NONE
                ln = ser.format.line
                ln.color.rgb = rgb(s["color"])
                ln.width = Pt(s.get("lw", 1.5))
                if s.get("dash"):
                    ln.dash_style = s["dash"]
            else:
                ser.format.line.fill.background()
                m = ser.marker
                m.style, m.size = MK[s["marker"]], s.get("size", 5)
                if s.get("fill"):
                    m.format.fill.solid()
                    m.format.fill.fore_color.rgb = rgb(s["fill"])
                else:
                    m.format.fill.solid()
                    m.format.fill.fore_color.rgb = rgb(s["edge"] if QA else "#ffffff")
                m.format.line.color.rgb = rgb(s["edge"])
                m.format.line.width = Pt(s.get("ew", 0.9))
                for i, e in enumerate(s.get("pt_edge", [])):
                    pm = ser.points[i].marker
                    pm.style, pm.size = MK[s["marker"]], s.get("size", 5)
                    pm.format.fill.solid()
                    pm.format.fill.fore_color.rgb = rgb(e if QA else "#ffffff")
                    pm.format.line.color.rgb = rgb(e)
                    pm.format.line.width = Pt(s.get("ew", 0.9))
        axes = ((ch.category_axis, xr, logx, xtitle, xfmt), (ch.value_axis, yr, logy, ytitle, yfmt))
        for ax, (lo, hi), lg, title, fmt in axes:
            sc = ax._element.find(qn("c:scaling"))
            if lg:
                sc.insert(0, cel("c:logBase", val=10))
            ax.minimum_scale, ax.maximum_scale = lo, hi
            ax.has_major_gridlines = True
            ax.major_gridlines.format.line.color.rgb = rgb(F.GRID)
            ax.major_gridlines.format.line.width = Pt(0.5)
            ax.has_minor_gridlines = False
            ax.major_tick_mark, ax.minor_tick_mark = XL_TICK_MARK.OUTSIDE, XL_TICK_MARK.NONE
            ax.tick_label_position = XL_TICK_LABEL_POSITION.LOW
            ax.crosses = XL_AXIS_CROSSES.MINIMUM
            ax.format.line.color.rgb = rgb(F.AXIS)
            ax.format.line.width = Pt(0.75)
            ax.tick_labels.font.size, ax.tick_labels.font.name = Pt(7), FONT
            ax.tick_labels.font.color.rgb = rgb(F.INK2)
            ax.tick_labels.number_format, ax.tick_labels.number_format_is_linked = fmt, False
            if title:
                ax.has_title = True
                tf = ax.axis_title.text_frame
                p = tf.paragraphs[0]
                for r in list(p.runs):
                    r._r.getparent().remove(r._r)
                fill_runs(p, title, 7.5, F.INK)
        if hide_x_labels:
            ch.category_axis.tick_label_position = XL_TICK_LABEL_POSITION.NONE
            ch.category_axis.has_major_gridlines = False
        # manual inner plot area
        pa = ch._chartSpace.find(".//" + qn("c:plotArea"))
        old = pa.find(qn("c:layout"))
        if old is not None:
            pa.remove(old)
        pa.insert(0, self._layout(plot, target=True))
        # legend
        if legend:
            ch.has_legend = True
            lg = ch.legend
            lg.include_in_layout = False
            lg.font.size, lg.font.name = Pt(legend.get("size", 6.5)), FONT
            lg.font.color.rgb = rgb(F.INK2)
            le = lg._element
            pos = le.find(qn("c:legendPos"))
            for idx in sorted(legend.get("hide", []), reverse=True):
                entry = cel("c:legendEntry")
                entry.append(cel("c:idx", val=idx))
                entry.append(cel("c:delete", val=1))
                pos.addnext(entry)
            lay = le.find(qn("c:layout"))
            if lay is not None:
                le.remove(lay)
            anchor = le.findall(qn("c:legendEntry"))
            (anchor[-1] if anchor else pos).addnext(self._layout(legend["box"], target=False))
        else:
            ch.has_legend = False

    @staticmethod
    def _layout(b, target):
        x, y, w, h = b
        lay = cel("c:layout")
        ml = cel("c:manualLayout")
        if target:
            ml.append(cel("c:layoutTarget", val="inner"))
        for tag, val in (("c:xMode", "edge"), ("c:yMode", "edge"), ("c:x", x), ("c:y", y), ("c:w", w), ("c:h", h)):
            ml.append(cel(tag, val=val))
        lay.append(ml)
        return lay

    def to_slide(self, xv, yv):
        x, y, w, h = self.box
        px, py, pw, ph = self.plot
        fx = ((math.log10(xv) - math.log10(self.xr[0])) / (math.log10(self.xr[1]) - math.log10(self.xr[0]))
              if self.logx else (xv - self.xr[0]) / (self.xr[1] - self.xr[0]))
        fy = ((math.log10(yv) - math.log10(self.yr[0])) / (math.log10(self.yr[1]) - math.log10(self.yr[0]))
              if self.logy else (yv - self.yr[0]) / (self.yr[1] - self.yr[0]))
        return x + (px + pw * fx) * w, y + (py + ph * (1 - fy)) * h


def build(out):
    h1, h2, h3, H, s = HF.load()
    c = h2[h2.coll]
    IN = 914400
    prs = Presentation()
    prs.slide_width, prs.slide_height = Emu(int(6.8 * IN)), Emu(int(6.35 * IN))
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    CW, CH = 3.36 * IN, 2.95 * IN
    BOX = {"a": (0.02 * IN, 0.22 * IN, CW, CH), "b": (3.42 * IN, 0.22 * IN, CW, CH),
           "c": (0.02 * IN, 3.38 * IN, CW, CH), "d": (3.42 * IN, 3.38 * IN, CW, CH)}
    # one group per panel: chart, data-anchored labels and panel letter move and resize together
    G = {}
    for k in "abcd":
        G[k] = slide.shapes.add_group_shape()
        G[k].name = f"Panel ({k})"

    # ---- (a) mean histories and first-collapse points
    t = np.array(H["t"])
    keep = np.nonzero(t >= 1e-5)[0]
    keep = np.unique(np.r_[keep[::10], keep[-1]])
    ser = []
    for k in HF.NAMES:
        ser.append(dict(name=LEG_A[k], kind="line", x=t[keep] * 1e3, y=np.array(H[k])[keep] / 1e3,
                        color=HF.HCOL[k], lw=1.5, dash=MSO_LINE_DASH_STYLE.DASH if HF.HLS[k] == "--" else None))
    hide = []
    for lab, val in (("Outlet pressure, 1 atm", HF.PATM / 1e3), ("Vapor pressure, 22 °C", HF.PS / 1e3)):
        hide.append(len(ser))
        ser.append(dict(name=lab, kind="line", x=[0.01, 1.0], y=[val, val], color=F.MUTED, lw=0.75,
                        dash=MSO_LINE_DASH_STYLE.ROUND_DOT))
    for R, mk, lab in ((100e-6, "o", "First collapse, 100 µm (KM-T, 100 Pa)"),
                       (500e-6, "s", "First collapse, 500 µm (KM-T, 100 Pa)")):
        q = c[(c.lab == "KM-T") & np.isclose(c.Rmax, R) & np.isclose(c.pg0_set, 100.0)]
        q = q.set_index("hist").reindex([k for k in HF.NAMES if k in set(q["hist"])])
        hide.append(len(ser))
        ser.append(dict(name=lab, kind="marker", marker=mk, size=5, x=np.maximum(q.t_c.values, 1e-5) * 1e3,
                        y=q.pinf_c.values / 1e3, edge=F.INK2, pt_edge=[HF.HCOL[k] for k in q.index], ew=1.1))
    pa = Panel(G["a"], "Panel (a) chart", BOX["a"], ser, (0.01, 1.0), (1.0, 200.0), True, True,
               "Time after leaving the vapor pocket (ms)", "Mean pressure along the trajectory (kPa)",
               plot=(0.17, 0.04, 0.79, 0.80), legend=dict(box=(0.18, 0.045, 0.43, 0.29), hide=hide, size=6.0))
    x, y = pa.to_slide(0.33, HF.PATM / 1e3)
    text_box(G["a"], x, y - 0.13 * IN, 0.8 * IN, 0.12 * IN, "outlet, 1 atm", size=6.3, color=F.MUTED, name="Label outlet")
    x, y = pa.to_slide(0.0105, HF.PS / 1e3)
    text_box(G["a"], x, y + 0.02 * IN, 0.8 * IN, 0.12 * IN, "p_{sat}, 22 °C", size=6.3, color=F.MUTED, name="Label psat")

    # ---- (b) eight combinations, 500 um, 100 Pa
    q = c[np.isclose(c.Rmax, 500e-6) & np.isclose(c.pg0_set, 100.0)]
    offs = {"RP": -0.27, "KM": -0.09, "PL": 0.09, "G": 0.27}
    ser = []
    for cl, tag in (("T", "energy balance"), ("P", "polytropic")):
        for m in ("RP", "KM", "PL", "G"):
            qq = q[(q.model == m) & (q.closure == cl)]
            ser.append(dict(name=HF.LAB[(m, cl)], kind="marker", marker=F.MRK[m], size=5,
                            x=[HF.NAMES.index(k) + offs[m] for k in qq["hist"]], y=qq.Tmax1.values,
                            fill=F.COL[m] if cl == "T" else None, edge=F.COL[m], ew=0.9))
    so = h2[np.isclose(h2.Rmax, 500e-6) & np.isclose(h2.pg0_set, 100.0)]
    refs = {}
    hide = []
    for lab, dash in (("KM-T", None), ("KM", MSO_LINE_DASH_STYLE.DASH)):
        v = float(so[so.lab == lab].T_step_out.dropna().iloc[0])
        refs[lab] = v
        hide.append(len(ser))
        ser.append(dict(name=f"Step to 1 atm, {lab}", kind="line", x=[-0.5, 5.6], y=[v, v], color=F.INK2, lw=0.8, dash=dash))
    pb = Panel(G["b"], "Panel (b) chart", BOX["b"], ser, (-0.5, 5.6), (100.0, 200000.0), False, True,
               None, "Peak temperature, first collapse (K)", plot=(0.17, 0.17, 0.79, 0.62),
               legend=dict(box=(0.14, 0.0, 0.84, 0.14), hide=hide, size=6.2), yfmt="#,##0", hide_x_labels=True)
    for i, k in enumerate(HF.NAMES):
        x, y = pb.to_slide(i, 100.0)
        text_box(G["b"], x - 0.3 * IN, y + 0.05 * IN, 0.6 * IN, 0.26 * IN, HF.TICK[k].split("\n"), size=6.5,
                 color=F.INK2, align=PP_ALIGN.CENTER, name=f"Category {HF.TICK[k]}")
    for lab, xt, al in (("KM-T", 2.0, PP_ALIGN.CENTER), ("KM", 5.5, PP_ALIGN.RIGHT)):
        x, y = pb.to_slide(xt, refs[lab])
        w = 1.1 * IN
        text_box(G["b"], x - (w / 2 if al == PP_ALIGN.CENTER else w), y - 0.12 * IN, w, 0.11 * IN,
                 f"step to 1 atm, {lab}", size=6.0, color=F.INK2, align=al, name=f"Label step {lab}")
    text_box(G["b"], BOX["b"][0] + 0.25 * IN, BOX["b"][1] - 0.18 * IN, 2.6 * IN, 0.16 * IN,
             "R_{max} = 500 µm, p_{g0} = 100 Pa", size=7.5, color=F.INK, name="Subtitle (b)")

    # ---- (c) polytropic over-prediction against xi, coloured by Peclet number
    ser = []
    for lo, hi, col, lab in HF.PE_BINS:
        m = (s.Pe >= lo) & (s.Pe < hi)
        if m.any():
            ser.append(dict(name=f"step, {lab}", kind="marker", marker="o", size=3, x=s.xi[m].values,
                            y=s.clos[m].values, fill=col, edge=col, ew=0.25))
    Tw = HF.wide(c, "Tmax1")
    X = HF.wide(c, "xi_star")["KM-T"]
    Pe = HF.wide(c, "Pe")["KM-T"]
    hx, hy, hp = [], [], []
    for idx, v in Tw.iterrows():
        if np.isfinite(v.get("KM", np.nan)) and np.isfinite(v.get("KM-T", np.nan)):
            hx.append(X.loc[idx]); hy.append(v["KM"] / v["KM-T"]); hp.append(Pe.loc[idx])
    hx, hy, hp = map(np.array, (hx, hy, hp))
    for lo, hi, col, lab in HF.PE_BINS:
        m = (hp >= lo) & (hp < hi)
        if m.any():
            ser.append(dict(name=f"device history, {lab}", kind="marker", marker="D", size=5, x=hx[m], y=hy[m],
                            fill=col, edge=F.INK, ew=0.6))
    hide = [len(ser), len(ser) + 1]
    ser.append(dict(name="Agreement", kind="line", x=[0.1, 1e4], y=[1, 1], color=F.AXIS, lw=0.8))
    ser.append(dict(name="10% over-prediction", kind="line", x=[0.1, 1e4], y=[1.1, 1.1], color=F.MUTED, lw=0.6,
                    dash=MSO_LINE_DASH_STYLE.ROUND_DOT))
    xmax = 10 ** math.ceil(math.log10(max(s.xi.max(), hx.max())))
    ymax = 30.0
    ser[-2]["x"] = ser[-1]["x"] = [0.1, xmax]
    pc = Panel(G["c"], "Panel (c) chart", BOX["c"], ser, (0.1, xmax), (1.0, ymax), True, True,
               "ξ (steps: Eq. 12; histories: Δp_{eq} + 3σ/R_{max})", "Polytropic over-prediction, KM / KM-T",
               plot=(0.17, 0.17, 0.79, 0.66), legend=dict(box=(0.12, 0.0, 0.86, 0.15), hide=hide, size=6.0))

    # ---- (d) history temperature against the steps
    ser = []
    for cl in ("T", "P"):
        for m in ("RP", "KM", "PL", "G"):
            qq = c[(c.model == m) & (c.closure == cl) & np.isfinite(c.T_step_eq)]
            ser.append(dict(name=HF.LAB[(m, cl)], kind="marker", marker=F.MRK[m], size=4,
                            x=qq.T_step_eq.values, y=qq.Tmax1.values, fill=F.COL[m] if cl == "T" else None,
                            edge=F.COL[m], ew=0.7))
    qq = c[(c.lab == "KM-T") & np.isfinite(c.T_step_out)]
    ser.append(dict(name="KM-T, step to 1 atm", kind="marker", marker="x", size=4, x=qq.T_step_out.values,
                    y=qq.Tmax1.values, fill=None, edge=F.INK2, ew=0.8))
    hide = [len(ser)]
    ser.append(dict(name="1:1", kind="line", x=[100, 200000], y=[100, 200000], color=F.AXIS, lw=0.8))
    pd_ = Panel(G["d"], "Panel (d) chart", BOX["d"], ser, (100.0, 200000.0), (100.0, 200000.0), True, True,
                "Peak temperature, step to Δp_{eq} or to 1 atm (K)", "Peak temperature, device history (K)",
                plot=(0.19, 0.17, 0.77, 0.66), legend=dict(box=(0.12, 0.0, 0.86, 0.15), hide=hide, size=6.0),
                xfmt="#,##0", yfmt="#,##0")

    for k, (x, y, w, h) in BOX.items():
        text_box(G[k], x, y - 0.2 * IN, 0.3 * IN, 0.18 * IN, f"({k})", size=9.5, color=F.INK, bold=True,
                 name=f"Panel label ({k})")
    prs.core_properties.title = "Figure 9 (editable)"
    prs.core_properties.author = "D.K. Pandey, V.V. Ranade"
    prs.save(out)
    print("saved", out)


if __name__ == "__main__":
    if "--qa" in sys.argv:
        QA = True
        build("../fig/Figure9_editable_QA.pptx")
    else:
        build(sys.argv[1] if len(sys.argv) > 1 else "../fig/Figure9_editable.pptx")
