"""Sensitivity of the energy balance to dissolution/uptake of the non-condensable gas (reviewer R1.8).
Liquid saturated with air at 1 atm far from the cavity (upper bound: no depletion by earlier growth)."""
import json, time
from concurrent.futures import ProcessPoolExecutor
import numpy as np, pandas as pd
from hcbubble import Case, simulate, Switches

OUT = '../out/'
SW = Switches(gas_exchange=True)

def run(job):
    tag, kw = job
    out = dict(tag)
    try:
        r = simulate(Case(sw=SW, **kw))
        out.update(Tmax=r.get('Tmax'), Tmax1=r.get('Tmax1'), Ng_ratio=r.get('Ng_ratio'), Mach=r.get('Mach'),
                   Mach1=r.get('Mach1'), status=r['status'], collapsed=r.get('collapsed'), collapsed1=r.get('collapsed1'))
    except Exception as e:
        out.update(error=str(e)[:200])
    return out

def jobs():
    J = []
    for R in (25e-6, 100e-6, 500e-6):
        for p in (1e5, 3e5, 1e6, 2e6):
            for g in (10.0, 100.0, 1e3, 1e4):
                J.append((dict(study='step', Rmax=R, pinf=p, pg0=g, model='KM'),
                          dict(model='KM', closure='T', Rmax=R, pinf=p, pg0=g)))
    H = json.load(open(OUT + 'H_histories.json')); t = np.array(H['t'])
    for name in ['V-PR3.0', 'V-PR4.0', 'V-PR5.5', 'V-b7.5', 'V-ld3', 'O-PR5.0']:
        for R in (50e-6, 100e-6, 200e-6, 500e-6):
            for g in (100.0, 1000.0):
                for m in ('KM', 'G'):
                    J.append((dict(study='hist', hist=name, Rmax=R, pg0=g, model=m),
                              dict(model=m, closure='T', history=(t, np.array(H[name])), start='cavity', Rmax=R, pg0=g,
                                   T0=295.15, psat=2645.0)))
    return J

if __name__ == '__main__':
    t1 = time.time()
    J = jobs()
    with ProcessPoolExecutor(max_workers=2, max_tasks_per_child=40) as ex:
        res = list(ex.map(run, J, chunksize=1))
    d = pd.DataFrame(res); d.to_csv(OUT + 'R18_gas_exchange.csv', index=False)
    print('runs', len(d), 'errors', d.get('error', pd.Series(dtype=str)).notna().sum(), '%.0f s' % (time.time() - t1), flush=True)
