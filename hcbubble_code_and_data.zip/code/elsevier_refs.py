"""Elsevier (Ultrasonics Sonochemistry) numbered reference style for the REFS dictionary of build_ms.
Entries that also appear in the authors' original submission are taken from it (matched by DOI)."""
import re

ABBR = {"Ultrason": "Ultrason.", "Sonochem": "Sonochem.", "Eng": "Eng.", "Chem": "Chem.", "Res": "Res.", "Ind": "Ind.",
        "Curr": "Curr.", "Sustain": "Sustain.", "Sci": "Sci.", "Des": "Des.", "J": "J.", "Philos": "Philos.", "Mag": "Mag.",
        "Annu": "Annu.", "Rev": "Rev.", "Mech": "Mech.", "Acoust": "Acoust.", "Soc": "Soc.", "Am": "Am.", "Mod": "Mod.",
        "Phys": "Phys.", "Proc": "Proc.", "R": "R.", "Rep": "Rep.", "Prog": "Prog.", "Lett": "Lett.", "Int": "Int.",
        "Thermophys": "Thermophys.", "Eur": "Eur.", "Technol": "Technol."}

def journal(j):
    return " ".join(ABBR.get(w, w) for w in j.split())

def authors(a):
    out = []
    for tok in [x.strip() for x in a.split(",")]:
        if tok in ("et al", "et al."):
            out.append("et al.")
            continue
        if tok.startswith("Lord "):
            out.append(tok)
            continue
        parts = tok.split()
        ini, sur = parts[-1], " ".join(parts[:-1])
        if not re.fullmatch(r"[A-Z]+", ini):
            out.append(tok)
            continue
        out.append("".join(c + "." for c in ini) + " " + sur)
    s = ", ".join(out)
    return s.replace(", et al.", " et al.")

PAT = re.compile(r'^(?P<auth>.+?)\. (?P<title>.+?)[.?] (?P<jour>[^.]+?)\. (?P<year>\d{4});(?P<vol>[^:(.]+)(?:\((?P<iss>[^)]+)\))?(?::(?P<pages>[^.]+))?\.(?: doi:(?P<doi>\S+))?$')

MANUAL = {
    "gilmore1952": "F.R. Gilmore, The Growth or Collapse of a Spherical Bubble in a Viscous Compressible Liquid, Report 26-4, California Institute of Technology, Pasadena, 1952.",
    "denner2024": "F. Denner, The Kirkwood–Bethe hypothesis for bubble dynamics, cavitation, and underwater explosions, Phys. Fluids 36 (2024). https://doi.org/10.1063/5.0209167.",
    "yasui2017": "K. Yasui, Acoustic Cavitation and Bubble Dynamics, Springer International Publishing, Cham, 2017. https://doi.org/10.1007/978-3-319-68237-2.",
    "rattray1951": "M. Rattray, Perturbation Effects in Cavitation Bubble Dynamics, PhD thesis, California Institute of Technology, Pasadena, 1951. https://doi.org/10.7907/NJDD-ZN16.",
    "poling2001": "B.E. Poling, J.M. Prausnitz, J.P. O'Connell, The Properties of Gases and Liquids, 5th ed., McGraw-Hill, New York, 2001.",
    "cole1948": "R.H. Cole, Underwater Explosions, Princeton University Press, Princeton, 1948.",
    "ohl1998": "C.-D. Ohl, O. Lindau, W. Lauterborn, Luminescence from spherically and aspherically collapsing laser induced bubbles, Phys. Rev. Lett. 80 (1998) 393–396. https://doi.org/10.1103/PhysRevLett.80.393.",
    "brujan2005": "E.A. Brujan, D.S. Hecht, F. Lee, G.A. Williams, Properties of luminescence from laser-created bubbles in pressurized water, Phys. Rev. E 72 (2005) 066310. https://doi.org/10.1103/PhysRevE.72.066310.",
}

def original_by_doi(path="../../ms/ms.md"):
    s = open(path).read()
    s = s[s.rfind("# References"):]
    out = {}
    for line in s.splitlines():
        m = re.match(r"\\\[(\d+)\\\]\s+(.*)", line.strip())
        if not m:
            continue
        txt = m.group(2).replace("--", "–").replace("\\'", "'").replace("\\", "").strip()
        d = re.search(r"doi\.org/(\S+?)\.?$", txt)
        if d:
            out[d.group(1).lower()] = txt
    return out

# corrections to entries taken from the original submission
FIX = {"blake1987": [("R. Blake, D.C. Gibson", "J.R. Blake, D.C. Gibson"), ("Ann. Rev. Fluid Mech 19", "Annu. Rev. Fluid Mech. 19")]}


def convert(key, ref, orig):
    m_doi = re.search(r"doi:(\S+)$", ref)
    if m_doi and m_doi.group(1).lower() in orig:
        txt = orig[m_doi.group(1).lower()]
        for a, b in FIX.get(key, []):
            assert a in txt, (key, a)
            txt = txt.replace(a, b)
        return txt, "original"
    if key in MANUAL:
        return MANUAL[key], "manual"
    m = PAT.match(ref)
    if not m:
        return ref, "unparsed"
    title = m["title"]
    if ref[len(m["auth"]) + 2 + len(title)] == "?":
        title += "?"
    pages = (m["pages"] or "").replace("-", "–")
    s = f"{authors(m['auth'])}, {title}, {journal(m['jour'])} {m['vol'].strip()} ({m['year']})"
    s += f" {pages}." if pages else "."
    if m["doi"]:
        s += f" https://doi.org/{m['doi']}."
    return s, "converted"

if __name__ == "__main__":
    import build_ms
    orig = original_by_doi()
    for k, v in build_ms.REFS.items():
        txt, how = convert(k, v, orig)
        print(f"[{how[:4]}] {k}: {txt}")
