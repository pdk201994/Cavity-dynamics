"""V1: inverse test against Tinguely et al. (2012); V2: noble gases vs Didenko et al. (2000)."""
import sys, json, math
from dataclasses import replace
import numpy as np, pandas as pd
from scipy.optimize import brentq
from concurrent.futures import ProcessPoolExecutor
from hcbubble import Case, simulate, MODELS, CLOSURES

OUT = "../out/"
MEAS = {1e4: 0.57, 3e4: 0.22}   # R_reb/R_max of the two bubbles of Tinguely et al. (2012), Fig. 3


def reb(model, closure, R, p, g, alpha=0.4):
    kw = dict(model=model, closure=closure, Rmax=R, pinf=p, pg0=g, T0=294.05, psat=2460.0, kappa=1.4,
              alpha=alpha, rtol=1e-7 if closure == "T" else 1e-9, max_calls=600000)
    if closure != "T":
        return simulate(Case(method="LSODA", **kw))
    # the energy balance of mm bubbles is very stiff: BDF, and LSODA where BDF stalls
    # (status -1 or call limit); the two agree to within 0.1% where both complete
    try:
        r = simulate(Case(method="BDF", **kw))
        if r.get("status") != -1:
            return r
    except RuntimeError:
        pass
    return simulate(Case(method="LSODA", **kw))


def invert(args):
    model, closure, R, p, alpha = args
    target = MEAS[p]
    f = lambda lg: reb(model, closure, R, p, 10 ** lg, alpha)["reb_ratio"] - target
    out = dict(model=model, closure=closure, Rmax=R, pinf=p, alpha=alpha, target=target)
    try:
        lo, hi = (-3.0 if closure == "P" else math.log10(0.3)), 3.5   # EB: below ~0.1 Pa the collapse exceeds Mach 3 and fails
        raised = 0
        while True:   # a run at the low end of the interval that fails moves the low end up by a decade
            try:
                flo = f(lo)
                if np.isfinite(flo):
                    break
            except Exception:
                pass
            if raised == 3:
                raise RuntimeError(f"runs at the low end of the search interval failed up to {10 ** lo:g} Pa")
            lo += 1.0
            raised += 1
        fhi = f(hi)
        if not np.isfinite(fhi):
            raise RuntimeError("non-finite rebound at the high end of the search interval")
        note = f"search started at {10 ** lo:g} Pa" if raised else ""
        out.update(reb_at_lo=flo + target, reb_at_hi=fhi + target, pg_lo=10 ** lo)
        if flo * fhi > 0:
            out.update(pg0_fit=np.nan, note="target outside reachable range" + (f"; {note}" if note else ""))
        else:
            lg = brentq(f, lo, hi, xtol=1e-3)
            out.update(pg0_fit=10 ** lg, note=note)
        r7 = reb(model, closure, R, p, 7.0, alpha)
        out.update(reb_at_7Pa=r7["reb_ratio"], Mach_7Pa=r7["Mach"], Tmax_7Pa=r7["Tmax"], xv_7Pa=r7.get("xv_collapse", np.nan))
    except Exception as e:
        out.update(pg0_fit=np.nan, note=repr(e)[:120])
    return out


def noble(args):
    gas, model, closure, R, g, p = args
    try:
        r = simulate(Case(model=model, closure=closure, gas=gas, liquid="octanol", Rmax=R, pinf=p, pg0=g))
        return dict(gas=gas, model=model, closure=closure, Rmax=R, pg0=g, pinf=p, Tmax=r["Tmax"], Mach=r["Mach"],
                    collapsed=r["collapsed"], error="")
    except Exception as e:
        return dict(gas=gas, model=model, closure=closure, Rmax=R, pg0=g, pinf=p, Tmax=np.nan, Mach=np.nan,
                    collapsed=False, error=repr(e)[:100])


if __name__ == "__main__":
    which = sys.argv[1:] or ["V1", "V2"]
    if "V1" in which:
        jobs = [(m, cl, 3.5e-3, p, 0.4) for p in MEAS for cl in CLOSURES for m in MODELS]
        jobs += [("KM", "T", R, p, 0.4) for p in MEAS for R in (2e-3, 5.6e-3)]
        jobs += [("KM", "T", 3.5e-3, p, a) for p in MEAS for a in (0.04, 1.0)]
        with ProcessPoolExecutor(2) as ex:
            rows = list(ex.map(invert, jobs))
        df = pd.DataFrame(rows); df.to_csv(OUT + "V1_tinguely_inverse.csv", index=False)
        print(df[["model", "closure", "Rmax", "pinf", "alpha", "target", "pg0_fit", "reb_at_7Pa", "reb_at_lo", "Mach_7Pa", "xv_7Pa", "note"]].round(4).to_string())

    if "V2" in which:
        from properties import LIQUIDS
        L = LIQUIDS["octanol"]
        jobs = []
        for R in (25e-6, 50e-6, 100e-6):
            for g in (30.0, 100.0, 300.0):
                for p in np.geomspace(2e4, 2e6, 25):
                    if g + L.psat - 2 * L.sigma / R >= p:
                        continue
                    for gas in ("He", "Ne", "Ar", "Kr", "Xe"):
                        for cl in CLOSURES:
                            jobs.append((gas, "KM", cl, R, g, float(p)))
                            if np.isclose(R, 50e-6) and np.isclose(g, 100.0):
                                jobs.append((gas, "G", cl, R, g, float(p)))
        with ProcessPoolExecutor(2) as ex:
            rows = list(ex.map(noble, jobs, chunksize=8))
        df = pd.DataFrame(rows); df.to_csv(OUT + "V2_noble.csv", index=False)
        print("V2:", len(df), "runs; errors", (df.error != "").sum())


def noble_b(args):
    gas, closure, R, p, g = args
    try:
        r = simulate(Case(model="KM", closure=closure, gas=gas, liquid="octanol", Rmax=R, pinf=p, pg0=g))
        return dict(gas=gas, closure=closure, Rmax=R, pinf=p, pg0=g, Tmax=r["Tmax"], Mach=r["Mach"], error="")
    except Exception as e:
        return dict(gas=gas, closure=closure, Rmax=R, pinf=p, pg0=g, Tmax=np.nan, Mach=np.nan, error=repr(e)[:100])


if __name__ == "__main__" and "V2b" in sys.argv[1:]:
    from properties import LIQUIDS
    L = LIQUIDS["octanol"]
    jobs = [(gas, cl, R, p, float(g)) for R in (25e-6, 50e-6, 100e-6) for p in (1e5, 2e5, 5e5)
            for g in np.geomspace(30, 3e4, 25) for gas in ("He", "Ne", "Ar", "Kr", "Xe") for cl in CLOSURES
            if g + L.psat - 2 * L.sigma / R < p]
    with ProcessPoolExecutor(2) as ex:
        rows = list(ex.map(noble_b, jobs, chunksize=8))
    df = pd.DataFrame(rows); df.to_csv(OUT + "V2b_noble_pg0scan.csv", index=False)
    print("V2b:", len(df), "runs; errors", (df.error != "").sum())
