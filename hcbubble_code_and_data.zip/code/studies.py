"""Run the studies of the rewritten manuscript and write one CSV per study to ../out/."""
import sys, time, math, json
from dataclasses import replace, asdict
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
import pandas as pd
from properties import LIQUIDS, GASES, LIQUID_ORDER, P_ATM
from hcbubble import Case, simulate, Switches, MODELS, CLOSURES, xi_tinguely

OUT = "../out/"
KEYS = ["label", "model", "closure", "gas", "liquid", "Rmax", "pinf", "pg0", "psat", "T0", "boundary", "gamma",
        "collapsed", "t_c", "Rmin", "comp", "Umax", "Mach", "Tmax", "xv_collapse", "Nv_ratio", "Rreb", "reb_ratio",
        "c_inf", "status", "floor_hit", "nfev"]


def _run(args):
    tag, case = args
    t0 = time.time()
    try:
        r = simulate(case)
        row = {k: r.get(k, np.nan) for k in KEYS}
        row["error"] = ""
    except Exception as e:  # recorded, never imputed
        row = {k: getattr(case, k, np.nan) if hasattr(case, k) else np.nan for k in KEYS}
        row.update(label=f"{case.model}/{case.closure}", collapsed=False, error=repr(e)[:200])
    row["tag"] = tag
    row["sw"] = json.dumps(asdict(case.sw))
    row["alpha"] = case.alpha
    row["runtime_s"] = time.time() - t0
    return row


def run(cases, name):
    t0 = time.time()
    rows = []
    with ProcessPoolExecutor(max_workers=2, max_tasks_per_child=50) as ex:
        futs = {ex.submit(_run, c): c for c in cases}
        for f in as_completed(futs):
            try:
                rows.append(f.result())
            except Exception as e:      # a worker died: record the case as failed, never impute
                tag, case = futs[f]
                row = {k: getattr(case, k, np.nan) for k in KEYS if hasattr(case, k)}
                row.update(tag=tag, label=f"{case.model}/{case.closure}", collapsed=False, error="worker died: " + repr(e)[:150])
                rows.append(row)
    df = pd.DataFrame(rows)
    df.to_csv(OUT + f"{name}.csv", index=False)
    nerr = (df["error"] != "").sum()
    print(f"{name}: {len(df)} runs in {time.time()-t0:.0f}s, errors={nerr}, not collapsed={(~df['collapsed'].astype(bool)).sum()}",
          flush=True)
    return df


def combos(base, tag):
    return [(tag, replace(base, model=m, closure=c)) for c in CLOSURES for m in MODELS]


def collapses(liquid, Rmax, pinf, pg0):
    L = LIQUIDS[liquid]
    return pg0 + L.psat - 2 * L.sigma / Rmax < pinf


if __name__ == "__main__":
    which = sys.argv[1:] or ["S1", "S2", "S3", "S4", "V1", "V2"]
    PINF = [1e5, 2e5, 3e5, 5e5, 1e6, 2e6]
    PG0 = [10, 30, 100, 300, 1e3, 3e3, 1e4, 3e4, 1e5]

    if "S1" in which:   # regime map: water, air
        cases = []
        for R in (25e-6, 100e-6, 500e-6):
            for p in PINF:
                for g in PG0:
                    if collapses("water", R, p, g):
                        cases += combos(Case(Rmax=R, pinf=p, pg0=float(g)), "S1")
        run(cases, "S1_regime_map")

    if "S2" in which:   # cavity contents
        cases = []
        for p in (3e5, 1e6):
            for g in (1e3, 1e4):
                for gas in ("He", "Ne", "Ar", "Kr", "Xe", "air", "CO2"):
                    cases += combos(Case(gas=gas, Rmax=100e-6, pinf=p, pg0=g), "S2")
                    if gas in ("air", "CO2", "Ar"):
                        for m in MODELS:   # energy balance with heat capacities frozen at 298 K
                            cases.append(("S2_cv298", Case(model=m, closure="T", gas=gas, Rmax=100e-6, pinf=p, pg0=g,
                                                            sw=Switches(cv_T=False))))
        for gas in ("Ar", "air", "CO2"):   # the original manuscript's condition, for continuity
            cases += combos(Case(gas=gas, Rmax=25e-6, pinf=1e6, pg0=101325.0), "S2_original")
        # closure ladder: which mechanism of the energy balance does what (air and CO2, water)
        ladder = {"adiabatic_frozen": Switches(conduction=False, transport=False, cv_T=False),
                  "+cv(T)": Switches(conduction=False, transport=False, cv_T=True),
                  "+conduction": Switches(conduction=True, transport=False, cv_T=True),
                  "+vapour transport (full)": Switches()}
        for gas in ("air", "CO2", "Ar"):
            for p, g in ((3e5, 1e3), (3e5, 1e4), (1e6, 1e3)):
                for nm, s in ladder.items():
                    cases.append((f"ladder:{nm}", Case(model="KM", closure="T", gas=gas, Rmax=100e-6, pinf=p, pg0=g, sw=s)))
                cases.append(("ladder:polytropic", Case(model="KM", closure="P", gas=gas, Rmax=100e-6, pinf=p, pg0=g)))
        run(cases, "S2_contents")

    if "S3" in which:   # boundaries (timing)
        cases = []
        base = Case(Rmax=100e-6, pinf=3e5, pg0=1e3)
        cases += combos(base, "S3_unbounded")
        for bnd in ("wall", "free"):
            for gm in (1.5, 2, 3, 5, 7, 10):
                cases += combos(replace(base, boundary=bnd, gamma=gm), "S3")
        run(cases, "S3_boundaries")

    if "S4" in which:   # solvents
        cases = []
        for liq in LIQUID_ORDER:
            for p in (3e5, 1e6):
                for g in (1e3, 1e4):
                    if collapses(liq, 100e-6, p, g):
                        cases += combos(Case(liquid=liq, Rmax=100e-6, pinf=p, pg0=g), "S4")
        for liq in ("methanol", "acetone", "ethanol"):   # Gilmore with water's Tait constants (original manuscript)
            for p in (3e5, 1e6):
                for g in (1e3, 1e4):
                    for cl in CLOSURES:
                        cases.append(("S4_water_tait", Case(model="G", closure=cl, liquid=liq, Rmax=100e-6, pinf=p, pg0=g,
                                                             B_fixed=3.046e8)))
        for R in (25e-6, 50e-6, 100e-6, 200e-6, 500e-6, 1000e-6):   # glycerol size sweep
            for p in (1e5, 3e5, 1e6):
                for g in (1e3, 1e4):
                    if collapses("glycerol", R, p, g):
                        for cl in CLOSURES:
                            cases.append(("S4_glycerol", Case(model="KM", closure=cl, liquid="glycerol", Rmax=R, pinf=p, pg0=g)))
        run(cases, "S4_solvents")

    if "V1" in which:   # Tinguely et al. (2012): rebound of mm-sized bubbles in microgravity
        cases = []
        for R in (2e-3, 3.5e-3, 5.6e-3):
            for p in (1e4, 3e4):
                for g in (3.5, 7.0, 10.5):
                    for a in (0.04, 0.4, 1.0):
                        for m in MODELS:
                            for cl in CLOSURES:
                                if cl == "P" and a != 0.4:
                                    continue
                                cases.append(("V1", Case(model=m, closure=cl, Rmax=R, pinf=p, pg0=g, T0=294.05, psat=2460.0,
                                                         kappa=1.4, alpha=a)))
        run(cases, "V1_tinguely")

    if "V2" in which:   # Didenko et al. (2000): noble gases in octanol at 285 K
        cases = []
        for R in (25e-6, 50e-6, 100e-6):
            for g in (30.0, 100.0, 300.0):
                for p in np.geomspace(2e4, 2e6, 41):
                    for gas in ("He", "Ne", "Ar", "Kr", "Xe"):
                        for m in ("KM", "G"):
                            for cl in CLOSURES:
                                if collapses("octanol", R, p, g):
                                    cases.append(("V2", Case(model=m, closure=cl, gas=gas, liquid="octanol", Rmax=R,
                                                             pinf=float(p), pg0=g)))
        run(cases, "V2_noble")
