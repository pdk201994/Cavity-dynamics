"""
hcbubble - reduced-order models for the collapse of a single cavity in hydrodynamic cavitation.

Cavity dynamic models (liquid side)
    RP   Rayleigh-Plesset (incompressible)
    KM   Keller-Miksis (first order in the cavity-wall Mach number)
    PL   Prosperetti-Lezzi family member eta = 1/2 (same order as KM)
    G    Gilmore (Kirkwood-Bethe hypothesis, Tait equation of state)
Closures (cavity side)
    P    polytropic: non-condensable gas compressed adiabatically with kappa = c_p/c_v at 298 K,
         vapour held at its saturation pressure (instantaneous phase equilibrium)
    T    Toegel-type energy balance: conduction across a thermal boundary layer, finite-rate vapour
         exchange (Stefan diffusion through a vapour boundary layer in series with Hertz-Knudsen
         interfacial resistance), temperature-dependent heat capacities

Both closures use the same initial state (vapour at p_sat(T0), gas at p_g0, both at T0) and the same
Noble-Abel co-volume for the gas; the energy balance also gives the vapour molecules a co-volume.
No stopping rule on |Rdot|: integration ends at the first rebound maximum (step problems) or at the end
of the pressure history; the cavity-wall Mach number is reported so validity can be judged a posteriori.
"""
import math
from dataclasses import dataclass, field, replace
import numpy as np
from scipy.integrate import solve_ivp
from properties import KB, NA, P_ATM, T_REF, GASES, LIQUIDS, VAPOURS, fuller_D, Species, Liquid

MODELS = ("RP", "KM", "PL", "G")
CLOSURES = ("P", "T")
LABEL = {("RP", "P"): "RP", ("KM", "P"): "KM", ("PL", "P"): "PL", ("G", "P"): "Gilmore",
         ("RP", "T"): "RP-T", ("KM", "T"): "KM-T", ("PL", "T"): "PL-T", ("G", "T"): "Gilmore-T"}


@dataclass
class Switches:
    conduction: bool = True      # heat conduction to the liquid
    transport: bool = True       # vapour evaporation / condensation
    cv_T: bool = True            # temperature-dependent (vibrational) heat capacities
    kinetic: bool = True         # Hertz-Knudsen interfacial resistance in series with diffusion
    stefan: bool = True          # log-mean (Stefan) correction for vapour-rich contents
    vapour_covolume: bool = True # vapour molecules occupy co-volume in the energy balance
    hard_core: bool = True       # Noble-Abel co-volume for the gas (both closures)
    gas_exchange: bool = False   # energy balance only: dissolution/uptake of the non-condensable gas through a
                                 # liquid-side diffusion layer (Henry's law at the wall); off for every result
                                 # in the paper except the sensitivity test of Section 2.3


@dataclass
class Case:
    model: str = "KM"
    closure: str = "T"
    gas: str = "air"
    liquid: str = "water"
    Rmax: float = 100e-6          # initial radius for step problems (cavity at rest = maximum radius)
    pinf: float = 3e5             # constant far-field (recovery) pressure for step problems [Pa abs]
    pg0: float = 1e3              # non-condensable gas pressure at Rmax [Pa]
    boundary: str = None          # None, "wall", "free"
    gamma: float = None           # stand-off d / Rmax
    history: tuple = None         # (t_array, p_array) far-field pressure history [s, Pa abs]
    Rn: float = None              # nucleus radius for pressure-history problems [m]
    H_gas: float = 7.8e-6         # Henry solubility of the gas in the liquid [mol m-3 Pa-1] (air in water, 25 C)
    D_liq: float = 2.0e-9         # diffusivity of the dissolved gas in the liquid [m2 s-1]
    p_gas_sat: float = 101325.0   # partial pressure of gas with which the liquid is saturated far away [Pa]
    start: str = "nucleus"        # history problems: "nucleus" (Rn in equilibrium with p(0)) or
                                  # "cavity" (Rmax at rest holding pg0, as in the step problem)
    alpha: float = 0.4            # mass accommodation coefficient (Hertz-Knudsen)
    eta: float = 0.5              # Prosperetti-Lezzi family parameter for model "PL"
    kappa: float = None           # override polytropic exponent
    T0: float = None              # override liquid temperature
    psat: float = None            # override saturation pressure
    sw: Switches = field(default_factory=Switches)
    liquid_state: str = "tait"    # "tait": rho, c of the liquid at p_inf from Tait; "fixed": 1 atm values
    B_fixed: float = None         # override Tait B (e.g. Cole's 3.046e8 Pa for the legacy check)
    rtol: float = 1e-9
    t_end: float = None
    keep: bool = False            # keep the trajectory (dense output)
    max_calls: int = 1500000      # work limit per run; exceeding it is recorded as a failure
    method: str = "LSODA"         # integrator (LSODA; BDF or Radau for very stiff vapour-dominated cases)


def _history_fn(t_arr, p_arr):
    """C1 monotone (PCHIP) interpolant of the far-field history with its exact derivative, so that the
    pressure and dp/dt seen by the compressible models are consistent and continuous."""
    import bisect
    from scipy.interpolate import PchipInterpolator
    t_arr = np.asarray(t_arr, float)
    p_arr = np.asarray(p_arr, float)
    P = PchipInterpolator(t_arr, p_arr, extrapolate=False)
    c3, c2, c1, c0 = (P.c[k].tolist() for k in range(4))
    xl = P.x.tolist()
    n = len(xl) - 1
    ta, tb, pa, pb = xl[0], xl[-1], float(p_arr[0]), float(p_arr[-1])

    def f(t):
        if t <= ta:
            return pa, 0.0
        if t >= tb:
            return pb, 0.0
        i = min(bisect.bisect_right(xl, t) - 1, n - 1)
        h = t - xl[i]
        a3, a2, a1, a0 = c3[i], c2[i], c1[i], c0[i]
        return ((a3 * h + a2) * h + a1) * h + a0, (3.0 * a3 * h + 2.0 * a2) * h + a1
    return f


def simulate(case: Case):
    L: Liquid = LIQUIDS[case.liquid]
    G: Species = GASES[case.gas] if isinstance(case.gas, str) else case.gas
    Vp: Species = L.vapour
    sw = case.sw
    T0 = case.T0 if case.T0 is not None else L.T0
    psat = case.psat if case.psat is not None else L.psat
    sig, mu = L.sigma, L.mu
    n_t = L.n_tait
    B_t = case.B_fixed if case.B_fixed is not None else L.B
    rho_ref = L.rho0

    def rho_of(p):
        return rho_ref * ((p + B_t) / (P_ATM + B_t)) ** (1.0 / n_t)

    def liquid_state(p):
        if case.liquid_state == "fixed":
            return L.rho0, L.c0
        r = rho_of(p)
        return r, math.sqrt(n_t * (p + B_t) / r)

    # far-field pressure
    if case.history is not None:
        pfun = _history_fn(*case.history)
        p_start = pfun(case.history[0][0])[0]
    else:
        pfun = None
        p_start = case.pinf

    # initial state
    if case.history is not None and case.start == "nucleus":
        R0 = case.Rn
        pg0 = p_start + 2 * sig / R0 - psat
        if pg0 <= 0:
            raise ValueError("nucleus not in equilibrium: p + 2 sigma/R - p_sat <= 0")
    else:
        R0 = case.Rmax
        pg0 = case.pg0
    V0 = 4.0 / 3.0 * math.pi * R0 ** 3
    bg = G.b_molecule if sw.hard_core else 0.0
    bv = Vp.b_molecule if (sw.hard_core and sw.vapour_covolume) else 0.0
    a0 = KB * T0
    q = (pg0 * bg + psat * bv) / a0
    Vex0 = V0 * q / (1.0 + q)
    Ng = pg0 * (V0 - Vex0) / a0
    Nv0 = psat * (V0 - Vex0) / a0 if case.closure == "T" else 0.0
    kappa = case.kappa if case.kappa is not None else G.kappa298
    Vexg = Ng * bg
    Vg0 = V0 - Vexg

    # property helpers for the energy balance
    if sw.cv_T:
        cvg, cvv, ev = G.cv, Vp.cv, Vp.e
    else:
        cg, cvv0 = G.cv298, Vp.cv298
        cvg = lambda T: cg
        cvv = lambda T: cvv0
        ev = lambda T: cvv0 * T
    D_ref = fuller_D(Vp, G, T_REF, P_ATM)
    Rk = math.sqrt(2 * math.pi * Vp.m * KB * T0) / case.alpha if sw.kinetic else 0.0
    enth_in = ev(T0) + T0              # enthalpy (k_B K) of a vapour molecule crossing the interface

    # image boundary
    sb = {None: 0.0, "wall": -1.0, "free": 1.0}[case.boundary]
    s_img = sb / (2.0 * case.gamma * R0) if sb != 0.0 else 0.0

    model, eta = case.model, (0.0 if case.model == "KM" else case.eta)
    four_pi = 4.0 * math.pi

    # scaling
    dp_ref = max(abs(p_start - psat), 1e3) if case.history is None else 1e5
    U_ref = math.sqrt(dp_ref / L.rho0)
    t_ref = R0 / U_ref if case.history is None else 1e-6
    N_ref = max(Ng + Nv0, 1.0)

    gasx = case.closure == "T" and sw.gas_exchange
    c_inf_gas = case.H_gas * case.p_gas_sat * 6.02214076e23     # molecules per m3 far from the cavity
    H_mol = case.H_gas * 6.02214076e23                           # molecules m-3 Pa-1
    eg = G.e if sw.cv_T else (lambda T: G.cv298 * T)
    enth_g_in = eg(T0) + T0

    def closure_state(R, U, Nv, T, Ngc=None):
        """returns p_g, dp_g/dt (no Rddot dependence), dNv/dt, dT/dt, T, dNg/dt"""
        if Ngc is None:
            Ngc = Ng
        V = four_pi / 3.0 * R ** 3
        Vdot = four_pi * R * R * U
        if case.closure == "P":
            Vf = V - Vexg
            ratio = Vg0 / Vf
            pgas = pg0 * ratio ** kappa
            return pgas + psat, -kappa * pgas * Vdot / Vf, 0.0, 0.0, T0 * ratio ** (kappa - 1.0), 0.0
        N = Ngc + Nv
        Vf = V - (Ngc * bg + Nv * bv)
        pg = N * KB * T / Vf
        xv = Nv / N
        xg = 1.0 - xv
        Tf = 0.5 * (T + T0)
        aU = abs(U)
        cg_T, cv_T = cvg(T), cvv(T)
        Qdot = 0.0
        if sw.conduction:
            lam = (xg * G.lam + xv * Vp.lam) * (Tf / T_REF) ** 0.7
            cp_mol = xg * cg_T + xv * cv_T + 1.0
            chi = lam * V / (N * KB * cp_mol)
            lth = R / math.pi
            if aU > 0.0:
                lth = min(math.sqrt(chi * R / aU), lth)
            Qdot = four_pi * R * R * lam * (T0 - T) / lth
        Nvdot = 0.0
        if sw.transport:
            D = D_ref * (Tf / T_REF) ** 1.75 * (P_ATM / pg)
            ld = R / math.pi
            if aU > 0.0:
                ld = min(math.sqrt(D * R / aU), ld)
            lm = 1.0
            if sw.stefan:
                aw = max(1.0 - min(psat / pg, 1.0 - 1e-12), 1e-12)
                ab = max(1.0 - xv, 1e-12)
                lm = aw if abs(aw - ab) < 1e-12 * aw else (aw - ab) / math.log(aw / ab)
            Rd = ld * KB * Tf * lm / D
            J = (psat - xv * pg) / (Rd + Rk)
            Nvdot = four_pi * R * R * J
        Ngdot = 0.0
        if gasx:
            ll = R
            if aU > 0.0:
                ll = min(math.sqrt(case.D_liq * R / aU), ll)
            Ngdot = four_pi * R * R * case.D_liq * (c_inf_gas - H_mol * xg * pg) / ll
        Cv = Ngc * cg_T + Nv * cv_T
        Tdot = (-pg * Vdot + Qdot + KB * (enth_in - ev(T)) * Nvdot + KB * (enth_g_in - eg(T)) * Ngdot) / (KB * Cv)
        dpg = pg * ((Nvdot + Ngdot) / N + Tdot / T - (Vdot - bv * Nvdot - bg * Ngdot) / Vf)
        return pg, dpg, Nvdot, Tdot, T, Ngdot

    def rhs_dim(t, R, U, Nv, T, Ngc=None):
        if pfun is None:
            pinf, dpinf = case.pinf, 0.0
        else:
            pinf, dpinf = pfun(t)
        rho, c = liquid_state(pinf)
        pg, dpg, Nvdot, Tdot, _, Ngdot = closure_state(R, U, Nv, T, Ngc)
        pB = pg - 2 * sig / R - 4 * mu * U / R
        A = dpg + 2 * sig * U / R ** 2 + 4 * mu * U * U / R ** 2
        img = 2.0 * s_img * R * U * U
        if model == "RP":
            Rdd = ((pB - pinf) / rho - 1.5 * U * U + img) / (R - s_img * R * R)
        elif model in ("KM", "PL"):
            num = (1 + (1 - eta) * U / c) * (pB - pinf) / rho + R / (rho * c) * (A - dpinf) \
                  - 1.5 * (1 - (3 * eta + 1) * U / (3 * c)) * U * U + img
            den = (1 - (eta + 1) * U / c) * R + 4 * mu / (rho * c) - s_img * R * R
            Rdd = num / den
        else:  # Gilmore
            ratio = (pB + B_t) / (pinf + B_t)
            rho_inf = rho_of(pinf)
            H = n_t / (n_t - 1) * (pinf + B_t) / rho_inf * (ratio ** ((n_t - 1) / n_t) - 1)
            rhoB = rho_inf * ratio ** (1.0 / n_t)
            C = math.sqrt(n_t * (pB + B_t) / rhoB)
            num = (1 + U / C) * H + (1 - U / C) * (R / C) * (A / rhoB - dpinf / rho_inf) \
                  - 1.5 * (1 - U / (3 * C)) * U * U + img
            den = (1 - U / C) * (R + 4 * mu / (C * rhoB)) - s_img * R * R
            Rdd = num / den
        return Rdd, Nvdot, Tdot, pg, c, Ngdot

    calls = [0]

    def rhs(tau, y):
        calls[0] += 1
        if calls[0] > case.max_calls:
            raise RuntimeError(f"exceeded {case.max_calls} right-hand-side evaluations")
        R = y[0] * R0
        U = y[1] * U_ref
        Ngc = None
        if case.closure == "T":
            Nv = y[2] * N_ref
            T = y[3] * T0
            if gasx:
                Ngc = y[4] * N_ref
        else:
            Nv, T = 0.0, T0
        Rdd, Nvdot, Tdot, _, _, Ngdot = rhs_dim(tau * t_ref, R, U, Nv, T, Ngc)
        out = [U / R0 * t_ref, Rdd / U_ref * t_ref]
        if case.closure == "T":
            out += [Nvdot / N_ref * t_ref, Tdot / T0 * t_ref]
            if gasx:
                out += [Ngdot / N_ref * t_ref]
        return out

    y0 = [1.0, -1e-9]
    if case.closure == "T":
        y0 += [Nv0 / N_ref, 1.0]
        if gasx:
            y0 += [Ng / N_ref]

    def ev_min(tau, y):
        return y[1]
    ev_min.direction = 1

    def ev_max(tau, y):
        return y[1]
    ev_max.direction = -1
    ev_max.terminal = case.history is None

    def ev_floor(tau, y):          # free volume (hard core) exhausted or radius collapsed
        R = y[0] * R0
        V = four_pi / 3 * R ** 3
        Nv = y[2] * N_ref if case.closure == "T" else 0.0
        Ngc = y[4] * N_ref if gasx else Ng
        Vex = Ngc * bg + Nv * bv
        return (V - Vex) / V - 1e-7 if Vex > 0 else y[0] - 1e-6
    ev_floor.terminal = True

    if case.history is not None:
        t_end = case.t_end if case.t_end is not None else case.history[0][-1]
    else:
        t_end = case.t_end if case.t_end is not None else 40.0 * 0.914681 * R0 * math.sqrt(L.rho0 / max(case.pinf - psat, 1.0))
    sol = solve_ivp(rhs, [0.0, t_end / t_ref], y0, method=case.method, events=[ev_min, ev_max, ev_floor],
                    rtol=case.rtol, atol=1e-12, dense_output=case.keep,
                    max_step=(t_end / t_ref) / (2000 if case.history is not None else 400))

    t = sol.t * t_ref
    R = sol.y[0] * R0
    U = sol.y[1] * U_ref
    if case.closure == "T":
        Nv = sol.y[2] * N_ref
        T = sol.y[3] * T0
    else:
        Nv = np.zeros_like(R)
        Vf = 4 * math.pi / 3 * R ** 3 - Vexg
        T = T0 * (Vg0 / Vf) ** (kappa - 1.0)

    res = dict(model=case.model, closure=case.closure, label=LABEL[(case.model, case.closure)],
               gas=G.name, liquid=case.liquid, Rmax=R0, pinf=case.pinf, pg0=pg0, psat=psat, T0=T0,
               boundary=case.boundary, gamma=case.gamma, status=sol.status, message=sol.message,
               floor_hit=bool(sol.t_events[2].size), nfev=sol.nfev)
    rho_inf, c_inf = liquid_state(case.pinf if case.history is None else p_start)
    res["c_inf"] = c_inf
    if case.history is None:
        if sol.t_events[0].size:
            tm = sol.t_events[0][0] * t_ref
            ym = sol.y_events[0][0]
            Rm = ym[0] * R0
            mask = t <= tm * (1 + 1e-12)
            Umax = max(np.max(np.abs(U[mask])), 0.0)
            if case.closure == "T":
                Tm_at_min = ym[3] * T0
                Nv_min = ym[2] * N_ref
                # peak temperature: maximum over the solver steps around the first collapse and the event state
                t_reb = sol.t_events[1][0] * t_ref if sol.t_events[1].size else t[-1]
                win = (t >= 0.5 * tm) & (t <= t_reb)
                Tpk = max(float(np.max(T[win])) if win.any() else Tm_at_min, Tm_at_min)
            else:
                Vf = 4 * math.pi / 3 * Rm ** 3 - Vexg
                Tpk = T0 * (Vg0 / Vf) ** (kappa - 1.0)
                Nv_min = 0.0
            if gasx:
                res["Ng_ratio"] = float(ym[4] * N_ref / Ng)
            res.update(collapsed=True, t_c=tm, Rmin=Rm, comp=R0 / Rm, Umax=Umax, Mach=Umax / c_inf,
                       Tmax=Tpk, xv_collapse=(Nv_min / (Ng + Nv_min)) if case.closure == "T" else np.nan,
                       Nv_ratio=(Nv_min / Nv0) if (case.closure == "T" and Nv0 > 0) else np.nan)
            if sol.t_events[1].size and sol.t_events[1][0] > sol.t_events[0][0]:
                Rreb = sol.y_events[1][0][0] * R0
                res.update(Rreb=Rreb, reb_ratio=Rreb / R0)
            else:
                res.update(Rreb=np.nan, reb_ratio=np.nan)
        else:
            res.update(collapsed=False, t_c=np.nan, Rmin=float(np.min(R)), comp=R0 / float(np.min(R)),
                       Umax=float(np.max(np.abs(U))), Mach=float(np.max(np.abs(U))) / c_inf,
                       Tmax=float(np.max(T)), xv_collapse=np.nan, Nv_ratio=np.nan, Rreb=np.nan, reb_ratio=np.nan)
    else:
        i = int(np.argmax(T))
        imax = int(np.argmax(R))
        res.update(collapsed=True, Tmax=float(T[i]), t_Tmax=float(t[i]), Rmax_hist=float(R[imax]),
                   t_Rmax=float(t[imax]), Rmin=float(np.min(R[imax:])) if imax < len(R) else np.nan,
                   Umax=float(np.max(np.abs(U))), Mach=float(np.max(np.abs(U))) / c_inf,
                   expansion=float(R[imax] / R0), n_min=int(sol.t_events[0].size), t_end=float(t[-1]))
        if case.start == "cavity":
            res.update(_first_collapse(case, sol, t, R, U, T, t_ref, R0, T0, psat, pfun, c_inf, kappa, Vexg, Vg0, pg0))
            if gasx and res.get("collapsed1"):
                k = int(np.argmin(np.abs(sol.t_events[0] * t_ref - res["t_c"])))
                res["Ng_ratio"] = float(sol.y_events[0][k][4] * N_ref / Ng)
    if case.keep:
        res["traj"] = dict(t=t, R=R, U=U, Nv=Nv, T=T, sol=sol, t_ref=t_ref, R0=R0, U_ref=U_ref, N_ref=N_ref)
    return res


def _first_collapse(case, sol, t, R, U, T, t_ref, R0, T0, psat, pfun, c_inf, kappa, Vexg, Vg0, pg0):
    """Metrics of the first genuine collapse of a cavity driven by a pressure history.

    A minimum counts as a collapse when R falls below half the largest radius reached since the previous
    minimum (or the start). The work-equivalent driving pressure is the constant overpressure that would do
    the same work on the cavity over the collapse: dp_eq = int (p_inf - p_sat)(-dV) / (V_peak - V_min)."""
    out = dict(collapsed1=False, t_c=np.nan, Rpeak=np.nan, t_peak=np.nan, Rmin1=np.nan, comp1=np.nan,
               Tmax1=np.nan, Mach1=np.nan, pinf_c=np.nan, dp_eq=np.nan, reb1=np.nan)
    t_min = sol.t_events[0] * t_ref
    y_min = sol.y_events[0]
    t_mx = sol.t_events[1] * t_ref
    t_prev = 0.0
    for k, tm in enumerate(t_min):
        Rm = y_min[k][0] * R0
        seg = (t >= t_prev) & (t <= tm * (1 + 1e-12))
        if not seg.any():
            t_prev = tm
            continue
        j = np.nonzero(seg)[0]
        jp = j[int(np.argmax(R[seg]))]
        Rp = float(R[jp])
        if Rm < 0.5 * Rp:
            tp = float(t[jp])
            win = (t >= tp) & (t <= tm * (1 + 1e-12))
            tt = np.r_[t[win], tm]
            VV = 4.0 / 3.0 * math.pi * np.r_[R[win], Rm] ** 3
            pp = np.array([pfun(x)[0] for x in tt]) - psat
            dV = -np.diff(VV)
            pm = 0.5 * (pp[1:] + pp[:-1])
            dp_eq = float(np.sum(pm * dV) / max(VV[0] - VV[-1], 1e-300))
            nxt = t_mx[t_mx > tm]
            t_reb = float(nxt[0]) if nxt.size else float(t[-1])
            if case.closure == "T":
                w2 = (t >= tp + 0.5 * (tm - tp)) & (t <= t_reb)
                Tm = y_min[k][3] * T0
                Tpk = max(float(np.max(T[w2])) if w2.any() else Tm, Tm)
            else:
                Vf = 4 * math.pi / 3 * Rm ** 3 - Vexg
                Tpk = T0 * (Vg0 / Vf) ** (kappa - 1.0)
            Umax1 = float(np.max(np.abs(U[(t >= tp) & (t <= t_reb)]))) if ((t >= tp) & (t <= t_reb)).any() else np.nan
            reb = np.nan
            if nxt.size:
                kk = int(np.nonzero(t_mx > tm)[0][0])
                reb = float(sol.y_events[1][kk][0] * R0 / Rp)
            out.update(collapsed1=True, t_c=float(tm), Rpeak=Rp, t_peak=tp, Rmin1=float(Rm), comp1=Rp / Rm,
                       Tmax1=float(Tpk), Mach1=Umax1 / c_inf, pinf_c=float(pfun(tm)[0]), dp_eq=dp_eq, reb1=reb)
            break
        t_prev = tm
    return out


def run_all(case: Case, models=MODELS, closures=CLOSURES):
    out = []
    for cl in closures:
        for m in models:
            out.append(simulate(replace(case, model=m, closure=cl)))
    return out


def xi_tinguely(dp, kappa, pg0, rho, c):
    return dp * kappa ** 6 / (pg0 ** (1 / kappa) * (rho * c * c) ** (1 - 1 / kappa))
