"""Section 4.7: analysis of the CFD-history runs (H1-H3), the numbers quoted in the text and Figure 9.
Also corrects the closure statements of the step map (S1) with the thermal Peclet number."""
import json, math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from properties import LIQUIDS, GASES, VAPOURS
from hcbubble import xi_tinguely
import figures as F

OUT, FIG = "../out/", "../fig/"
T0, PS, PATM = 295.15, 2645.0, 101325.0
W, AIR, H2O = LIQUIDS["water"], GASES["air"], VAPOURS["water"]
KAP, SIG = AIR.kappa298, LIQUIDS["water"].sigma
NAMES = ['V-PR3.0', 'V-PR4.0', 'V-PR5.5', 'V-b7.5', 'V-ld3', 'O-PR5.0']
SHORT = {'V-PR3.0': 'Venturi, PR 3.0', 'V-PR4.0': 'Venturi, PR 4.0', 'V-PR5.5': 'Venturi, PR 5.5',
         'V-b7.5': 'Venturi, 7.5° diffuser, PR 3.0', 'V-ld3': 'Venturi, l/d = 3, PR 3.0', 'O-PR5.0': 'Orifice, PR 5.0'}
TICK = {'V-PR3.0': 'V, 3.0', 'V-PR4.0': 'V, 4.0', 'V-PR5.5': 'V, 5.5', 'V-b7.5': 'V 7.5°,\n3.0', 'V-ld3': 'V l/d 3,\n3.0',
        'O-PR5.0': 'O, 5.0'}
HCOL = {'V-PR3.0': '#86b6ef', 'V-PR4.0': '#2a78d6', 'V-PR5.5': '#104281', 'V-b7.5': '#eb6834', 'V-ld3': '#eb6834',
        'O-PR5.0': '#1baf7a'}
HLS = {'V-PR3.0': '-', 'V-PR4.0': '-', 'V-PR5.5': '-', 'V-b7.5': '-', 'V-ld3': '--', 'O-PR5.0': '-'}
LAB = {("RP", "P"): "RP", ("KM", "P"): "KM", ("PL", "P"): "PL", ("G", "P"): "Gilmore",
       ("RP", "T"): "RP-T", ("KM", "T"): "KM-T", ("PL", "T"): "PL-T", ("G", "T"): "Gilmore-T"}
PE_BINS = [(0, 3, "#0d366b", "Pe < 3"), (3, 30, "#3987e5", "3 ≤ Pe < 30"), (30, 1e9, "#b7d3f6", "Pe ≥ 30")]


def chi0(pg, T, psat):
    """thermal diffusivity of the initial contents (gas + saturated vapour), m2/s"""
    ptot = pg + psat
    xg, xv = pg / ptot, psat / ptot
    lam = xg * AIR.lam + xv * H2O.lam
    cp = xg * (AIR.cv(T) + 1.0) + xv * (H2O.cv(T) + 1.0)
    return lam / (ptot / T * cp)


def pe_colour(pe):
    for lo, hi, c, _ in PE_BINS:
        if lo <= pe < hi:
            return c
    return PE_BINS[-1][2]


def load():
    h2 = pd.read_csv(OUT + "H2_cavity.csv")
    h3 = pd.read_csv(OUT + "H3_steps.csv")
    h1 = pd.read_csv(OUT + "H1_nucleus.csv")
    H = json.load(open(OUT + "H_histories.json"))
    for d in (h1, h2):
        d["lab"] = [LAB[(m, c)] for m, c in zip(d.model, d.closure)]
        d["failed"] = d["failed"].fillna(False).astype(bool)
    h2["coll"] = h2.collapsed1.fillna(False).astype(bool)
    h2["pg_peak"] = h2.pg0_set * (h2.Rmax / h2.Rpeak) ** 3
    # driving of the first collapse: work-equivalent overpressure plus the surface-tension work 3 sigma / R
    h2["dp_star"] = h2.dp_eq + 3 * SIG / h2.Rpeak
    h2["xi_star"] = [xi_tinguely(d, KAP, g, W.rho(PS + d), W.c(PS + d)) if (ok and np.isfinite(d)) else np.nan
                     for d, g, ok in zip(h2.dp_star, h2.pg_peak, h2.coll)]
    h2["t_coll"] = h2.t_c - h2.t_peak
    h2["Pe"] = [R * R / (chi0(g, T0, PS) * tc) if ok else np.nan
                for R, g, tc, ok in zip(h2.Rpeak, h2.pg_peak, h2.t_coll, h2.coll)]
    eq = h3[h3.study == "H3eq"].copy()
    eq["lab"] = [LAB[(m, c)] for m, c in zip(eq.model_h, eq.closure_h)]
    eq = eq.set_index(["hist", "Rmax", "pg0_set", "lab"])
    outs = h3[h3.study == "H3out"].copy()
    outs["lab"] = [LAB[(m, c)] for m, c in zip(outs.model, outs.closure)]
    outs = outs.set_index(["Rmax", "pg0_set", "lab"])
    key = list(zip(h2["hist"], h2.Rmax, h2.pg0_set, h2.lab))
    h2["T_step_eq"] = [eq.Tmax.get(k, np.nan) for k in key]
    h2["M_step_eq"] = [eq.Mach.get(k, np.nan) for k in key]
    h2["T_step_out"] = [outs.Tmax.get(k[1:], np.nan) for k in key]
    h2["M_step_out"] = [outs.Mach.get(k[1:], np.nan) for k in key]
    # step map with Peclet number
    s1 = pd.read_csv(OUT + "S1_regime_map.csv")
    T = s1.pivot_table(index=["Rmax", "pinf", "pg0"], columns="label", values="Tmax")
    tc = s1.pivot_table(index=["Rmax", "pinf", "pg0"], columns="label", values="t_c")["KM-T"]
    s = pd.DataFrame({"clos": T["KM"] / T["KM-T"], "rp": T["RP-T"] / T["KM-T"]})
    s["xi"] = [xi_tinguely(p - W.psat, KAP, g, W.rho(p), W.c(p)) for (R, p, g) in s.index]
    s["Pe"] = [R * R / (chi0(g, W.T0, W.psat) * tc.loc[(R, p, g)]) for (R, p, g) in s.index]
    return h1, h2, h3, H, s[s.clos.notna()]


def wide(d, val):
    return d.pivot_table(index=["hist", "Rmax", "pg0_set"], columns="lab", values=val)


def numbers(h1, h2, h3, H, s):
    s = s.copy()
    N = {}
    ch = H["checks"]
    N["h_chk_v"] = f"{100 * ch['venturi PR3.0: Fig 10b vs Fig 19'][0]:.1f}"
    N["h_chk_o_lo"] = f"{100 * ch['orifice l/d2 PR5: Fig 6b vs Fig 8c'][0]:.1f}"
    N["h_chk_o_hi"] = f"{100 * ch['orifice l/d2 PR5: Fig 6b vs Fig 6c'][0]:.1f}"
    p0 = [H["meta"][k]["p0"] for k in NAMES]
    N["h_p0_lo"], N["h_p0_hi"] = f"{min(p0) / 1e3:.1f}", f"{max(p0) / 1e3:.1f}"
    # nucleus problem: Blake thresholds and response
    bl = []
    for k in NAMES:
        pgn = H["meta"][k]["PR"] * PATM + 2 * SIG / 10e-6 - PS
        Rc = math.sqrt(3 * pgn * (10e-6) ** 3 / (2 * SIG))
        bl.append((PS - 4 * SIG / (3 * Rc), min(H[k])))
    N["h_blake_lo"] = f"{min(b[0] for b in bl) / 1e3:.2f}"
    N["h_blake_hi"] = f"{max(b[0] for b in bl) / 1e3:.2f}"
    N["h_blake_margin"] = f"{min(b[1] - b[0] for b in bl) / 1e3:.2f}"
    N["h_pmin"] = f"{min(b[1] for b in bl) / 1e3:.2f}"
    ok1 = h1[~h1.failed]
    N["h1_n"], N["h1_fail"] = str(len(h1)), str(int(h1.failed.sum()))
    for cl, k in (("P", "P"), ("T", "T")):
        q = ok1[ok1.closure == cl].expansion
        N[f"h1_exp_{k}_lo"], N[f"h1_exp_{k}_hi"] = f"{q.min():.1f}", f"{q.max():.1f}"
    N["h1_Tmax"] = f"{ok1.Tmax.max():.0f}"
    N["h1_Mmax"] = f"{ok1.Mach.max():.3f}"
    # cavity problem
    c = h2[h2.coll]
    kmt = c[c.lab == "KM-T"]
    N["h2_n"], N["h2_fail"] = str(len(h2)), str(int(h2.failed.sum()))
    N["h3_n"] = str(len(h3))
    N["h2_ncoll_KMT"] = str(len(kmt))
    N["h2_ncond"] = str(len(h2[h2.lab == "KM-T"]))
    N["h2_dpeq_lo"], N["h2_dpeq_hi"] = f"{kmt.dp_eq.min() / 1e3:.2f}", f"{kmt.dp_eq.max() / 1e3:.0f}"
    N["h2_frac_hi"] = f"{100 * kmt.dp_eq.max() / PATM:.0f}"
    N["h2_M_KMT_max"] = f"{kmt.Mach1.max():.2f}"
    N["h2_M_all_max"] = f"{c.Mach1.max():.2f}"
    ref = c[(c["hist"] == "V-PR3.0") & np.isclose(c.Rmax, 500e-6) & np.isclose(c.pg0_set, 100.0)].set_index("lab")
    N["h2_ref_tc"] = f"{1e6 * ref.loc['KM-T', 't_c']:.0f}"
    N["h2_ref_pinfc"] = f"{ref.loc['KM-T', 'pinf_c'] / 1e3:.0f}"
    N["h2_ref_dpeq"] = f"{ref.loc['KM-T', 'dp_eq'] / 1e3:.0f}"
    for l, key in (("KM", "KM"), ("KM-T", "KMT"), ("RP-T", "RPT"), ("Gilmore-T", "GT"), ("PL-T", "PLT")):
        N[f"h2_ref_T_{key}"] = f"{ref.loc[l, 'Tmax1']:,.0f}"
    N["h2_ref_M_KMT"] = f"{ref.loc['KM-T', 'Mach1']:.2f}"
    N["h2_ref_Tout_KMT"] = f"{ref.loc['KM-T', 'T_step_out']:,.0f}"
    N["h2_ref_Mout_KMT"] = f"{ref.loc['KM-T', 'M_step_out']:.2f}"
    # device trend, 500 um, 100 Pa, KM-T
    d5 = kmt[np.isclose(kmt.Rmax, 500e-6) & np.isclose(kmt.pg0_set, 100.0)].set_index("hist")
    for k, key in (("V-PR3.0", "v30"), ("V-PR4.0", "v40"), ("V-PR5.5", "v55"), ("V-b7.5", "vb75"), ("V-ld3", "vld3"),
                   ("O-PR5.0", "o50")):
        N[f"h2_{key}_T"] = f"{d5.loc[k, 'Tmax1']:,.0f}"
        N[f"h2_{key}_tc"] = f"{1e6 * d5.loc[k, 't_c']:.0f}"
        N[f"h2_{key}_dpeq"] = f"{d5.loc[k, 'dp_eq'] / 1e3:.1f}"
        N[f"h2_{key}_pc"] = f"{d5.loc[k, 'pinf_c'] / 1e3:.1f}"
    nc = h2[(~h2.coll) & (h2.lab == "KM-T")]
    N["h2_nocoll_n"] = str(len(nc))
    # step to the outlet pressure and to dp_eq
    over = (kmt.T_step_out / kmt.Tmax1).dropna()
    N["h2_over_lo"], N["h2_over_hi"], N["h2_over_med"] = f"{over.min():.1f}", f"{over.max():.0f}", f"{over.median():.1f}"
    overP = (c[c.lab == "KM"].T_step_out / c[c.lab == "KM"].Tmax1).dropna()
    N["h2_overP_hi"] = f"{overP.max():.0f}"
    overRP = (c[c.lab == "RP-T"].T_step_out / c[c.lab == "RP-T"].Tmax1).dropna()
    N["h2_overRP_hi"] = f"{overRP.max():.0f}"
    N["h2_Mout_lo"], N["h2_Mout_hi"] = f"{kmt.M_step_out.min():.2f}", f"{kmt.M_step_out.max():.2f}"
    c2 = c[np.isfinite(c.T_step_eq)]
    err = 100 * (c2.Tmax1 / c2.T_step_eq - 1)
    N["h2_eq_n"] = str(len(c2))
    N["h2_eq_T_max"] = f"{err[c2.closure == 'T'].abs().max():.1f}"
    N["h2_eq_P_max"] = f"{err[c2.closure == 'P'].abs().max():.0f}"
    N["h2_eq_med"] = f"{err.abs().median():.1f}"
    N["h2_eq_P_p95"] = f"{np.percentile(err[c2.closure == 'P'].abs(), 95):.1f}"
    dM = (c2.Mach1 / c2.M_step_eq - 1).abs() * 100
    N["h2_eq_M_med"] = f"{dM.median():.1f}"
    # models and closures
    Tw = wide(c, "Tmax1")
    sp = 100 * (Tw[["KM-T", "PL-T", "Gilmore-T"]].max(axis=1) - Tw[["KM-T", "PL-T", "Gilmore-T"]].min(axis=1)) / Tw["KM-T"]
    spP = 100 * (Tw[["KM", "PL", "Gilmore"]].max(axis=1) - Tw[["KM", "PL", "Gilmore"]].min(axis=1)) / Tw["KM"]
    N["h2_spread_T_max"] = f"{sp.max():.1f}"
    N["h2_spread_P_max"] = f"{spP.dropna().max():.1f}"
    clos = (Tw["KM"] / Tw["KM-T"]).dropna()
    N["h2_clos_lo"], N["h2_clos_hi"] = f"{clos.min():.1f}", f"{clos.max():.1f}"
    X = wide(c, "xi_star")["KM-T"]
    Pe = wide(c, "Pe")["KM-T"]
    M = wide(c, "Mach1")["KM-T"]
    low = clos[X.reindex(clos.index) < 2]
    N["h2_clos_lowxi_lo"], N["h2_clos_lowxi_hi"] = f"{low.min():.1f}", f"{low.max():.1f}"
    N["h2_xi_lo"], N["h2_xi_hi"] = f"{X.min():.2f}", f"{X.max():.0f}"
    N["h2_Pe_lo"], N["h2_Pe_hi"] = f"{Pe.min():.1f}", f"{Pe.max():.1f}"
    tcoll = wide(c, "t_coll")["KM-T"] * 1e6
    N["h2_tcoll_lo"], N["h2_tcoll_hi"] = f"{tcoll.min():.0f}", f"{tcoll.max():.0f}"
    rp = (Tw["RP-T"] / Tw["KM-T"]).dropna()
    N["h2_RP_hi"] = f"{rp.max():.1f}"
    N["h2_RP10_M"] = f"{M[rp[rp > 1.10].index].min():.3f}"
    N["h2_RP10_M_below"] = f"{M[rp[rp <= 1.10].index].max():.3f}"
    N["h2_RP10_xi"] = f"{X[rp[rp > 1.10].index].min():.1f}"
    later = (c[c.lab == "KM-T"].Tmax / c[c.lab == "KM-T"].Tmax1)
    N["h2_later_frac"] = f"{100 * (later > 1.05).mean():.0f}"
    N["h2_later_max"] = f"{later.max():.1f}"
    # corrected statements for the step map
    N["s1_n"] = str(len(s))
    w10 = s[s.clos <= 1.10]
    N["s1_clos10_n"] = str(len(w10))
    N["s1_clos10_pg"] = "/".join(sorted(set(f"{g / 1e3:.0f}" for (_, _, g) in w10.index)))
    N["s1_clos_xi2_max"] = f"{100 * (s[s.xi < 2].clos.max() - 1):.0f}"
    N["s1_clos_pg100_max"] = f"{100 * (s[[i[2] >= 1e5 for i in s.index]].clos.max() - 1):.0f}"
    N["s1_Pe_xi2_lo"], N["s1_Pe_xi2_hi"] = f"{s[s.xi < 2].Pe.min():.1f}", f"{s[s.xi < 2].Pe.max():.0f}"
    N["s1_Pe_lo"], N["s1_Pe_hi"] = f"{s.Pe.min():.1f}", f"{s.Pe.max():,.0f}"
    # closure ratio at xi 5-30 by Pe class, step map
    mid = s[(s.xi >= 5) & (s.xi < 30)]
    N["s1_mid_lowPe"] = f"{mid[mid.Pe < 3].clos.median():.1f}"
    N["s1_mid_highPe"] = f"{mid[mid.Pe >= 30].clos.median():.1f}"
    # gas dissolution/uptake sensitivity (reviewer R1.8), energy balance
    g = pd.read_csv(OUT + "R18_gas_exchange.csv")
    s1 = pd.read_csv(OUT + "S1_regime_map.csv")
    ref = s1[s1.label == "KM-T"].set_index(["Rmax", "pinf", "pg0"]).Tmax
    st = g[g.study == "step"].copy()
    st["dT"] = 100 * (st.Tmax / [ref.get((R, p, q), np.nan) for R, p, q in zip(st.Rmax, st.pinf, st.pg0)] - 1)
    st["up"] = 100 * (st.Ng_ratio - 1)
    hi_g, lo_g = st[st.pg0 >= 100], st[st.pg0 < 100]
    N["gx_step_dT_max"] = f"{hi_g.dT.abs().max():.1f}"
    N["gx_step_up_max"] = f"{hi_g.up.max():.1f}"
    N["gx_10_up_lo"], N["gx_10_up_hi"] = f"{lo_g.up.min():.0f}", f"{lo_g.up.max():.0f}"
    N["gx_10_dT_lo"], N["gx_10_dT_hi"] = f"{lo_g.dT.abs().min():.0f}", f"{lo_g.dT.abs().max():.0f}"
    hh = g[g.study == "hist"].copy()
    href = h2[h2.closure == "T"].set_index(["hist", "Rmax", "pg0_set", "model"]).Tmax1
    hh["dT"] = 100 * (hh.Tmax1 / [href.get((a_, R, q, m), np.nan) for a_, R, q, m in zip(hh["hist"], hh.Rmax, hh.pg0, hh.model)] - 1)
    hh["up"] = 100 * (hh.Ng_ratio - 1)
    hh = hh[np.isfinite(hh.dT)]
    N["gx_hist_dT_max"] = f"{hh.dT.abs().max():.1f}"
    N["gx_hist_up_max"] = f"{hh.up.max():.1f}"
    N["gx_hist1k_dT_max"] = f"{hh[hh.pg0 >= 1000].dT.abs().max():.1f}"
    N["gx_n"] = str(len(g))
    return N


def fig_histories(h1, h2, H, s):
    t = np.array(H["t"])
    c = h2[h2.coll]
    fig, axs = plt.subplots(2, 2, figsize=(6.8, 6.0), constrained_layout=True)
    # (a)
    ax = axs[0, 0]
    tt = np.maximum(t, 1e-5)
    for k in NAMES:
        ax.plot(tt * 1e3, np.array(H[k]) / 1e3, color=HCOL[k], ls=HLS[k], lw=1.5, label=SHORT[k])
    for R, mk in ((100e-6, "o"), (500e-6, "s")):
        q = c[(c.lab == "KM-T") & np.isclose(c.Rmax, R) & np.isclose(c.pg0_set, 100.0)]
        for _, r in q.iterrows():
            ax.plot(max(r.t_c, 1e-5) * 1e3, r.pinf_c / 1e3, mk, ms=5, mfc="white", mec=HCOL[r["hist"]], mew=1.2, zorder=5)
    ax.axhline(PATM / 1e3, color=F.MUTED, lw=0.8, ls=":")
    ax.text(0.33, PATM / 1e3 * 1.07, "outlet, 1 atm", fontsize=6.3, color=F.MUTED)
    ax.axhline(PS / 1e3, color=F.MUTED, lw=0.8, ls=":")
    ax.text(0.0105, PS / 1e3 * 0.80, "$p_{sat}$, 22 °C", fontsize=6.3, color=F.MUTED)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlim(1e-2, 1.0); ax.set_ylim(1.9, 150)
    F.logticks(ax, [0.01, 0.1, 1.0], ["0.01", "0.1", "1"])
    F.logticks(ax, [2, 5, 10, 20, 50, 100], ["2", "5", "10", "20", "50", "100"], axis="y")
    ax.set_xlabel("Time after leaving the vapor pocket (ms)")
    ax.set_ylabel("Mean pressure along the trajectory (kPa)")
    ax.legend(loc="upper left", bbox_to_anchor=(0.0, 0.88), fontsize=5.7, handlelength=1.8, labelspacing=0.25)
    F.panel(ax, "a")
    # (b)
    ax = axs[0, 1]
    q = c[np.isclose(c.Rmax, 500e-6) & np.isclose(c.pg0_set, 100.0)]
    offs = {"RP": -0.27, "KM": -0.09, "PL": 0.09, "G": 0.27}
    for i, k in enumerate(NAMES):
        for _, r in q[q["hist"] == k].iterrows():
            ax.scatter(i + offs[r.model], r.Tmax1, marker=F.MRK[r.model], s=17,
                       facecolors=F.COL[r.model] if r.closure == "T" else "none", edgecolors=F.COL[r.model],
                       linewidths=0.9, zorder=3)
    so = h2[np.isclose(h2.Rmax, 500e-6) & np.isclose(h2.pg0_set, 100.0)]
    for lab, ls, xt, ha in (("KM-T", "-", 2.0, "center"), ("KM", "--", 5.5, "right")):
        v = so[so.lab == lab].T_step_out.dropna()
        ax.axhline(v.iloc[0], color=F.INK2, lw=0.8, ls=ls)
        ax.text(xt, v.iloc[0] * 1.07, f"step to 1 atm, {lab}", fontsize=5.9, color=F.INK2, ha=ha)
    ax.set_yscale("log"); ax.set_ylim(300, 1.5e5)
    ax.set_xlim(-0.5, 5.6)
    ax.set_xticks(range(len(NAMES))); ax.set_xticklabels([TICK[k] for k in NAMES], fontsize=6.3)
    ax.set_ylabel("Peak temperature, first collapse (K)")
    ax.set_title("$R_{max}$ = 500 µm, $p_{g0}$ = 100 Pa", loc="left", fontsize=8)
    for m in ("RP", "KM", "PL", "G"):
        ax.scatter([], [], marker=F.MRK[m], s=17, color=F.COL[m], label=F.NAME[m])
    ax.scatter([], [], marker="o", s=17, facecolors="none", edgecolors=F.INK2, label="open: polytropic")
    ax.legend(loc="upper left", fontsize=5.8, ncol=2, handletextpad=0.3, columnspacing=0.8)
    ax.grid(axis="x", visible=False)
    F.panel(ax, "b")
    # (c)
    ax = axs[1, 0]
    ax.scatter(s.xi, s.clos, s=10, c=[pe_colour(p) for p in s.Pe], marker="o", linewidths=0, alpha=0.85, zorder=2)
    Tw = wide(c, "Tmax1")
    X = wide(c, "xi_star")["KM-T"]; Pe = wide(c, "Pe")["KM-T"]
    for idx, v in Tw.iterrows():
        if np.isfinite(v.get("KM", np.nan)) and np.isfinite(v.get("KM-T", np.nan)):
            ax.scatter(X.loc[idx], v["KM"] / v["KM-T"], s=26, marker="D", color=pe_colour(Pe.loc[idx]),
                       edgecolors=F.INK, linewidths=0.6, zorder=3)
    for lo, hi, col, lab in PE_BINS:
        ax.scatter([], [], s=14, color=col, label=lab)
    ax.scatter([], [], s=10, marker="o", color=F.MUTED, label="step, 0.1–2 MPa")
    ax.scatter([], [], s=22, marker="D", facecolors="none", edgecolors=F.INK, linewidths=0.6, label="device history")
    ax.axhline(1, color=F.AXIS, lw=0.8); ax.axhline(1.1, color=F.MUTED, lw=0.6, ls=":")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("ξ (steps: Eq. 12; histories: $\\Delta p_{eq}$ + 3σ/$R_{max}$)")
    ax.set_ylabel("Polytropic over-prediction, KM / KM-T")
    ax.legend(loc="upper left", fontsize=5.8, ncol=1, labelspacing=0.25)
    F.panel(ax, "c")
    # (d)
    ax = axs[1, 1]
    for m in ("RP", "KM", "PL", "G"):
        for cl in ("P", "T"):
            q = c[(c.model == m) & (c.closure == cl)]
            ax.scatter(q.T_step_eq, q.Tmax1, marker=F.MRK[m], s=11, facecolors=F.COL[m] if cl == "T" else "none",
                       edgecolors=F.COL[m], linewidths=0.7, zorder=3)
    q = c[c.lab == "KM-T"]
    ax.scatter(q.T_step_out, q.Tmax1, marker="x", s=13, color=F.INK2, linewidths=0.8, zorder=2)
    lim = [250, 2e5]
    ax.plot(lim, lim, color=F.AXIS, lw=0.8)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(lim); ax.set_ylim(lim)
    ax.set_xlabel("Peak temperature, step problem (K)")
    ax.set_ylabel("Peak temperature, device history (K)")
    for m in ("RP", "KM", "PL", "G"):
        ax.scatter([], [], marker=F.MRK[m], s=13, color=F.COL[m], label=f"{F.NAME[m]}")
    ax.scatter([], [], marker="x", s=13, color=F.INK2, label="KM-T, step to 1 atm")
    ax.legend(loc="upper left", fontsize=5.8, labelspacing=0.25, title="step to $\\Delta p_{eq}$:", title_fontsize=6)
    F.panel(ax, "d")
    F.save(fig, "fig10_histories")


if __name__ == "__main__":
    h1, h2, h3, H, s = load()
    N = numbers(h1, h2, h3, H, s)
    json.dump(N, open(OUT + "H_numbers.json", "w"), indent=0)
    for k, v in N.items():
        print(f"{k:22s} {v}")
    fig_histories(h1, h2, H, s)
