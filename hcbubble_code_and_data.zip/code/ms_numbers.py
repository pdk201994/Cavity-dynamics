"""Collect every number quoted in the manuscript from the result files (no number is typed by hand)."""
import json
import numpy as np
import pandas as pd
from properties import LIQUIDS, GASES
from hcbubble import xi_tinguely

OUT = "../out/"


def K(x):      # temperature, nearest kelvin with thousands separator
    return f"{x:,.0f}"


def P(x, d=0):  # percentage
    return f"{x:.{d}f}"


def F(x, d=2):
    return f"{x:.{d}f}"


def build():
    N = {}
    W, kair = LIQUIDS["water"], GASES["air"].kappa298
    s1 = pd.read_csv(OUT + "S1_regime_map.csv")
    N["n_S1"] = f"{len(s1):,}"
    N["n_S1_fail"] = str(int((s1.error.fillna("") != "").sum()))
    T = s1.pivot_table(index=["Rmax", "pinf", "pg0"], columns="label", values="Tmax")
    M = s1.pivot_table(index=["Rmax", "pinf", "pg0"], columns="label", values="Mach")
    X = s1.pivot_table(index=["Rmax", "pinf", "pg0"], columns="label", values="xv_collapse")
    RB = s1.pivot_table(index=["Rmax", "pinf", "pg0"], columns="label", values="reb_ratio")

    def at(tab, lab, R, p, g):
        return float(tab.loc[(R, p, g), lab])
    R = 100e-6
    hc = (R, 3e5, 1000.0)
    N["xi_hc"] = F(xi_tinguely(3e5 - W.psat, kair, 1e3, W.rho(3e5), W.c(3e5)), 0)
    for lab, key in (("KM", "KM"), ("KM-T", "KMT"), ("RP", "RP"), ("RP-T", "RPT"), ("Gilmore-T", "GT"), ("PL-T", "PLT"), ("Gilmore", "G"), ("PL", "PL")):
        N[f"T_{key}_hc"] = K(at(T, lab, *hc))
    N["ratio_hc"] = F(at(T, "KM", *hc) / at(T, "KM-T", *hc), 1)
    N["M_KMT_hc"] = F(at(M, "KM-T", *hc)); N["M_KM_hc"] = F(at(M, "KM", *hc))
    N["xv_hc"] = P(100 * at(X, "KM-T", *hc))
    N["reb_KM_hc"] = F(at(RB, "KM", *hc)); N["reb_KMT_hc"] = F(at(RB, "KM-T", *hc))
    atm = (R, 1e5, 100.0)
    N["xi_atm"] = F(xi_tinguely(1e5 - W.psat, kair, 100.0, W.rho(1e5), W.c(1e5)), 0)
    N["M_KMT_atm"] = F(at(M, "KM-T", *atm)); N["T_KM_atm"] = K(at(T, "KM", *atm)); N["T_KMT_atm"] = K(at(T, "KM-T", *atm))
    # thresholds over the whole map (all radii)
    xi = pd.Series([xi_tinguely(p - W.psat, kair, g, W.rho(p), W.c(p)) for (_, p, g) in T.index], index=T.index)
    clos = T["KM-T"] / T["KM"]
    N["clos90_xi"] = F(xi[clos > 0.9].max(), 1)
    N["clos50_xi"] = F(xi[clos < 0.5].min(), 0)
    hi = xi >= 30
    N["clos_hi_min"] = F(1 / clos[hi].max(), 1); N["clos_hi_max"] = F(1 / clos[hi].min(), 0)
    mid = (xi >= 2) & (xi <= 4)
    N["clos_mid_lo"] = P(100 * (1 - clos[mid].max())); N["clos_mid_hi"] = P(100 * (1 - clos[mid].min()))
    vr = (xi > 4) & (M["KM-T"] <= 0.5)
    N["clos_vr_lo"] = F(1 / clos[vr].max(), 1); N["clos_vr_hi"] = F(1 / clos[vr].min(), 0)
    lo = xi < 5
    N["clos_lo_min"] = P(100 * (1 - clos[lo].max())); N["clos_lo_max"] = P(100 * (1 - clos[lo].min()))
    for cl, suf in (("", "P"), ("-T", "T")):
        rp = T["RP" + cl] / T["KM" + cl]
        N[f"RP10_xi_{suf}"] = F(xi[rp > 1.10].min(), 1)
        N[f"RP10_M_{suf}"] = F(M["KM" + cl][rp > 1.10].min(), 2)
        g = (T["Gilmore" + cl] / T["KM" + cl] - 1).abs(); pl = (T["PL" + cl] / T["KM" + cl] - 1).abs()
        N[f"G5_M_{suf}"] = F(M["KM" + cl][g > 0.05].min(), 2); N[f"G10_M_{suf}"] = F(M["KM" + cl][g > 0.10].min(), 2)
        N[f"PL5_M_{suf}"] = F(M["KM" + cl][pl > 0.05].min(), 2); N[f"PL10_M_{suf}"] = F(M["KM" + cl][pl > 0.10].min(), 2)
        N[f"RPmax_{suf}"] = F(rp.max(), 0)
    bins = json.load(open(OUT + "S1_mach_bins.json"))
    for k, v in bins.items():
        for kk, vv in v.items():
            N[f"bin_{k}_{kk}"] = str(vv)
    # spread of compressible models by xi bin (energy balance, all radii)
    sp = (T[["KM-T", "PL-T", "Gilmore-T"]].max(1) - T[["KM-T", "PL-T", "Gilmore-T"]].min(1)) / T["KM-T"]
    N["spreadT_xi5"] = P(100 * sp[xi < 5].max(), 1); N["spreadT_xi30"] = P(100 * sp[(xi >= 5) & (xi < 30)].max(), 0)
    N["spreadT_xi100"] = P(100 * sp[(xi >= 30) & (xi < 100)].max(), 0); N["spreadT_ximax"] = P(100 * sp[xi >= 100].max(), 0)
    N["MT_xi30_100_lo"] = F(M["KM-T"][(xi >= 30) & (xi < 100)].min()); N["MT_xi30_100_hi"] = F(M["KM-T"][(xi >= 30) & (xi < 100)].max())
    N["MT_xi100_hi"] = F(M["KM-T"][xi >= 100].max())
    # De-Nasri trend: recovery pressure 0.1 -> 0.2 MPa at fixed gas content
    for g, key in ((1000.0, "1k"), (100.0, "100")):
        a, b = at(T, "KM-T", R, 1e5, g), at(T, "KM-T", R, 2e5, g)
        N[f"dn_{key}_a"] = K(a); N[f"dn_{key}_b"] = K(b); N[f"dn_{key}_pct"] = P(100 * (b / a - 1))

    s2 = pd.read_csv(OUT + "S2_contents.csv")
    m2 = s2[s2.tag == "S2"]
    for p, pk in ((3e5, "03"), (1e6, "1")):
        for g, gk in ((1e3, "1k"), (1e4, "10k")):
            q = m2[np.isclose(m2.pinf, p) & np.isclose(m2.pg0, g)]
            for gas in ("He", "Ne", "Ar", "Kr", "Xe", "air", "CO2"):
                for lab, lk in (("KM", "KM"), ("KM-T", "KMT")):
                    N[f"g_{pk}_{gk}_{gas}_{lk}"] = K(float(q[(q.gas == gas) & (q.label == lab)].Tmax.iloc[0]))
            ar = float(q[(q.gas == "Ar") & (q.label == "KM-T")].Tmax.iloc[0]); co2 = float(q[(q.gas == "CO2") & (q.label == "KM-T")].Tmax.iloc[0])
            arp = float(q[(q.gas == "Ar") & (q.label == "KM")].Tmax.iloc[0]); co2p = float(q[(q.gas == "CO2") & (q.label == "KM")].Tmax.iloc[0])
            N[f"g_{pk}_{gk}_ArCO2_T"] = F(ar / co2); N[f"g_{pk}_{gk}_ArCO2_P"] = F(arp / co2p)
    cv = s2[s2.tag == "S2_cv298"]
    for gas in ("Ar", "air", "CO2"):
        a = float(cv[(cv.gas == gas) & (cv.label == "KM-T") & np.isclose(cv.pinf, 3e5) & np.isclose(cv.pg0, 1e3)].Tmax.iloc[0])
        b = float(m2[(m2.gas == gas) & (m2.label == "KM-T") & np.isclose(m2.pinf, 3e5) & np.isclose(m2.pg0, 1e3)].Tmax.iloc[0])
        N[f"cv_{gas}_298"] = K(a); N[f"cv_{gas}_drop"] = P(100 * (1 - b / a))
    lad = s2[s2.tag.str.startswith("ladder")].copy(); lad["step"] = lad.tag.str.replace("ladder:", "", regex=False)
    for gas in ("air", "CO2", "Ar"):
        for g, gk in ((1e3, "1k"), (1e4, "10k")):
            q = lad[(lad.gas == gas) & np.isclose(lad.pinf, 3e5) & np.isclose(lad.pg0, g)].set_index("step")
            for st, sk in (("polytropic", "P"), ("adiabatic_frozen", "AF"), ("+cv(T)", "CV"), ("+conduction", "COND"), ("+vapour transport (full)", "FULL")):
                N[f"lad_{gas}_{gk}_{sk}"] = K(float(q.loc[st, "Tmax"]))
            N[f"lad_{gas}_{gk}_xv"] = P(100 * float(q.loc["+vapour transport (full)", "xv_collapse"]))
    og = s2[s2.tag == "S2_original"]
    for gas in ("Ar", "air", "CO2"):
        for lab, lk in (("KM", "KM"), ("KM-T", "KMT")):
            N[f"orig_{gas}_{lk}"] = K(float(og[(og.gas == gas) & (og.label == lab)].Tmax.iloc[0]))

    s3 = pd.read_csv(OUT + "S3_boundaries.csv")
    ref = s3[s3.tag == "S3_unbounded"].set_index("label")
    b = s3[s3.tag == "S3"].copy()
    b["dtc"] = 100 * (b.t_c / b.label.map(ref.t_c) - 1); b["dT"] = 100 * (b.Tmax / b.label.map(ref.Tmax) - 1)
    for bnd in ("wall", "free"):
        for gm in (1.5, 10.0):
            q = b[(b.boundary == bnd) & np.isclose(b.gamma, gm)]
            N[f"b_{bnd}_{gm:g}_KMT"] = P(float(q[q.label == "KM-T"].dtc.iloc[0]), 2)
            N[f"b_{bnd}_{gm:g}_KMT_abs"] = P(abs(float(q[q.label == "KM-T"].dtc.iloc[0])), 2)
            comp = q[q.model != "RP"]
            N[f"b_{bnd}_{gm:g}_spread"] = P(float(comp.dtc.max() - comp.dtc.min()), 2)
            N[f"b_{bnd}_{gm:g}_RP"] = P(float(q[q.label == "RP"].dtc.iloc[0]), 2)
    comp = b[b.model != "RP"]
    N["b_dT_comp_max"] = P(float(comp.dT.abs().max()), 1)
    N["b_dT_RPT_max"] = P(float(b[b.label == "RP-T"].dT.abs().max()), 1)

    s4 = pd.read_csv(OUT + "S4_solvents.csv")
    m4 = s4[s4.tag == "S4"]
    for g, gk in ((1e3, "1k"), (1e4, "10k")):
        for p, pk in ((3e5, "03"), (1e6, "1")):
            q = m4[np.isclose(m4.pinf, p) & np.isclose(m4.pg0, g)]
            for liq in ("water", "methanol", "ethanol", "isopropanol", "acetone", "20% MeOH", "glycerol"):
                lk = liq.replace("% MeOH", "MeOH")
                for lab, kk in (("KM", "KM"), ("KM-T", "KMT"), ("Gilmore", "G"), ("Gilmore-T", "GT")):
                    v = q[(q.liquid == liq) & (q.label == lab)].Tmax
                    if len(v):
                        N[f"s_{pk}_{gk}_{lk}_{kk}"] = K(float(v.iloc[0]))
                v = q[(q.liquid == liq) & (q.label == "KM-T")].xv_collapse
                if len(v) and np.isfinite(v.iloc[0]):
                    N[f"s_{pk}_{gk}_{lk}_xv"] = P(100 * float(v.iloc[0]))
            w = float(q[(q.liquid == "water") & (q.label == "KM-T")].Tmax.iloc[0]); mth = float(q[(q.liquid == "methanol") & (q.label == "KM-T")].Tmax.iloc[0])
            wp = float(q[(q.liquid == "water") & (q.label == "KM")].Tmax.iloc[0]); mp = float(q[(q.liquid == "methanol") & (q.label == "KM")].Tmax.iloc[0])
            N[f"s_{pk}_{gk}_quenchT"] = P(100 * (1 - mth / w)); N[f"s_{pk}_{gk}_quenchP"] = P(100 * (1 - mp / wp))
    wt = s4[s4.tag == "S4_water_tait"]
    for p, pk in ((3e5, "03"), (1e6, "1")):
        a = float(wt[(wt.liquid == "methanol") & (wt.label == "Gilmore") & np.isclose(wt.pinf, p) & np.isclose(wt.pg0, 1e3)].Tmax.iloc[0])
        bb = float(m4[(m4.liquid == "methanol") & (m4.label == "Gilmore") & np.isclose(m4.pinf, p) & np.isclose(m4.pg0, 1e3)].Tmax.iloc[0])
        km = float(m4[(m4.liquid == "methanol") & (m4.label == "KM") & np.isclose(m4.pinf, p) & np.isclose(m4.pg0, 1e3)].Tmax.iloc[0])
        N[f"tait_{pk}_old"] = K(a); N[f"tait_{pk}_new"] = K(bb); N[f"tait_{pk}_KM"] = K(km)
        N[f"tait_{pk}_gap_old"] = P(100 * (a / km - 1)); N[f"tait_{pk}_gap_new"] = P(100 * (bb / km - 1))
    gl = s4[s4.tag == "S4_glycerol"].copy()
    gl["Re"] = gl.Rmax * np.sqrt(1258.0 * (gl.pinf - 0.017)) / 0.934
    t = gl[gl.label == "KM-T"]
    N["gly_Re_overdamped_max"] = F(t[~t.collapsed.astype(bool)].Re.max(), 1)
    hot = t[t.collapsed.astype(bool) & (t.Tmax > 600)]
    N["gly_Re_heat_min"] = F(hot.Re.min(), 1)
    r1 = t[np.isclose(t.Rmax, 1e-3) & np.isclose(t.pinf, 3e5) & np.isclose(t.pg0, 1e3)].Tmax
    N["gly_1mm"] = K(float(r1.iloc[0]))
    N["gly_25um_Re"] = F(float(t[np.isclose(t.Rmax, 25e-6) & np.isclose(t.pinf, 3e5)].Re.iloc[0]), 2)

    s5 = pd.read_csv(OUT + "S5_sensitivity.csv")
    for liq in ("water", "methanol", "acetone"):
        q = s5[s5.liquid == liq]
        N[f"sens_{liq}_min"] = K(q.Tmax.min()); N[f"sens_{liq}_max"] = K(q.Tmax.max())
        a = q[q.test == "alpha"].set_index("alpha").Tmax
        N[f"sens_{liq}_a004"] = K(a.loc[0.04]); N[f"sens_{liq}_a1"] = K(a.loc[1.0])
        N[f"sens_{liq}_nostefan"] = K(float(q[q.test == "no Stefan"].Tmax.iloc[0]))
    v1 = pd.read_csv(OUT + "V1_tinguely_inverse.csv")
    for _, r in v1.iterrows():
        key = f"v1_{r.model}{r.closure}_{int(r.pinf/1e3)}_{r.Rmax*1e3:.1f}_{r.alpha}"
        N[key] = "—" if not np.isfinite(r.pg0_fit) else F(r.pg0_fit, 2)
    base = v1[np.isclose(v1.Rmax, 3.5e-3) & np.isclose(v1.alpha, 0.4) & (v1.model != "RP")]
    N["v1_10_lo"] = F(base[np.isclose(base.pinf, 1e4)].pg0_fit.min(), 1); N["v1_10_hi"] = F(base[np.isclose(base.pinf, 1e4)].pg0_fit.max(), 1)
    N["v1_30_lo"] = F(base[np.isclose(base.pinf, 3e4)].pg0_fit.min(), 2); N["v1_30_hi"] = F(base[np.isclose(base.pinf, 3e4)].pg0_fit.max(), 2)
    N["v1_RP_reb"] = F(float(v1[(v1.model == "RP") & (v1.closure == "P") & np.isclose(v1.pinf, 1e4)].reb_at_7Pa.iloc[0]), 3)
    v2 = pd.read_csv(OUT + "V2b_calibrated.csv")
    t = v2[v2.closure == "T"]
    N["v2_XeHe_lo"] = F(t.XeHe.min()); N["v2_XeHe_hi"] = F(t.XeHe.max())
    # RMS over the four predicted gases (argon is calibrated, so its error is zero by construction)
    meas = dict(He=3800, Ne=4100, Kr=4400, Xe=5100)   # Didenko et al. (2000), octanol, 285 K
    rms4 = lambda d: np.sqrt(sum((d[g] - m) ** 2 for g, m in meas.items()) / len(meas))
    rp = v2[v2.closure == "P"].assign(r4=lambda d: rms4(d))[["R_um", "pinf_MPa", "r4"]]
    rt = t.assign(r4=lambda d: rms4(d)).merge(rp, on=["R_um", "pinf_MPa"], suffixes=("", "_P"))
    N["v2_rms_lo"] = K(rt.r4.min()); N["v2_rms_hi"] = K(rt.r4.max()); N["v2_rms_P"] = K(rp.r4.mean())
    N["v2_rms_better"] = str(int((rt.r4 < rt.r4_P).sum()))
    N["v2_n"] = str(len(t)); N["v2_ordered"] = str(int(t.ordered.sum()))
    q = t[np.isclose(t.R_um, 100) & np.isclose(t.pinf_MPa, 0.2)].iloc[0]
    for g in ("He", "Ne", "Ar", "Kr", "Xe"):
        N[f"v2_100_{g}"] = K(q[g])
    N["v2_100_XeHe"] = F(q.XeHe)
    bm = json.load(open(OUT + "benchmarks.json"))
    N["b1"] = ", ".join(f"{r['err_pct']:+.4f}" for r in bm["B1_rayleigh"])
    N["b2"] = f"{max(abs(r['err_vs_Req_pct']) for r in bm['B2_minnaert']):.3f}"
    N["b2_R0"] = f"{bm['B2_minnaert'][0]['err_vs_R0_pct']:.2f}"
    N["b3_max"] = f"{max(abs(r['diff_pct']) for r in bm['B3_energy_balance']):.1f}"
    N["b5_max"] = f"{max(abs(r['diff_pct']) for r in bm['B5_closure_limit']):.1e}"
    N["b4_c1"] = f"{bm['B4_image']['first_order_coeff']:.4f}"; N["b4_c2"] = f"{bm['B4_image']['second_order_coeff']:.4f}"
    rows = bm["B4_image"]["rows"]
    N["b4_RPquad_maxdiff"] = f"{max(abs(r['RP_wall_pct'] - r['quad_wall_pct']) for r in rows):.4f}"
    N["b4_rat2_maxdiff"] = f"{max(abs(r['quad_wall_pct'] - r['rattray2_pct']) for r in rows):.2f}"
    b6 = bm["B6_tolerance"]
    N["b6"] = f"{100 * abs(b6[0]['Tmax'] / b6[-1]['Tmax'] - 1):.4f}"
    return N


if __name__ == "__main__":
    N = build()
    json.dump(N, open(OUT + "numbers.json", "w"), indent=0)
    for k in sorted(N):
        print(k, "=", N[k])
