"""Continuity check: with the set-up of the earlier (ULTSON-D-26-01491) manuscript - no co-volume, kappa = 1.4018,
gas at 1 atm, R0 = 25 um, fixed liquid state for KM/PL and Cole's Tait B for Gilmore - hcbubble reproduces the
polytropic values of that manuscript's Table 5 at 1 and 10 MPa."""
from hcbubble import Case, simulate, Switches
REF = {(1e6, "RP"): 1456, (1e6, "KM"): 1317, (1e6, "PL"): 1319, (1e6, "G"): 1314,
       (1e7, "RP"): 12075, (1e7, "KM"): 4484, (1e7, "PL"): 4723, (1e7, "G"): 4619}
for (p, m), ref in REF.items():
    r = simulate(Case(model=m, closure="P", Rmax=25e-6, pinf=p, pg0=101325.0, kappa=1.4018, sw=Switches(hard_core=False),
                      liquid_state="fixed" if m != "G" else "tait", B_fixed=3.046e8 if m == "G" else None))
    print(f"{m:2s} {p/1e6:4.0f} MPa: {r['Tmax']:7.0f} K (earlier Table 5: {ref} K)")
