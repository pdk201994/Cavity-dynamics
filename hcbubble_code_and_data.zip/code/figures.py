"""Publication figures for the rewritten manuscript (static PNG, 300 dpi)."""
import sys, json, math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, LogNorm, Normalize
from matplotlib.ticker import NullFormatter, FixedLocator, FixedFormatter
from properties import LIQUIDS, GASES, LIQUID_ORDER
from hcbubble import xi_tinguely

OUT, FIG = "../out/", "../fig/"
INK, INK2, MUTED, GRID, AXIS = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#9a998f"
COL = {"KM": "#2a78d6", "PL": "#eb6834", "G": "#1baf7a", "RP": "#898781"}
MRK = {"KM": "o", "PL": "s", "G": "^", "RP": "D"}
NAME = {"KM": "Keller–Miksis", "PL": "Prosperetti–Lezzi", "G": "Gilmore", "RP": "Rayleigh–Plesset"}
SLOT = ["#2a78d6", "#eb6834", "#1baf7a"]
BLUES = ["#cde2fb", "#b7d3f6", "#9ec5f4", "#86b6ef", "#6da7ec", "#5598e7", "#3987e5", "#2a78d6",
         "#256abf", "#1c5cab", "#184f95", "#104281", "#0d366b"]
CMAP = LinearSegmentedColormap.from_list("blue", BLUES)

plt.rcParams.update({
    "font.size": 8.5, "font.family": "DejaVu Sans", "axes.titlesize": 9, "axes.labelsize": 8.5,
    "axes.edgecolor": AXIS, "axes.labelcolor": INK, "axes.linewidth": 0.8, "xtick.color": INK2,
    "ytick.color": INK2, "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.5, "legend.fontsize": 7.5, "legend.frameon": False,
    "lines.linewidth": 1.6, "lines.markersize": 5.5, "savefig.dpi": 300, "figure.dpi": 110,
    "axes.spines.top": False, "axes.spines.right": False, "text.color": INK,
})


def panel(ax, letter):
    ax.text(-0.14, 1.04, f"({letter})", transform=ax.transAxes, fontsize=9.5, fontweight="bold", va="bottom")


def logticks(ax, vals, labels, axis="x"):
    a = ax.xaxis if axis == "x" else ax.yaxis
    a.set_major_locator(FixedLocator(vals)); a.set_major_formatter(FixedFormatter(labels))
    a.set_minor_formatter(NullFormatter())


def save(fig, name):
    fig.savefig(FIG + name + ".png", bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("wrote", name)


def regime_tables(R=100e-6):
    df = pd.read_csv(OUT + "S1_regime_map.csv")
    df = df[np.isclose(df.Rmax, R)]
    W, k = LIQUIDS["water"], GASES["air"].kappa298
    T = df.pivot_table(index=["pinf", "pg0"], columns="label", values="Tmax")
    M = df.pivot_table(index=["pinf", "pg0"], columns="label", values="Mach")
    T["xi"] = [xi_tinguely(p - W.psat, k, g, W.rho(p), W.c(p)) for p, g in T.index]
    return df, T, M


def grid_of(T, col, fn=None):
    P = sorted(set(i[0] for i in T.index))
    G = sorted(set(i[1] for i in T.index))
    Z = np.full((len(P), len(G)), np.nan)
    for i, p in enumerate(P):
        for j, g in enumerate(G):
            if (p, g) in T.index:
                v = T.loc[(p, g)]
                Z[i, j] = fn(v) if fn else v[col]
    return np.array(P), np.array(G), Z


def edges(v):
    lv = np.log10(v)
    mid = 0.5 * (lv[1:] + lv[:-1])
    return 10 ** np.concatenate([[lv[0] - (mid[0] - lv[0])], mid, [lv[-1] + (lv[-1] - mid[-1])]])


def fig_regime():
    df, T, M = regime_tables()
    fig, axs = plt.subplots(2, 2, figsize=(6.8, 5.6), constrained_layout=True)
    specs = [
        ("Cavity-wall Mach number, KM-T", lambda v: M.loc[v.name, "KM-T"], LogNorm(0.005, 3), None),
        ("Polytropic over-prediction, T(KM) / T(KM-T)", lambda v: v["KM"] / v["KM-T"], LogNorm(1, 15), None),
        ("Spread of KM-T, PL-T, Gilmore-T (% of KM-T)",
         lambda v: 100 * (max(v["KM-T"], v["PL-T"], v["Gilmore-T"]) - min(v["KM-T"], v["PL-T"], v["Gilmore-T"])) / v["KM-T"],
         Normalize(0, 30), None),
        ("Rayleigh–Plesset over-prediction, T(RP-T) / T(KM-T)", lambda v: v["RP-T"] / v["KM-T"], LogNorm(1, 50), None),
    ]
    P = sorted(set(i[0] for i in T.index)); G = sorted(set(i[1] for i in T.index))
    XI = np.full((len(P), len(G)), np.nan)
    for i, p in enumerate(P):
        for j, g in enumerate(G):
            if (p, g) in T.index:
                XI[i, j] = T.loc[(p, g), "xi"]
    for ax, (title, fn, norm, _), letter in zip(axs.flat, specs, "abcd"):
        Pv, Gv, Z = grid_of(T, None, fn=lambda v, fn=fn: fn(v))
        m = ax.pcolormesh(edges(Gv), edges(Pv) / 1e6, np.ma.masked_invalid(Z), cmap=CMAP, norm=norm,
                          edgecolors="white", linewidth=1.0)
        ax.set_xscale("log"); ax.set_yscale("log")
        W_, k_ = LIQUIDS["water"], GASES["air"].kappa298
        gf = np.geomspace(edges(Gv)[0], edges(Gv)[-1], 200); pf = np.geomspace(edges(Pv)[0], edges(Pv)[-1], 200)
        GG, PP = np.meshgrid(gf, pf)
        XF = xi_tinguely(PP - W_.psat, k_, GG, W_.rho(PP), np.sqrt(W_.n_tait * (PP + W_.B) / W_.rho(PP)))
        cs = ax.contour(GG, PP / 1e6, XF, levels=[5, 30, 100], colors=INK2, linewidths=0.8, linestyles="--")
        ax.clabel(cs, fmt=lambda x: f"ξ={x:.0f}", fontsize=6.5, inline=True, manual=False)
        cb = fig.colorbar(m, ax=ax, shrink=0.9, pad=0.02)
        cb.ax.tick_params(labelsize=7); cb.outline.set_edgecolor(AXIS)
        ax.set_title(title, loc="left", fontsize=8.2)
        ax.set_xlabel("Gas pressure at maximum radius, $p_{g0}$ (Pa)")
        ax.set_ylabel("Recovery pressure, $p_\\infty$ (MPa)")
        ax.grid(False)
        ax.text(0.97, 0.04, "no collapse\n($p_{g0}+p_{sat}\\geq p_\\infty$)", transform=ax.transAxes, ha="right",
                va="bottom", fontsize=6, color=MUTED)
        panel(ax, letter)
    save(fig, "fig2_regime_map")


def fig_deviation():
    df = pd.read_csv(OUT + "S1_regime_map.csv")
    W, k = LIQUIDS["water"], GASES["air"].kappa298
    fig, axs = plt.subplots(1, 2, figsize=(6.8, 2.8), constrained_layout=True)
    ax = axs[0]
    for cl, fill, ls in (("P", "none", "--"), ("T", None, "-")):
        sub = df[df.closure == cl]
        T = sub.pivot_table(index=["Rmax", "pinf", "pg0"], columns="model", values="Tmax")
        Mk = sub.pivot_table(index=["Rmax", "pinf", "pg0"], columns="model", values="Mach")["KM"]
        for m in ("PL", "G"):
            dev = 100 * (T[m] / T["KM"] - 1)
            ax.scatter(Mk, dev, s=14, marker=MRK[m], facecolors=COL[m] if fill is None else "none",
                       edgecolors=COL[m], linewidths=0.8,
                       label=f"{NAME[m]} ({'energy balance' if cl == 'T' else 'polytropic'})")
    ax.axhline(0, color=AXIS, lw=0.8)
    for x in (0.3, 1.0):
        ax.axvline(x, color=MUTED, lw=0.6, ls=":")
    ax.set_xscale("log"); ax.set_xlim(3e-3, 5)
    ax.set_xlabel("Cavity-wall Mach number (Keller–Miksis)")
    ax.set_ylabel("Peak temperature relative to KM (%)")
    ax.legend(loc="upper left", fontsize=6.5, ncol=1)
    panel(ax, "a")
    ax = axs[1]
    for cl, fill in (("P", "none"), ("T", None)):
        sub = df[df.closure == cl]
        T = sub.pivot_table(index=["Rmax", "pinf", "pg0"], columns="model", values="Tmax")
        xi = [xi_tinguely(p - W.psat, k, g, W.rho(p), W.c(p)) for (_, p, g) in T.index]
        ax.scatter(xi, T["RP"] / T["KM"], s=14, marker=MRK["RP"], facecolors=COL["RP"] if fill is None else "none",
                   edgecolors=COL["RP"], linewidths=0.8,
                   label=f"RP / KM ({'energy balance' if cl == 'T' else 'polytropic'})")
    ax.axhline(1, color=AXIS, lw=0.8)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("Energy-partition parameter ξ (Tinguely et al.)")
    ax.set_ylabel("Peak temperature, RP / KM")
    ax.legend(loc="upper left", fontsize=6.5)
    panel(ax, "b")
    save(fig, "fig3_model_deviation")


def fig_ladder():
    s2 = pd.read_csv(OUT + "S2_contents.csv")
    lad = s2[s2.tag.str.startswith("ladder")].copy()
    lad["step"] = lad.tag.str.replace("ladder:", "", regex=False)
    order = ["polytropic", "adiabatic_frozen", "+cv(T)", "+conduction", "+vapour transport (full)"]
    lab = ["Polytropic", "EB, no\ntransfer", "+ $c_v(T)$", "+ heat\nconduction", "+ vapour\nexchange"]
    fig, axs = plt.subplots(1, 2, figsize=(6.8, 2.9), constrained_layout=True, sharey=True)
    for ax, (p, g), letter in zip(axs, ((3e5, 1e3), (3e5, 1e4)), "ab"):
        for gas, col, mk in (("Ar", SLOT[0], "o"), ("air", SLOT[1], "s"), ("CO2", SLOT[2], "^")):
            q = lad[(lad.gas == gas) & np.isclose(lad.pinf, p) & np.isclose(lad.pg0, g)].set_index("step").loc[order]
            ax.plot(range(5), q.Tmax, marker=mk, color=col, label={"CO2": "CO$_2$"}.get(gas, gas))
        ax.set_yscale("log")
        ax.set_xticks(range(5)); ax.set_xticklabels(lab, fontsize=7)
        ax.set_title(f"$p_\\infty$ = {p/1e6:.1f} MPa, $p_{{g0}}$ = {g/1e3:.0f} kPa, $R_{{max}}$ = 100 µm (KM)",
                     loc="left", fontsize=8)
        panel(ax, letter)
    axs[0].set_ylabel("Peak temperature (K)")
    axs[0].legend(loc="upper right")
    save(fig, "fig4_closure_ladder")


def fig_gases(v2=True):
    s2 = pd.read_csv(OUT + "S2_contents.csv")
    main = s2[s2.tag == "S2"]
    fig, axs = plt.subplots(1, 2, figsize=(6.8, 2.9), constrained_layout=True)
    ax = axs[0]
    gases = ["He", "Ne", "Ar", "Kr", "Xe", "air", "CO2"]
    x = np.arange(len(gases))
    for (g, ls, fill), off in zip(((1e3, "-", True), (1e4, "-", False)), (-0.12, 0.12)):
        for m in ("KM",):
            for cl, mk_fill in (("P", "none"), ("T", None)):
                q = main[(main.model == m) & (main.closure == cl) & np.isclose(main.pinf, 3e5) & np.isclose(main.pg0, g)]
                q = q.set_index("gas").loc[gases]
                col = SLOT[0] if g == 1e3 else SLOT[1]
                ax.scatter(x + off, q.Tmax, marker="o" if cl == "T" else "D", s=26,
                           facecolors=col if cl == "T" else "none", edgecolors=col, linewidths=1.0,
                           label=f"$p_{{g0}}$ = {g/1e3:.0f} kPa, {'KM-T' if cl == 'T' else 'KM (polytropic)'}")
    ax.set_yscale("log"); ax.set_xticks(x); ax.set_xticklabels([{"CO2": "CO$_2$"}.get(g, g) for g in gases])
    ax.set_ylabel("Peak temperature (K)")
    ax.set_title("Water, $p_\\infty$ = 0.3 MPa, $R_{max}$ = 100 µm", loc="left", fontsize=8)
    ax.legend(fontsize=6.3, loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=2)
    panel(ax, "a")
    ax = axs[1]
    if v2:
        noble_panel(ax)
    panel(ax, "b")
    save(fig, "fig5_gases")


DIDENKO_OCT = {"He": (3800, 170), "Ne": (4100, 100), "Ar": (4300, 140), "Kr": (4400, 190), "Xe": (5100, 70)}
DIDENKO_DOD = {"He": 2600, "Ar": 3200, "Xe": 3800}


def noble_calibrated(model="KM", closure="T", R=50e-6, g=100.0, target=4300.0):
    v2 = pd.read_csv(OUT + "V2_noble.csv")
    q = v2[(v2.model == model) & (v2.closure == closure) & np.isclose(v2.Rmax, R) & np.isclose(v2.pg0, g)]
    ar = q[q.gas == "Ar"].sort_values("pinf")
    # interpolate p_inf at which argon reaches the target in log-log
    lp, lt = np.log(ar.pinf.values), np.log(ar.Tmax.values)
    ok = np.isfinite(lt)
    pcal = float(np.exp(np.interp(np.log(target), lt[ok], lp[ok])))
    out = {}
    for gas in ("He", "Ne", "Ar", "Kr", "Xe"):
        s = q[q.gas == gas].sort_values("pinf")
        out[gas] = float(np.exp(np.interp(np.log(pcal), np.log(s.pinf.values), np.log(s.Tmax.values))))
    return pcal, out


def noble_panel(ax):
    gases = ("He", "Ne", "Ar", "Kr", "Xe")
    xs = np.array([GASES[g].lam for g in gases])
    meas = np.array([DIDENKO_OCT[g][0] for g in gases]); err = np.array([DIDENKO_OCT[g][1] for g in gases])
    cal = pd.read_csv(OUT + "V2b_calibrated.csv")
    for (R, col, mk) in ((25.0, SLOT[1], "^"), (50.0, SLOT[0], "o"), (100.0, SLOT[2], "v")):
        q = cal[(cal.closure == "T") & np.isclose(cal.R_um, R) & np.isclose(cal.pinf_MPa, 0.2)].iloc[0]
        ax.plot(xs, [q[g] for g in gases], "-", marker=mk, color=col, label=f"KM-T, $R_{{max}}$ = {R:.0f} µm")
    q = cal[(cal.closure == "P") & np.isclose(cal.R_um, 50.0) & np.isclose(cal.pinf_MPa, 0.2)].iloc[0]
    ax.plot(xs, [q[g] for g in gases], "--", marker="D", mfc="white", color=COL["RP"], label="KM, polytropic (any size)")
    ax.errorbar(xs, meas, yerr=err, fmt="s", color=INK, mfc="white", mew=1.0, ms=5, capsize=2,
                label="Measured (Didenko et al.)", zorder=5)
    for g, x in zip(gases, xs):
        ax.annotate(g, (x, 2950), ha="center", fontsize=7, color=INK2)
    ax.set_xscale("log"); ax.set_xlabel("Thermal conductivity of the gas at 298 K (W m$^{-1}$ K$^{-1}$)")
    ax.set_ylabel("Peak / emission temperature (K)"); ax.set_ylim(2850, 5500)
    ax.set_title("Noble gases in octanol; argon fitted to 4300 K ($p_\\infty$ = 0.2 MPa)", loc="left", fontsize=7.8)
    ax.legend(fontsize=6.0, loc="upper right")


def fig_tinguely():
    v1 = pd.read_csv(OUT + "V1_tinguely.csv")
    meas = {1e4: 0.57, 3e4: 0.22}
    fig, axs = plt.subplots(1, 2, figsize=(6.8, 2.9), constrained_layout=True, sharey=True)
    combos = [("RP", "P"), ("KM", "P"), ("PL", "P"), ("G", "P"), ("RP", "T"), ("KM", "T"), ("PL", "T"), ("G", "T")]
    labels = ["RP", "KM", "PL", "Gilmore", "RP-T", "KM-T", "PL-T", "Gilmore-T"]
    for ax, p, letter in zip(axs, (1e4, 3e4), "ab"):
        for i, (m, cl) in enumerate(combos):
            q = v1[(v1.model == m) & (v1.closure == cl) & np.isclose(v1.pinf, p)]
            base = q[np.isclose(q.Rmax, 3.5e-3) & np.isclose(q.pg0, 7.0) & np.isclose(q.alpha, 0.4)]
            lo, hi = q.reb_ratio.min(), q.reb_ratio.max()
            y = len(combos) - 1 - i
            ax.plot([lo, hi], [y, y], color=COL[m], lw=2.2, alpha=0.45, solid_capstyle="round")
            ax.scatter(base.reb_ratio, [y] * len(base), marker=MRK[m], s=30, color=COL[m] if cl == "T" else "white",
                       edgecolors=COL[m], linewidths=1.1, zorder=4)
        ax.axvline(meas[p], color=INK, lw=1.0)
        ax.text(meas[p], len(combos) - 0.4, f" measured {meas[p]:.2f}", fontsize=7, va="bottom")
        ax.set_yticks(range(len(combos))); ax.set_yticklabels(labels[::-1])
        ax.set_xlim(0, 1.05); ax.set_xlabel("Rebound radius / maximum radius")
        ax.set_title(f"$p_\\infty$ = {p/1e3:.0f} kPa", loc="left", fontsize=8.5)
        panel(ax, letter)
    save(fig, "fig6_tinguely")


def fig_solvents():
    s4 = pd.read_csv(OUT + "S4_solvents.csv")
    m = s4[s4.tag == "S4"]
    fig, axs = plt.subplots(1, 2, figsize=(6.8, 2.9), constrained_layout=True)
    liqs = [l for l in LIQUID_ORDER if l != "glycerol"]
    mix = ["water", "20% MeOH", "40% MeOH", "60% MeOH", "80% MeOH", "methanol"]
    pure = ["ethanol", "isopropanol", "acetone"]
    ax = axs[0]
    for (g, col) in ((1e3, SLOT[0]), (1e4, SLOT[1])):
        for cl, fill, ls in (("T", True, "-"), ("P", False, "--")):
            q = m[(m.model == "KM") & (m.closure == cl) & np.isclose(m.pinf, 3e5) & np.isclose(m.pg0, g)].set_index("liquid")
            xm = [LIQUIDS[l].psat for l in mix]; ym = q.loc[mix, "Tmax"]
            ax.plot(xm, ym, ls, marker="o", color=col, mfc=col if fill else "white", ms=4,
                    label=f"$p_{{g0}}$ = {g/1e3:.0f} kPa, {'KM-T' if cl == 'T' else 'KM (polytropic)'}")
            xp = [LIQUIDS[l].psat for l in pure]; yp = q.loc[pure, "Tmax"]
            ax.scatter(xp, yp, marker="s", s=24, color=col if fill else "white", edgecolors=col, zorder=4)
            if cl == "T" and g == 1e3:
                for l, x_, y_ in zip(pure, xp, yp):
                    ax.annotate({"isopropanol": "IPA"}.get(l, l), (x_, y_), textcoords="offset points", xytext=(4, -9),
                                fontsize=6.5, color=INK2)
    ax.set_xscale("log"); ax.set_yscale("log")
    logticks(ax, [3e3, 1e4, 3e4], ["3 000", "10 000", "30 000"])
    ax.set_xlabel("Saturation vapour pressure at 25 °C (Pa)"); ax.set_ylabel("Peak temperature (K)")
    ax.set_title("$p_\\infty$ = 0.3 MPa, $R_{max}$ = 100 µm, air", loc="left", fontsize=7.8)
    ax.legend(fontsize=6.2, loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=2)
    panel(ax, "a")
    ax = axs[1]
    for (g, col) in ((1e3, SLOT[0]), (1e4, SLOT[1])):
        q = m[(m.label == "KM-T") & np.isclose(m.pinf, 3e5) & np.isclose(m.pg0, g)].set_index("liquid")
        ax.plot([LIQUIDS[l].psat for l in mix], q.loc[mix, "xv_collapse"], "-o", color=col, ms=4,
                label=f"$p_{{g0}}$ = {g/1e3:.0f} kPa")
        ax.scatter([LIQUIDS[l].psat for l in pure], q.loc[pure, "xv_collapse"], marker="s", s=24, color=col, zorder=4)
        if g == 1e3:
            for l in pure:
                ax.annotate({"isopropanol": "IPA"}.get(l, l), (LIQUIDS[l].psat, q.loc[l, "xv_collapse"]),
                            textcoords="offset points", xytext=(5, -3), fontsize=6.5, color=INK2)
    ax.set_xscale("log"); ax.set_ylim(0, 1)
    logticks(ax, [3e3, 1e4, 3e4], ["3 000", "10 000", "30 000"])
    ax.set_xlabel("Saturation vapour pressure at 25 °C (Pa)"); ax.set_ylabel("Vapour mole fraction at collapse (KM-T)")
    ax.legend(fontsize=6.5, loc="upper left")
    panel(ax, "b")
    save(fig, "fig7_solvents")


def fig_glycerol():
    s4 = pd.read_csv(OUT + "S4_solvents.csv")
    gl = s4[s4.tag == "S4_glycerol"].copy()
    gl["Re"] = gl.Rmax * np.sqrt(1258.0 * (gl.pinf - 0.017)) / 0.934
    fig, ax = plt.subplots(figsize=(3.4, 2.8), constrained_layout=True)
    for p, col, mk in ((1e5, SLOT[0], "o"), (3e5, SLOT[1], "s"), (1e6, SLOT[2], "^")):
        q = gl[(gl.label == "KM-T") & np.isclose(gl.pinf, p) & np.isclose(gl.pg0, 1e3)].sort_values("Rmax")
        ok = q.collapsed.astype(bool)
        ax.plot(q.Re, q.Tmax, "-", color=col, alpha=0.5)
        ax.scatter(q.Re[ok], q.Tmax[ok], marker=mk, color=col, s=26, label=f"{p/1e6:.1f} MPa", zorder=4)
        ax.scatter(q.Re[~ok], q.Tmax[~ok], marker=mk, facecolors="white", edgecolors=col, s=26, zorder=4)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("$Re = R_{max}\\sqrt{\\rho\\,\\Delta p}\\,/\\,\\mu$"); ax.set_ylabel("Peak temperature, KM-T (K)")
    ax.set_title("Glycerol, $p_{g0}$ = 1 kPa; open: over-damped", loc="left", fontsize=8)
    ax.legend(title="$p_\\infty$", fontsize=6.5, title_fontsize=7, loc="upper left")
    save(fig, "fig8_glycerol")


def fig_boundaries():
    s3 = pd.read_csv(OUT + "S3_boundaries.csv")
    bm = json.load(open(OUT + "benchmarks.json"))["B4_image"]["rows"]
    ref = s3[s3.tag == "S3_unbounded"].set_index("label")
    b = s3[s3.tag == "S3"].copy()
    b["dtc"] = 100 * (b.t_c / b.label.map(ref.t_c) - 1); b["dT"] = 100 * (b.Tmax / b.label.map(ref.Tmax) - 1)
    fig, axs = plt.subplots(1, 2, figsize=(6.8, 2.8), constrained_layout=True)
    ax = axs[0]
    g = np.array([r["gamma"] for r in bm])
    ax.plot(g, [r["rattray2_pct"] for r in bm], color=MUTED, lw=1.0, ls=":", label="Rattray, 2nd order")
    ax.plot(g, [-r["rattray2_pct"] for r in bm], color=MUTED, lw=1.0, ls=":")
    for bnd, mk in (("wall", "o"), ("free", "s")):
        q = b[(b.boundary == bnd) & (b.label == "KM-T")].sort_values("gamma")
        ax.plot(q.gamma, q.dtc, "-", marker=mk, color=SLOT[0] if bnd == "wall" else SLOT[1],
                label=f"KM-T, {'rigid wall' if bnd == 'wall' else 'free surface'}")
        quad = [r["quad_wall_pct"] if bnd == "wall" else r["quad_free_pct"] for r in bm]
        ax.scatter(g, quad, marker="x", color=INK2, s=18, zorder=5, label="image-model quadrature" if bnd == "wall" else None)
    ax.axhline(0, color=AXIS, lw=0.8)
    ax.axvspan(1.4, 3.5, color="#f0efec", zorder=0)
    ax.text(1.5, 0.8, "luminescence lost\nnear walls (expts)", fontsize=6.3, color=INK2)
    ax.set_xscale("log"); logticks(ax, [1.5, 2, 3, 5, 7, 10], ["1.5", "2", "3", "5", "7", "10"])
    ax.set_xlabel("Stand-off γ = d / $R_{max}$"); ax.set_ylabel("Change in collapse time (%)")
    ax.legend(fontsize=6.3, loc="upper right")
    panel(ax, "a")
    ax = axs[1]
    for m in ("KM", "PL", "G", "RP"):
        for cl, ls in (("T", "-"), ("P", "--")):
            q = b[(b.boundary == "wall") & (b.model == m) & (b.closure == cl)].sort_values("gamma")
            ax.plot(q.gamma, q.dT, ls, marker=MRK[m], color=COL[m], ms=3.5, mfc=COL[m] if cl == "T" else "white",
                    label=f"{NAME[m]}{'-T' if cl == 'T' else ''}" if True else None)
    ax.axhline(0, color=AXIS, lw=0.8)
    ax.set_xscale("log"); logticks(ax, [1.5, 2, 3, 5, 7, 10], ["1.5", "2", "3", "5", "7", "10"])
    ax.set_xlabel("Stand-off γ (rigid wall)"); ax.set_ylabel("Change in peak temperature (%)")
    ax.set_title("Spherical models only: shape change not represented", loc="left", fontsize=7.5)
    ax.legend(fontsize=5.6, ncol=2, loc="upper right")
    panel(ax, "b")
    save(fig, "fig9_boundaries")


if __name__ == "__main__":
    which = sys.argv[1:] or ["regime", "deviation", "ladder", "solvents", "glycerol", "boundaries"]
    for w in which:
        globals()["fig_" + w]()
