"""Vector extraction of curves from PDF figures (filled outlines of stroked lines)."""
import numpy as np
import pymupdf

def subpaths(drawing, tol=1e-3):
    """split a PyMuPDF drawing into subpaths: list of (N,2) point arrays (curve items sampled at their nodes)"""
    out, cur, last = [], [], None
    for it in drawing['items']:
        kind = it[0]
        if kind == 'l':
            pts = [it[1], it[2]]
        elif kind == 'c':
            pts = [it[1], it[2], it[3], it[4]]
            # sample the bezier
            P0, P1, P2, P3 = [np.array([q.x, q.y]) for q in pts]
            s = np.linspace(0, 1, 6)[:, None]
            B = (1-s)**3*P0 + 3*(1-s)**2*s*P1 + 3*(1-s)*s**2*P2 + s**3*P3
            pts = [pymupdf.Point(*b) for b in B]
        elif kind == 're':
            r = it[1]
            pts = [r.tl, r.tr, r.br, r.bl, r.tl]
        elif kind == 'qu':
            q = it[1]
            pts = [q.ul, q.ur, q.lr, q.ll, q.ul]
        else:
            continue
        p0 = pts[0]
        if last is None or abs(p0.x - last.x) > tol or abs(p0.y - last.y) > tol:
            if cur:
                out.append(np.array(cur))
            cur = [(p0.x, p0.y)]
        for q in pts[1:]:
            cur.append((q.x, q.y))
        last = pts[-1]
    if cur:
        out.append(np.array(cur))
    return out

def drawings_by_colour(page, box, colour, tol=0.01):
    res = []
    for d in page.get_drawings():
        col = d.get('fill') if d.get('fill') is not None else d.get('color')
        if col is None or not pymupdf.Rect(*box).intersects(d['rect']):
            continue
        if max(abs(a - b) for a, b in zip(col, colour)) < tol:
            res.append(d)
    return res
