"""Extract dashed (mean) curves from traced vector figures: rasterise one colour, erode away dots and thin
lines, then take the centre line of every remaining dash (centroid and two points along its principal axis)."""
import sys, json
sys.path.insert(0, '.')
import numpy as np, pymupdf
from PIL import Image, ImageDraw
from scipy import ndimage
from vec import subpaths

def colour_mask(page, box, colour, tol, scale):
    x0, y0, x1, y1 = box
    W, H = int((x1 - x0) * scale) + 1, int((y1 - y0) * scale) + 1
    im = Image.new('1', (W, H), 0)
    dr = ImageDraw.Draw(im)
    B = pymupdf.Rect(*box)
    for d in page.get_drawings():
        f = d.get('fill')
        if f is None or not B.intersects(d['rect']):
            continue
        if max(abs(a - b) for a, b in zip(f, colour)) > tol:
            continue
        for s in subpaths(d):
            if len(s) < 3:
                continue
            pts = [((px - x0) * scale, (py - y0) * scale) for px, py in s]
            dr.polygon(pts, fill=1)
    return np.array(im, dtype=bool)

def disk(r):
    y, x = np.mgrid[-r:r + 1, -r:r + 1]
    return x * x + y * y <= r * r

def dash_points(mask, scale, erode_pt=0.45, min_len_pt=2.0, ends=0.35):
    er = ndimage.binary_erosion(mask, structure=disk(int(round(erode_pt * scale))))
    lab, n = ndimage.label(er)
    out = []
    for i in range(1, n + 1):
        yy, xx = np.nonzero(lab == i)
        if len(xx) < 5:
            continue
        P = np.c_[xx, yy].astype(float) / scale
        c = P.mean(0)
        U, S, Vt = np.linalg.svd(P - c, full_matrices=False)
        ax = Vt[0]
        proj = (P - c) @ ax
        L = proj.max() - proj.min()
        wid = (P - c) @ Vt[1]
        W = wid.max() - wid.min()
        if L < min_len_pt:
            continue
        out.append(dict(c=c, ax=ax, L=L, W=W, n=len(xx)))
    return out

def to_tp(xy, box, cal):
    x = xy[:, 0] + box[0]
    y = xy[:, 1] + box[1]
    lt = cal['lt0'] + (x - cal['x0']) / cal['sx']
    lp = cal['lp0'] + (cal['y0'] - y) / cal['sy']
    return 10 ** lt, 10 ** lp

def curve(page, box, colour, tol, cal, scale=12, erode_pt=0.45, min_len_pt=2.0, ends=0.3):
    m = colour_mask(page, box, colour, tol, scale)
    ds = dash_points(m, scale, erode_pt, min_len_pt)
    pts = []
    for d in ds:
        for s in (-ends, 0.0, ends):
            pts.append(d['c'] + s * d['L'] * d['ax'])
    pts = np.array(pts)
    t, p = to_tp(pts, box, cal)
    o = np.argsort(t)
    return t[o], p[o], ds

FIG = {
    '10b': dict(page=7, box=(170.6, 434.6, 460.4, 605.2), erode=0.45, minlen=2.0,
                cal=dict(x0=170.17, sx=145.115, lt0=-5.0, y0=605.70, sy=57.08, lp0=2.0),
                curves={'V-PR3.0': ((0.996, 0.756, 0.056), 0.02),
                        'V-PR4.0': ((0.29, 0.452, 0.724), 0.02),
                        'V-PR5.5': ((0.038, 0.695, 0.32), 0.02)}),
    '19': dict(page=10, box=(77.9, 519.5, 281.4, 652.9), erode=0.25, minlen=1.5,
               cal=dict(x0=77.56, sx=101.86, lt0=-5.0, y0=653.23, sy=44.70, lp0=2.0),
               curves={'V-PR3.0-fig19': ((1.0, 0.757, 0.012), 0.02),
                       'V-b7.5-PR3.0': ((0.012, 0.447, 0.757), 0.02),
                       'V-ld3-PR3.0': ((0.012, 0.012, 0.012), 0.02)}),
}

if __name__ == '__main__':
    doc = pymupdf.open('../../pdfs/aiche/paper.pdf')
    res = {}
    for fk, F in FIG.items():
        page = doc[F['page']]
        for name, (col, tol) in F['curves'].items():
            t, p, ds = curve(page, F['box'], col, tol, F['cal'], erode_pt=F['erode'], min_len_pt=F['minlen'])
            Ls = np.array([d['L'] for d in ds]); Ws = np.array([d['W'] for d in ds])
            print(f'{fk} {name}: {len(ds)} dashes, L median {np.median(Ls):.2f} pt, W median {np.median(Ws):.2f} pt, '
                  f't {t.min():.2e}-{t.max():.2e}, p {p.min():.0f}-{p.max():.0f}')
            res[name] = dict(fig=fk, t=t.tolist(), p=p.tolist(), L=Ls.tolist(), W=Ws.tolist())
    json.dump(res, open('aiche_dashes_raw.json', 'w'))
