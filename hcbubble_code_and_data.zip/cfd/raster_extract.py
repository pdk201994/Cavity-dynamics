import sys, json
sys.path.insert(0, '.')
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import median_filter

def runs(col):
    if col.size == 0:
        return []
    br = np.nonzero(np.diff(col) > 1)[0]
    return np.split(col, br + 1)

def track(cand, x_lo, x_hi, y_start, max_jump=18, min_run=2):
    """cand: boolean candidate mask (full image). follow the run nearest to the previous y."""
    xs, ys = [], []
    prev = y_start
    miss = 0
    for x in range(x_lo, x_hi):
        rr = [r for r in runs(np.nonzero(cand[:, x])[0]) if len(r) >= min_run]
        if not rr:
            miss += 1
            continue
        c = np.array([r.mean() for r in rr])
        j = int(np.argmin(np.abs(c - prev)))
        jump = max_jump * (1 + miss)
        if abs(c[j] - prev) > jump:
            miss += 1
            continue
        xs.append(x); ys.append(c[j]); prev = c[j]; miss = 0
    return np.array(xs), np.array(ys)

def cal(fr):
    top, bot, left, right = fr
    def f(x, y):
        return 10 ** (-5 + 2 * (x - left) / (right - left)), 10 ** (2 + 3 * (bot - y) / (bot - top))
    def inv_y(p):
        return bot - (np.log10(p) - 2) / 3 * (bot - top)
    return f, inv_y

A = np.array(Image.open('cherd_p10_x218.png').convert('RGB')).astype(int)
B = np.array(Image.open('cherd_p12_x247.png').convert('RGB')).astype(int)
R, G, Bc = A[..., 0], A[..., 1], A[..., 2]
R2, G2, B2 = B[..., 0], B[..., 1], B[..., 2]
FR = {'6b': (540.5, 1193.0, 181.5, 1462.0), '6c': (1413.5, 2051.0, 191.5, 1458.5), '8c': (1437.0, 2090.5, 186.0, 1463.5)}
cands = {
    'O-ld2-PR5.0': ('6b', A, (np.abs(R - G) < 16) & (np.abs(G - Bc) < 16) & (R < 172) & (R > 110), 3800),
    'O-ld2-PR2.5': ('6b', A, (R > 205) & (G > 95) & (G < 150) & (Bc < 95), 3800),
    'O-ld5-PR5.0': ('6c', A, (Bc > R + 90) & (R < 95) & (G < 135), 3500),
    'O-ld2-PR5.0-fig6c': ('6c', A, (G > R + 35) & (G > Bc + 60) & (R < 135), 3800),
    'O-r0.2-PR5.0': ('8c', B, (B2 > R2 + 90) & (R2 < 100) & (G2 < 140), 3600),
    'O-r0-PR5.0-fig8c': ('8c', B, (G2 > R2 + 35) & (G2 > B2 + 60) & (R2 < 135) & (G2 < 175), 3800),
}
out = {}
for name, (fk, img, cand, p0) in cands.items():
    f, inv_y = cal(FR[fk])
    top, bot, left, right = FR[fk]
    cm = np.zeros_like(cand); cm[int(top) + 3:int(bot) - 2, int(left) + 3:int(right) - 2] = cand[int(top) + 3:int(bot) - 2, int(left) + 3:int(right) - 2]
    xs, ys = track(cm, int(left) + 4, int(right) - 3, inv_y(p0))
    ys_f = median_filter(ys, size=9, mode='nearest')
    t, p = f(xs, ys_f)
    out[name] = dict(fig=fk, t=t.tolist(), p=p.tolist(), cover=len(xs) / (right - left))
    print(name, 'columns', len(xs), 'coverage %.2f' % (len(xs) / (right - left - 7)), 't %.2e-%.2e p %.0f-%.0f' % (t.min(), t.max(), p.min(), p.max()))
    # overlay
    im = Image.fromarray(img.astype(np.uint8)).crop((int(left) - 5, int(top) - 5, int(right) + 5, int(bot) + 5))
    dr = ImageDraw.Draw(im)
    for x, y in zip(xs, ys_f):
        dr.point((x - int(left) + 5, y - int(top) + 5), fill=(255, 0, 255))
    im.save(f'ovl_{name}.png')
json.dump(out, open('cherd_raw.json', 'w'))
