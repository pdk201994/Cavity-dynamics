"""Build smooth mean pressure histories from the digitized points and check the duplicated curves."""
import json
import numpy as np
from scipy.interpolate import PchipInterpolator

A = json.load(open('aiche_dashes_raw.json'))
C = json.load(open('cherd_raw.json'))

def binned(t, p, lo=-5.0, hi=-3.0, w=0.02, nmin=1):
    lt, lp = np.log10(t), np.log10(p)
    edges = np.arange(lo, hi + w / 2, w)
    xs, ys = [], []
    for a, b in zip(edges[:-1], edges[1:]):
        m = (lt >= a) & (lt < b)
        if m.sum() >= nmin:
            xs.append(np.median(lt[m])); ys.append(np.median(lp[m]))
    return np.array(xs), np.array(ys)

def smooth_curve(t, p, w=0.02):
    x, y = binned(np.asarray(t), np.asarray(p), w=w)
    # light 3-point running median to remove isolated outliers, keep steep rises
    y2 = y.copy()
    for i in range(1, len(y) - 1):
        y2[i] = np.median(y[i - 1:i + 2])
    return x, y2

def merge(*pairs):
    t = np.concatenate([np.asarray(a) for a, _ in pairs]); p = np.concatenate([np.asarray(b) for _, b in pairs])
    o = np.argsort(t)
    return t[o], p[o]

def rms_log_diff(ta, pa, tb, pb):
    xa, ya = smooth_curve(ta, pa); xb, yb = smooth_curve(tb, pb)
    lo, hi = max(xa[0], xb[0]), min(xa[-1], xb[-1])
    x = np.linspace(lo, hi, 200)
    da = PchipInterpolator(xa, ya)(x); db = PchipInterpolator(xb, yb)(x)
    d = 10 ** (da - db) - 1
    return float(np.sqrt(np.mean(d ** 2))), float(np.max(np.abs(d)))

checks = {}
checks['venturi PR3.0: Fig 10b vs Fig 19'] = rms_log_diff(A['V-PR3.0']['t'], A['V-PR3.0']['p'], A['V-PR3.0-fig19']['t'], A['V-PR3.0-fig19']['p'])
checks['orifice l/d2 PR5: Fig 6b vs Fig 8c'] = rms_log_diff(C['O-ld2-PR5.0']['t'], C['O-ld2-PR5.0']['p'], C['O-r0-PR5.0-fig8c']['t'], C['O-r0-PR5.0-fig8c']['p'])
checks['orifice l/d2 PR5: Fig 6b vs Fig 6c'] = rms_log_diff(C['O-ld2-PR5.0']['t'], C['O-ld2-PR5.0']['p'], C['O-ld2-PR5.0-fig6c']['t'], C['O-ld2-PR5.0-fig6c']['p'])
for k, v in checks.items():
    print('%-40s rms %.1f%%  max %.1f%%' % (k, 100 * v[0], 100 * v[1]))

H = {
    'V-PR3.0': dict(device='venturi', design='Case 3 (d = 2 mm, l/d = 0, diffuser 9.25 deg)', PR=3.0, src='AIChE J Fig. 10b + Fig. 19',
                    pts=merge((A['V-PR3.0']['t'], A['V-PR3.0']['p']), (A['V-PR3.0-fig19']['t'], A['V-PR3.0-fig19']['p']))),
    'V-PR4.0': dict(device='venturi', design='Case 3', PR=4.0, src='AIChE J Fig. 10b', pts=(A['V-PR4.0']['t'], A['V-PR4.0']['p'])),
    'V-PR5.5': dict(device='venturi', design='Case 3', PR=5.5, src='AIChE J Fig. 10b', pts=(A['V-PR5.5']['t'], A['V-PR5.5']['p'])),
    'V-b7.5': dict(device='venturi', design='l/d = 0, diffuser 7.5 deg', PR=3.0, src='AIChE J Fig. 19', pts=(A['V-b7.5-PR3.0']['t'], A['V-b7.5-PR3.0']['p'])),
    'V-ld3': dict(device='venturi', design='l/d = 3, diffuser 9.25 deg', PR=3.0, src='AIChE J Fig. 19', pts=(A['V-ld3-PR3.0']['t'], A['V-ld3-PR3.0']['p'])),
    'O-PR5.0': dict(device='orifice', design='sharp-edged, l/d = 2', PR=5.0, src='ChERD Fig. 6b (checked against Figs. 6c and 8c)',
                    pts=merge((C['O-ld2-PR5.0']['t'], C['O-ld2-PR5.0']['p']), (C['O-r0-PR5.0-fig8c']['t'], C['O-r0-PR5.0-fig8c']['p']))),
}
grid = np.concatenate([np.linspace(0, 1e-5, 41)[:-1], np.logspace(-5, -3, 3001)])
out = {'t': grid.tolist(), 'checks': checks, 'meta': {}}
for k, h in H.items():
    x, y = smooth_curve(*h['pts'], w=0.02 if k.startswith('V') else 0.015)
    f = PchipInterpolator(x, y, extrapolate=True)
    lt = np.log10(np.maximum(grid, 1e-5))
    lt = np.clip(lt, x[0], x[-1])           # hold the end values outside the digitized range
    p = 10 ** f(lt)
    out[k] = p.tolist()
    out['meta'][k] = dict(device=h['device'], design=h['design'], PR=h['PR'], src=h['src'], p0=float(p[0]), p_end=float(p[-1]),
                          t_first=float(10 ** x[0]), t_last=float(10 ** x[-1]), n_pts=int(len(h['pts'][0])))
    print('%-8s p(0) %.0f Pa  p(1 ms) %.0f Pa  digitized %.2e-%.2e s  bins %d' % (k, p[0], p[-1], 10 ** x[0], 10 ** x[-1], len(x)))
json.dump(out, open('../out/H_histories.json', 'w'))
