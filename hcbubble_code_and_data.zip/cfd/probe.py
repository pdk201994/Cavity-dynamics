import sys, collections
import pymupdf
pdf, pno, x0, y0, x1, y1 = sys.argv[1], int(sys.argv[2]), *map(float, sys.argv[3:7])
doc = pymupdf.open(pdf)
p = doc[pno]
box = pymupdf.Rect(x0, y0, x1, y1)
groups = collections.defaultdict(list)
for k, d in enumerate(p.get_drawings()):
    r = d['rect']
    if not box.intersects(r):
        continue
    col = d.get('fill') if d.get('fill') is not None else d.get('color')
    key = (d['type'], tuple(round(c, 3) for c in col) if col else None, d.get('width'))
    groups[key].append((k, len(d['items']), [round(v, 1) for v in r], collections.Counter(it[0] for it in d['items'])))
for key, lst in groups.items():
    n = sum(x[1] for x in lst)
    print(key, 'paths', len(lst), 'items', n)
    for x in lst[:4]:
        print('    ', x)
