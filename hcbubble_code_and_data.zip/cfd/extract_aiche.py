"""Extract Simpson & Ranade (AIChE J 2019) Fig. 10b and Fig. 19 curves from the traced vector paths."""
import sys, json
sys.path.insert(0, '.')
import numpy as np, pymupdf
from vec import subpaths

PDF = '../../pdfs/aiche/paper.pdf'

def calib(page, plot_box, grey=(0.471, 0.477, 0.487)):
    """axis calibration from traced tick-label glyphs: returns (x0, pt/decade_x, logt0), (y_100, pt/decade_y)"""
    labs = []
    for d in page.get_drawings():
        f = d.get('fill')
        if f is None or max(abs(a - b) for a, b in zip(f, grey)) > 0.02:
            continue
        labs.append(d['rect'])
    return labs

def centroids(drawings):
    pts, sizes = [], []
    for d in drawings:
        for s in subpaths(d):
            x0, y0 = s.min(0); x1, y1 = s.max(0)
            pts.append(((x0 + x1) / 2, (y0 + y1) / 2)); sizes.append((x1 - x0, y1 - y0))
    return np.array(pts), np.array(sizes)

def by_colour(page, box, colour, tol=0.01):
    out = []
    B = pymupdf.Rect(*box)
    for d in page.get_drawings():
        f = d.get('fill')
        if f is None or not B.intersects(d['rect']):
            continue
        if max(abs(a - b) for a, b in zip(f, colour)) < tol:
            out.append(d)
    return out

if __name__ == '__main__':
    doc = pymupdf.open(PDF)
    p = doc[7]
    for r in calib(p, None):
        if 420 < r.y0 < 640 and 120 < r.x0 < 480:
            print('label', [round(v, 2) for v in r], 'cx %.2f cy %.2f' % ((r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2))
    box = (169, 433, 462, 607)
    cols = {'y': (0.996, 0.756, 0.056), 'b_dash': (0.29, 0.452, 0.724), 'b_dot': (0.072, 0.448, 0.729),
            'g_dash': (0.038, 0.695, 0.32), 'g_dot': (0.445, 0.683, 0.282)}
    for k, c in cols.items():
        P, S = centroids(by_colour(p, box, c))
        print(k, len(P), 'size median %.2f x %.2f, p90 %.2f x %.2f' % (*np.median(S, 0), *np.percentile(S, 90, 0)))
        np.save(f'raw_{k}.npy', np.hstack([P, S]))
