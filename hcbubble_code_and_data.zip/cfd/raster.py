"""Extract solid mean-pressure curves from the raster figures of Simpson & Ranade (ChERD 2018)."""
import json
import numpy as np
from PIL import Image
from scipy import ndimage

def frame(A, y0, y1, x0, x1):
    """frame lines (top, bottom, left, right) of a chart in a sub-window"""
    sub = A[y0:y1, x0:x1].sum(2) < 200
    r = sub.sum(1); c = sub.sum(0)
    rows = np.nonzero(r > 0.8 * (x1 - x0) * 0.85)[0] + y0
    cols = np.nonzero(c > 0.8 * (y1 - y0) * 0.8)[0] + x0
    return rows, cols

def mask_colour(A, rgb, tol):
    d = np.sqrt(((A - np.array(rgb)) ** 2).sum(2))
    return d < tol

def disk(r):
    y, x = np.mgrid[-r:r + 1, -r:r + 1]
    return x * x + y * y <= r * r

def column_track(m, x_lo, x_hi, y_start, max_jump=25):
    """follow one thick curve column by column: choose the run nearest the previous y"""
    ys, xs = [], []
    prev = y_start
    for x in range(x_lo, x_hi):
        col = np.nonzero(m[:, x])[0]
        if col.size == 0:
            continue
        # split into runs
        br = np.nonzero(np.diff(col) > 1)[0]
        runs = np.split(col, br + 1)
        cents = np.array([r.mean() for r in runs])
        sizes = np.array([len(r) for r in runs])
        j = int(np.argmin(np.abs(cents - prev)))
        if abs(cents[j] - prev) > max_jump:
            continue
        ys.append(cents[j]); xs.append(x); prev = cents[j]
    return np.array(xs), np.array(ys)
